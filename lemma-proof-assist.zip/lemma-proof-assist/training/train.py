#!/usr/bin/env python3
"""Prune SmolLM2's feed-forward channels and train a proof continuation LoRA on CPU."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import re
import shutil
import time
from urllib.request import urlopen

import pyarrow.parquet as pq
import torch
from peft import LoraConfig, get_peft_model
from transformers import AutoTokenizer, LlamaConfig, LlamaForCausalLM


BASE = 'HuggingFaceTB/SmolLM2-135M'
BASE_REVISION = '93efa2f097d58c2a74874c7e644dbc9b0cee75a2'
DATASET = 'project-numina/NuminaMath-CoT'
DATASET_REVISION = '9d8d210c9f6a36c8f3cd84045668c9b7800ef517'
DATASET_SHARD = 'data/train-00000-of-00005.parquet'
BASE_FILES = ('config.json', 'model.safetensors', 'tokenizer.json',
              'tokenizer_config.json', 'special_tokens_map.json')
SOURCES = {'math', 'olympiads', 'synthetic_amc', 'synthetic_math'}
PHRASES = re.compile(
    r'\b(?:to (?:show|prove|see)|it (?:suffices|remains) to|we (?:need|want) to|'
    r'(?:suppose|assume),? for contradiction|note that|observe that|'
    r'by (?:the definition|assumption|hypothesis)|without loss of generality|'
    r'for (?:each|some|all)|there exists|rearranging)\b', re.I,
)


def download(url, destination):
    if destination.is_file():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + '.part')
    with urlopen(url + '?download=true', timeout=120) as response, partial.open('wb') as out:
        shutil.copyfileobj(response, out)
    partial.replace(destination)


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def prepare(work, tokenizer, seed, length):
    data = work / 'data/numina.parquet'
    download(f'https://huggingface.co/datasets/{DATASET}/resolve/{DATASET_REVISION}/{DATASET_SHARD}', data)
    rng = random.Random(seed)
    # The dataset interleaves sources. Use an evenly spaced set of batches so
    # a source grouped near the beginning cannot dominate the split.
    parquet = pq.ParquetFile(data)
    if not {'source', 'solution'}.issubset(parquet.schema_arrow.names):
        raise ValueError('Expected source and solution columns')
    rows = []
    for idx, batch in enumerate(parquet.iter_batches(batch_size=512, columns=['source', 'solution'])):
        if idx % 4 == 0:
            rows.extend(batch.to_pylist())
    rng.shuffle(rows)
    train, validation = [], []
    sources = Counter()
    seen = set()
    for row in rows:
        if row['source'] not in SOURCES or not row['solution']:
            continue
        text = re.sub(r'\s+', ' ', row['solution']).strip()
        if len(text) < 80:
            continue
        digest = hashlib.blake2b(text.encode('utf-8'), digest_size=8).digest()
        if digest in seen:
            continue
        seen.add(digest)
        held_out = int.from_bytes(digest, 'big') % 16 == 0
        split, target = (validation, 96) if held_out else (train, 2048)
        if len(split) >= target:
            continue
        matches = list(PHRASES.finditer(text))
        if not matches:
            continue
        start = max(0, rng.choice(matches).start() - 85)
        start = text.rfind(' ', 0, start) + 1 if start else 0
        tokens = tokenizer.encode(text[start:start + 1200], add_special_tokens=False)[:length]
        if len(tokens) < 24:
            continue
        split.append(tokens)
        sources[f'{"validation" if held_out else "train"}:{row["source"]}'] += 1
        if len(train) == 2048 and len(validation) == 96:
            break
    if len(train) < 512 or len(validation) < 64:
        raise ValueError(f'Insufficient proof-writing windows: {len(train)} train, {len(validation)} validation')
    print(f'Prepared {len(train)} training and {len(validation)} held-out proof windows: {dict(sources)}', flush=True)
    return train, validation, dict(sources), sha256(data)


@torch.no_grad()
def prune(base, width, calibration, length, pad, dtype):
    original = LlamaForCausalLM.from_pretrained(base, torch_dtype=torch.float32, local_files_only=True)
    config = LlamaConfig.from_dict(original.config.to_dict())
    original_width = config.intermediate_size
    if not 0 < width < original_width or width % 128:
        raise ValueError(f'Keep a multiple of 128 channels below the original width {original_width}')
    original.eval()
    activity = torch.zeros(config.num_hidden_layers, original_width)
    handles = []

    def measure(index):
        def before_down_projection(_module, inputs):
            activity[index].add_(inputs[0].square().sum(dim=(0, 1)))
        return before_down_projection

    for index, layer in enumerate(original.model.layers):
        handles.append(layer.mlp.down_proj.register_forward_pre_hook(measure(index)))
    for start in range(0, len(calibration), 4):
        inputs, _ = make_batch(calibration[start:start + 4], length, pad)
        original.model(input_ids=inputs, use_cache=False)
    for handle in handles:
        handle.remove()

    weights = original.state_dict()
    for index in range(config.num_hidden_layers):
        stem = f'model.layers.{index}.mlp.'
        gate, up, down = [weights[stem + name + '_proj.weight'] for name in ('gate', 'up', 'down')]
        # Squared output contribution = squared channel activation times the
        # squared column norm. Keep the channels most active on proof text.
        importance = activity[index] * down.square().sum(dim=0)
        kept = importance.topk(width).indices.sort().values
        weights[stem + 'gate_proj.weight'] = gate.index_select(0, kept)
        weights[stem + 'up_proj.weight'] = up.index_select(0, kept)
        weights[stem + 'down_proj.weight'] = down.index_select(1, kept)
    config.intermediate_size = width
    model = LlamaForCausalLM(config)
    missing, unexpected = model.load_state_dict(weights, strict=False, assign=True)
    if set(missing) - {'lm_head.weight'} or unexpected:
        raise ValueError(f'Unexpected checkpoint tensors: {missing=}, {unexpected=}')
    model.tie_weights()
    return model.to(device='cpu', dtype=dtype)


def make_batch(sequences, length, pad):
    inputs = torch.full((len(sequences), length), pad, dtype=torch.long)
    labels = torch.full_like(inputs, -100)
    for row, tokens in enumerate(sequences):
        values = torch.tensor(tokens, dtype=torch.long)
        inputs[row, :len(tokens)] = values
        labels[row, :len(tokens)] = values
    # Padding is strictly on the right and has no labels. Causal attention
    # prevents real tokens from attending to it.
    return inputs, labels


@torch.no_grad()
def evaluate(model, sequences, length, pad, batch_size, dtype):
    model.eval()
    weighted_loss = predicted = 0
    for start in range(0, len(sequences), batch_size):
        inputs, labels = make_batch(sequences[start:start + batch_size], length, pad)
        with torch.autocast('cpu', dtype=torch.bfloat16, enabled=dtype == torch.bfloat16):
            loss = model(input_ids=inputs, labels=labels, use_cache=False).loss.item()
        count = int((labels[:, 1:] != -100).sum())
        weighted_loss += loss * count
        predicted += count
    return weighted_loss / predicted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work-dir', required=True, type=Path)
    parser.add_argument('--steps', type=int, default=280)
    parser.add_argument('--threads', type=int, default=3)
    parser.add_argument('--sequence-length', type=int, default=96)
    parser.add_argument('--batch-size', type=int, default=2)
    parser.add_argument('--width', type=int, default=1408)
    parser.add_argument('--rank', type=int, default=8)
    parser.add_argument('--seed', type=int, default=402)
    parser.add_argument('--bf16', action='store_true', help='Use only on CPUs with fast BF16 matrix multiplication')
    args = parser.parse_args()
    if min(args.steps, args.threads, args.batch_size, args.rank) < 1 or args.sequence_length < 24:
        parser.error('Use positive steps, threads, batch size, and rank, and at least 24 tokens per example')
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    torch.manual_seed(args.seed)
    rng = random.Random(args.seed)
    dtype = torch.bfloat16 if args.bf16 else torch.float32
    work = args.work_dir.resolve()
    base, output = work / 'base', work / 'trained'
    if output.exists():
        raise FileExistsError(f'Use a new work directory or move the existing checkpoint at {output}')
    for name in BASE_FILES:
        download(f'https://huggingface.co/{BASE}/resolve/{BASE_REVISION}/{name}', base / name)
    tokenizer = AutoTokenizer.from_pretrained(base, local_files_only=True)
    train, validation, sources, data_sha = prepare(work, tokenizer, args.seed, args.sequence_length)
    tokenizer.pad_token = tokenizer.eos_token
    pad = tokenizer.pad_token_id
    calibration = [tokens for tokens in train if len(tokens) == args.sequence_length][:48]
    if not calibration:
        raise ValueError('No full-length calibration windows. Choose a shorter sequence length.')
    backbone = prune(base, args.width, calibration, args.sequence_length, pad, dtype)
    base_parameters = sum(parameter.numel() for parameter in backbone.parameters())
    model = get_peft_model(backbone, LoraConfig(
        task_type='CAUSAL_LM', r=args.rank, lora_alpha=2 * args.rank, lora_dropout=0.05,
        target_modules=['q_proj', 'v_proj', 'o_proj', 'up_proj', 'down_proj'], bias='none',
    ))
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    targets = sum(parameter.numel() for parameter in trainable)
    baseline = evaluate(model, validation, args.sequence_length, pad, args.batch_size, dtype)
    print(f'Pruned weights: {base_parameters:,}; training {targets:,} LoRA weights. Held-out loss before: {baseline:.4f}', flush=True)
    optimizer = torch.optim.AdamW(trainable, lr=3e-4, weight_decay=0.01)
    steps = args.steps
    warmup = min(15, max(1, steps // 10))
    schedule = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda tick:
        min(1, (tick + 1) / warmup) * max(0.15, 1 - max(0, tick - warmup) / steps))
    losses = []
    tokens_seen = 0
    order = list(range(len(train)))
    offset = len(order)
    started = time.monotonic()
    model.train()
    for step in range(1, steps + 1):
        if offset + args.batch_size > len(order):
            rng.shuffle(order)
            offset = 0
        windows = [train[index] for index in order[offset:offset + args.batch_size]]
        offset += args.batch_size
        tokens_seen += sum(map(len, windows))
        inputs, labels = make_batch(windows, args.sequence_length, pad)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast('cpu', dtype=torch.bfloat16, enabled=dtype == torch.bfloat16):
            loss = model(input_ids=inputs, labels=labels, use_cache=False).loss
        loss.backward()
        torch.nn.utils.clip_grad_norm_(trainable, max_norm=1.0, error_if_nonfinite=True)
        optimizer.step()
        schedule.step()
        losses.append(loss.item())
        if step == 1 or step % 20 == 0 or step == steps:
            print(f'{step}/{steps} mean loss {sum(losses[-20:]) / len(losses[-20:]):.4f}, '
                  f'{time.monotonic() - started:.1f}s', flush=True)

    adapted = evaluate(model, validation, args.sequence_length, pad, args.batch_size, dtype)
    adapter, merged = output / 'adapter', output / 'merged'
    model.peft_config['default'].base_model_name_or_path = BASE
    model.peft_config['default'].revision = BASE_REVISION
    model.save_pretrained(adapter, safe_serialization=True, save_embedding_layers=False)
    # Merge in FP32 so small LoRA deltas survive before GGUF quantization.
    merged_model = model.float().merge_and_unload(safe_merge=True)
    merged_model.config.use_cache = True
    merged_model.save_pretrained(merged, safe_serialization=True)
    tokenizer.save_pretrained(merged)
    # The adapter is reusable against this script's pruned base, not the full
    # upstream checkpoint. Preserve the exact base configuration separately.
    shutil.copyfile(merged / 'config.json', output / 'pruned-config.json')
    metrics = {
        'base': BASE, 'base_revision': BASE_REVISION, 'base_weights_sha256': sha256(base / 'model.safetensors'),
        'dataset': DATASET, 'dataset_revision': DATASET_REVISION, 'dataset_shard': DATASET_SHARD,
        'dataset_shard_sha256': data_sha, 'windows_by_split_and_source': sources,
        'device': 'cpu', 'dtype': str(dtype), 'torch': torch.__version__,
        'steps': steps, 'batch_size': args.batch_size, 'sequence_length': args.sequence_length,
        'seed': args.seed, 'threads': args.threads, 'tokens_seen': tokens_seen,
        'intermediate_size': args.width, 'pruned_parameters': base_parameters,
        'calibration_windows': len(calibration),
        'lora_rank': args.rank, 'lora_parameters': targets,
        'held_out_windows': len(validation), 'held_out_loss_pruned': baseline, 'held_out_loss_adapted': adapted,
        'last_20_train_loss': sum(losses[-20:]) / len(losses[-20:]),
        'optimization_seconds': round(time.monotonic() - started, 1),
    }
    (output / 'training.json').write_text(json.dumps(metrics, indent=2) + '\n', encoding='utf-8')
    print(f'Held-out loss after: {adapted:.4f}. Artifacts: {output}', flush=True)


if __name__ == '__main__':
    main()
