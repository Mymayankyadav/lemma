#!/usr/bin/env python3
"""Export the merged CPU-trained proof model and enforce a 100 MB GGUF budget."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


ENGINE_REVISION = '3d4e86bbeb15f487d6da6174ba6191b7c212cc25'
BUDGET_BYTES = 100_000_000


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work-dir', required=True, type=Path)
    parser.add_argument('--llama', required=True, type=Path, help='llama.cpp b6789 checkout')
    parser.add_argument('--quantizer', required=True, type=Path, help='Built llama-quantize binary')
    args = parser.parse_args()
    llama = args.llama.resolve()
    revision = subprocess.check_output(['git', '-C', llama, 'rev-parse', 'HEAD'], text=True).strip()
    if revision != ENGINE_REVISION:
        parser.error(f'Expected llama.cpp {ENGINE_REVISION}, got {revision}')

    output = args.work_dir.resolve() / 'trained'
    temporary = output / 'lemma-proof-assist.f16.gguf'
    quantized = output / 'lemma-proof-assist.gguf.part'
    final = output / 'lemma-proof-assist.gguf'
    try:
        subprocess.run([sys.executable, str(llama / 'convert_hf_to_gguf.py'), str(output / 'merged'),
                        '--outfile', str(temporary), '--outtype', 'f16', '--model-name', 'Lemma Proof Assist'],
                       check=True)
        subprocess.run([str(args.quantizer.resolve()), '--pure', str(temporary), str(quantized), 'Q4_0', '3'],
                       check=True)
        size = quantized.stat().st_size
        if size > BUDGET_BYTES:
            raise ValueError(f'GGUF is {size:,} bytes, exceeding the {BUDGET_BYTES:,}-byte model budget')
        with quantized.open('rb') as stream:
            if stream.read(4) != b'GGUF':
                raise ValueError('Quantizer output was not a GGUF file')
            stream.seek(0)
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        quantized.replace(final)
        (output / 'export.json').write_text(json.dumps({
            'file': final.name, 'size_bytes': size, 'sha256': digest, 'format': 'GGUF',
            'quantization': 'Q4_0', 'llama_cpp_revision': revision,
        }, indent=2) + '\n', encoding='utf-8')
        print(f'{final}: {size:,} bytes, SHA-256 {digest}')
    finally:
        temporary.unlink(missing_ok=True)
        quantized.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
