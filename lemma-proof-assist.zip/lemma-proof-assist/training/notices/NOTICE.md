# Lemma Proof Assist notices

Lemma Proof Assist modifies **SmolLM2-135M** by Hugging Face. The changes are activation-calibrated feed-forward pruning, a CPU-trained and merged LoRA, and GGUF Q4_0 quantization. The upstream model card declares Apache License 2.0. [Upstream model and license declaration](https://huggingface.co/HuggingFaceTB/SmolLM2-135M/tree/93efa2f097d58c2a74874c7e644dbc9b0cee75a2)

Training and validation windows come from the first training shard of **NuminaMath-CoT** by Project Numina. The source dataset card declares Apache License 2.0. The training script normalizes whitespace, selects proof-writing passages, tokenizes them, and holds out deduplicated passages for evaluation. [Dataset card, license and authors](https://huggingface.co/datasets/project-numina/NuminaMath-CoT/tree/9d8d210c9f6a36c8f3cd84045668c9b7800ef517)

The Android preview links **llama.cpp** and its GGML backend. The pinned engine checkout includes the MIT license. [Pinned engine source and license](https://github.com/ggml-org/llama.cpp/tree/3d4e86bbeb15f487d6da6174ba6191b7c212cc25)
