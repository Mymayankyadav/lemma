# Lemma Proof Assist LoRA adapter

The 8-rank adapter targets the query, value, attention output, feed-forward up and feed-forward down projections. Recreate the 1,408-channel base with the pinned model, dataset and activation calibration in `training/train.py`. Its down and up projections have the dimensions in `model/pruned-config.json`. The bundled GGUF already contains the adapter merged into the model.
