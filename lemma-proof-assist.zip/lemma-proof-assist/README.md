# Lemma Proof Assist

The Android preview uses Lemma’s existing faded-text suggestion and Undo controls in the Tutor composer. Open a checkpoint’s Tutor, choose **Write a question**, and type `We need to` or `Let $A \sub` with the answer editor focused. Pause briefly, then tap the suggestion or swipe right to accept it. The example workspace starts in Balanced mode. **Settings → Tutor → Writing aid** controls Balanced, Faster typing and Faded continuations.

The model ranks short proof phrases and unfinished LaTeX commands from Lemma’s symbol catalog. A temperature of 0.85 varies the order. Lemma leaves the mathematical statement and its verification to the learner. Only recent text typed in the answer editor reaches the scorer. The Android runtime loads a bundled GGUF on the CPU and works in airplane mode.

## Bundle contents

- `model/lemma-proof-assist.gguf` contains the merged and quantized model and tokenizer.
- `model/adapter/` contains the rank-8 PEFT adapter for the calibrated, pruned base reconstructed by `train.py`.
- `model/training.json`, `model/pruned-config.json` and `model/export.json` record the data, architecture, run and output hash.
- `lemma-android.patch` adds the Android runtime, the Tutor integration and the build scripts to the pinned Lemma revision.
- `training/` contains standalone CPU training and export scripts, pinned requirements and third-party license notices.

Run `sha256sum -c SHA256SUMS` from the extracted bundle to verify the files.

## Build the Android preview

Use Node.js 22+, JDK 21, Android platform 36, SDK Build Tools 35.0.0 and 36.0.0, NDK 28.2.13676358 and Android CMake 3.22.1. Set `ANDROID_HOME` to the SDK directory. The preview supports `arm64-v8a` and `x86_64` on Android 7 and later.

```sh
proof_bundle=/absolute/path/to/extracted/lemma-proof-assist
git init lemma
git -C lemma fetch --depth 1 https://github.com/Mymayankyadav/lemma.git ec64431e013de651feb066c8d51fdb859d6f797f
git -C lemma checkout --detach FETCH_HEAD
git -C lemma apply --check "$proof_bundle/lemma-android.patch"
git -C lemma apply "$proof_bundle/lemma-android.patch"
git clone --depth 1 --branch b6789 https://github.com/ggml-org/llama.cpp.git
export LEMMA_LLAMA_CPP="$PWD/llama.cpp"
export LEMMA_PROOF_ASSIST_MODEL="$proof_bundle/model/lemma-proof-assist.gguf"
cd lemma
npm ci
node scripts/android-writing-aid-demo.mjs "$proof_bundle/Lemma-Proof-Assist.apk"
```

The demo APK installs alongside the Lemma release and opens the example workspace. To build the usual Lemma Android app with this feature, run `VITE_ANDROID_PROOF_ASSIST=1 npm run build:android` with the same two model and engine environment variables, then run `./gradlew assembleDebug` inside `android/`. Existing release signing applies when building the signed release.

## Rebuild the model on CPU

Use Linux x86_64, Python 3.12, Git and a C/C++ toolchain. These commands use the extracted bundle and the pinned llama.cpp checkout from the Android build steps. Training downloads roughly 516 MB of pinned public weights and math data, and the work directory needs room for the intermediate FP32 and FP16 checkpoints.

```sh
proof_work=/absolute/path/to/proof-assist-work
mkdir -p "$proof_work"
python3.12 -m venv "$proof_work/venv"
proof_bin="$proof_work/venv/bin"
"$proof_bin/python" -m pip install -r "$proof_bundle/training/requirements.txt"
"$proof_bin/python" "$proof_bundle/training/train.py" --work-dir "$proof_work"
"$proof_bin/cmake" -S "$LEMMA_LLAMA_CPP" -B "$proof_work/llama-build" -G Ninja \
  -DCMAKE_MAKE_PROGRAM="$proof_bin/ninja" -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_SHARED_LIBS=OFF -DLLAMA_CURL=OFF -DLLAMA_BUILD_TESTS=OFF \
  -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_SERVER=OFF
"$proof_bin/cmake" --build "$proof_work/llama-build" --target llama-quantize -j 3
"$proof_bin/python" "$proof_bundle/training/export_model.py" --work-dir "$proof_work" \
  --llama "$LEMMA_LLAMA_CPP" --quantizer "$proof_work/llama-build/bin/llama-quantize"
```

The export writes `trained/lemma-proof-assist.gguf` and enforces a 100,000,000-byte maximum. The released run kept 1,408 of 1,536 feed-forward channels per layer using activation measurements on 48 training windows. Rank-8 LoRA trained for 280 CPU steps over 53,409 input tokens. Loss on 96 held-out proof-text windows went from 2.1396 to 1.7893 before quantization. The underlying data and checkpoint are publicly available. [NuminaMath-CoT](https://huggingface.co/datasets/project-numina/NuminaMath-CoT) · [SmolLM2-135M](https://huggingface.co/HuggingFaceTB/SmolLM2-135M)

## Run the native benchmark

From the patched Lemma checkout, build the same C++ scorer for your host. The benchmark exercises phrase and symbol choices, sampling, cancellation and warm request timing. Android timing depends on the phone’s CPU, storage and load.

```sh
cmake -S android/app/src/main/cpp/proofassist -B "$proof_work/benchmark" \
  -DCMAKE_BUILD_TYPE=Release -DLLAMA_SOURCE="$LEMMA_LLAMA_CPP"
cmake --build "$proof_work/benchmark" --target lemma-proof-assist-bench -j 3
"$proof_work/benchmark/lemma-proof-assist-bench" "$LEMMA_PROOF_ASSIST_MODEL"
```
