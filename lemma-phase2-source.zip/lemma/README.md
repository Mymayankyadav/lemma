# Lemma — mathematics learning and memory

Lemma is an offline-first mathematics flashcard app being expanded into a **model-independent learning system**: mathematical sources, study plans, proof attempts, tutoring handoffs and FSRS-6 review history will be stored independently of Claude, ChatGPT or any other chatbot.

**Development status (2026-10-26): Phase 1 packaging source prepared; Supabase authentication/sync, connectors, source library and Android native runtime are future phases.** Do not assume the app syncs merely because the project has a Supabase key.

## Start here

- [Detailed phased roadmap](docs/ROADMAP.md)
- [GitHub, Supabase and Android setup](docs/SETUP.md)
- [Existing note/profile data model](docs/DATA_MODEL.md)
- [SQL draft for a NEW Lemma Supabase project](supabase/schema.sql)

## Already present in the original app

- Notes/cards editor, browser, statistics, graph and daily reviews.
- Markdown + KaTeX mathematics, theorem/definition/proof blocks, cloze questions, proof-step reveal, linked prerequisites.
- FSRS-6 review scheduler, simulator and optimizer; IndexedDB fallback.
- Import and export to Lemma Markdown, JSON, Anki text and common tabular formats.

## Phase 1 source changes

- One browser/Capacitor HTML build with local JS/CSS/fonts, plus offline-capable PWA shell.
- `capacitor.config.json` with the same built `dist/index.html` as GitHub Pages.
- GitHub Pages workflow and gated Android debug build workflow.
- Pinned Supabase SDK dependency and public build config **only**; cloud connection still requires Phase 2 implementation.
- Small tested merge helper for existing JSON note format, with final concurrent review correctness deferred to immutable review event replay.

## Commands

```bash
npm install                         # requires network; generates package-lock.json
npx playwright install chromium
npm run build                     # dist/index.html, lemma.html, PWA assets
npm run test:merge                # can run without installed dependencies
npm test                         # FSRS, renderer and browser E2E
npm run android:add               # once; commit generated native Android project
npm run android:sync              # after each web build before native packaging
```

Node.js 22+ and the Capacitor 8 Android tooling are needed. **Commit the generated package-lock.json**. No service-role key ever belongs in the frontend.
