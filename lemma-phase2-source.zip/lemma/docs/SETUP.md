# Owner setup checklist — Lemma

This is the handoff from the prepared source archive. **Do not use the existing Carrel Supabase database.**

## A. GitHub: create repository

1. Create a new private repository named `lemma` (you may make it public later if desired). Leave it empty: no generated README, license, or `.gitignore`.
2. Extract the **contents of the `lemma/` folder** from the delivered ZIP into the repository root. `package.json` should be directly in the root.
3. On a laptop or development environment with Node.js 22 or newer:

```bash
npm install
npx playwright install chromium
npm run test:merge
npm test
npm run build
```

`npm install` creates `package-lock.json` (the build environment used to prepare the archive could not fetch npm packages). **Commit the lockfile**. Before the first production release, replace workflow `npm install` with `npm ci` for reproducibility.

4. Commit and push:

```bash
git init -b main
git add .
git commit -m "Initialize Lemma portable study platform (phase 1)"
git remote add origin https://github.com/<owner>/lemma.git
git push -u origin main
```

5. GitHub → repository Settings → Pages → Build and deployment → GitHub Actions. The `Deploy web app to GitHub Pages` action then publishes `https://<owner>.github.io/lemma/`.

## B. Supabase: create a DIFFERENT project

1. Dashboard → New project. Name: `lemma`; choose an organization and strong database password; choose **Mumbai / ap-south-1** if suitable.
2. Once ready, copy **Project URL** and **publishable key** from Connect / API settings. Never place `service_role` or other secret keys in GitHub repo variables or frontend code.
3. In the GitHub repository → Settings → Secrets and variables → Actions → Variables, create:

```
SUPABASE_URL               = https://<project-ref>.supabase.co
SUPABASE_PUBLISHABLE_KEY   = sb_publishable_...
```

4. In Supabase → Authentication → URL Configuration, set the **Site URL** and allow redirect URL to your actual GitHub Pages address once known (including `/<repo>/`).
5. Enable Email authentication/OTP. Default Supabase emails are rate-limited for experimentation; production needs correctly configured SMTP and verified sender.
6. **Before running SQL:** review `supabase/schema.sql` and the Phase 2 plan. The schema is a prepared migration, but app-side auth/sync isn't wired in Phase 1. Apply it to the new Lemma project only when starting Phase 2 and testing RLS.
7. Optional: Enable Google OAuth after you have a valid web redirect flow. Android deep linking is handled in a separate phase.

## C. Android: after npm install

1. Install Android Studio, Android SDK and a supported Java version, as required by Capacitor 8.
2. Run `npm run android:add` once. This creates the native `android/` directory.
3. Commit the native Android project (excluding `local.properties`, `.gradle`, APKs and signing keys). Avoid changing the `appId` after distributing a signed app.
4. Run `npm run android:sync`, then `npm run android:open` for Android Studio.
5. Build a debug APK and install on a real device. After committing `android/`, the `Android debug APK` GitHub workflow can run its build and upload an artifact.

**Current limitation:** Android is scaffolded but no native project or verified APK is inside the first source ZIP. Debug APK workflow deliberately skips compilation until `android/gradlew` is present.

## D. What to tell the development assistant next

Provide only the **GitHub repository URL** and **the new Lemma Supabase project ID** (not passwords or secrets). Ask it to begin `ROADMAP.md` Phase 2: Supabase auth, offline outbox, two-device synchronization and RLS tests.

## E. Data safety

- Keep exports/backups of your existing flashcards before turning on cloud migration.
- Sign-in must be optional and anonymous cards must remain intact until you explicitly migrate them.
- Do not use a secret key in source or CI web build arguments.
- Data sync is **not** yet operational in Phase 1; a configured URL/key alone do not turn on sync.
