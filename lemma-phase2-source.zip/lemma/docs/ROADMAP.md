# Lemma — phased engineering plan

**Project:** Lemma, a persistent mathematics learning environment, independent of the currently available LLM.
**Targets:** GitHub Pages PWA and Capacitor Android app from **one source tree**, with Supabase as shared backend.
**Primary principle:** The student's progress, proof attempts, memory and plan belong to Lemma, not to Claude or ChatGPT.
**Baseline:** Source archive dated 2026-10-26, version 0.4.0. Preserve the FSRS-6 engine, mathematical render pipeline, and existing cards.
**Status on 2026-10-26:** Phase 1 source changes and initial merge tests prepared; cloud and APK not yet validated. No live Supabase project has been modified.

## Product outcomes

1. A student can use Lemma entirely offline to read cards, solve proofs and review on Android or the web.
2. Once authenticated, changes made on one device reach Supabase promptly and appear on another open device through realtime events; changes made offline are durably queued and reconciled upon reconnection.
3. Books, typed or scanned class notes, study plans, mathematical questions, written proof attempts, hints and mastery evidence are persisted independently of a particular assistant.
4. Claude and ChatGPT can request an identical, compact learning-context packet and resume from the **current intellectual stopping point** without uploading the whole book or restating the conversation.
5. The tutor does not simply present proofs; it makes the student produce the core mathematical reasoning, with progressively more informative hints when appropriate.
6. Flashcards track concepts, prerequisites, source citations, and review events, without corrupting FSRS scheduling history.
7. A fully automated pipeline publishes the website and, after native scaffolding is committed, builds a debug Android APK. Release APKs use a secured signing process.

## Principles and non-goals

- Keep the existing framework-free JavaScript architecture and `Store` contract until a measured reason requires changing them.
- Preserve `src/fsrs.js` and `src/render.js`; do not casually substitute a different spaced-repetition algorithm.
- Treat **local confirmed writes as durable** before showing them as saved; background sync must be retriable.
- App actions are idempotent and user-scoped; no model receives a Supabase service-role key.
- A summary is a convenient handoff, **not** the canonical record. Preserve append-only student attempts/review events and stable source references.
- Do not save hidden model reasoning as a learning record. Save the student's visible attempt, visible tutoring feedback, evidence of understanding, and a short next-step instruction.
- Don't ingest entire copyrighted books into publicly accessible tables or automatically publish their text. Source documents remain private to the account.
- Avoid premature multi-agent infrastructure, a custom native UI rewrite, or complex vector-search deployment before the continuity experiment works.

## Phase 0 — Archive assessment and baseline [DONE]

- Audited the existing scripts and store interface, Claude-specific storage, UI, schema draft, and E2E harness.
- Identified what is reusable: existing cards, math notation, FSRS optimizer, editor, graph, import/export, IndexedDB.
- Identified missing pieces: portable sync/auth, per-user cloud cache, source ingestion, learning-event protocol, cross-chat connector, proper PWA/Android packaging.

**Exit:** Documented architecture and existing code constraints.

## Phase 1 — Single-codebase web and Android packaging [CODE PREPARED; FULL VALIDATION BLOCKED]

Code delivered:

- Complete HTML document in `src/index.html`; Capacitor requires a `<head>` and output `index.html`.
- Bundle KaTeX, marked, DOMPurify and `supabase-js` into the same HTML output, removing runtime CDNs (Google Fonts gracefully falls back).
- `src/config.js` holds public build configuration; environment variables are injected into the build.
- `dist/index.html` plus backwards-compatible `dist/lemma.html` and `dist/test.html` outputs.
- PWA manifest, versioned service-worker app-shell cache, and placeholder app icon.
- GitHub Pages workflow publishes only the app and necessary PWA assets.
- `capacitor.config.json` declares Android project identity and web directory.
- Android debug CI pipeline (only runs its build after the native Android project has been generated and committed).
- Isolated `SyncMerge` utility and initial Node regression tests.

Still to verify on a network-enabled machine:

- Run `npm install` to download pinned dependencies and generate/commit `package-lock.json`.
- Run `npx playwright install chromium`, `npm test`, `npm run build` and a smoke test in a browser.
- Install Android Studio/SDK, run `npm run android:add`, commit native project, run `npm run android:sync`, build debug APK and test on a real phone.
- Check browser app installs/loads offline after a successful first visit.

**Exit criteria:** Web builds and deploys; local-only cards remain usable offline; Android app opens and shows the same screens and cards. No cloud-account claims yet.

**Recommended model:** Sonnet Medium for most scripts; Sonnet High for Capacitor troubleshooting.

## Phase 2 — Supabase authentication, offline-first sync and correctness [NEXT]

### 2.1 Account bootstrap

- Create a **new** Supabase project named `lemma` (do not reuse the Carrel project).
- Review `supabase/schema.sql` and apply it only to the new project after integration test database smoke checks.
- Enable email OTP as the default sign-in, plus optional Google OAuth; support link and code verification.
- Account creation must not be required for first use. Add “Sign in to sync” from Settings and sync indicator.
- Set site URL and web redirect URL for `https://<username>.github.io/<repo>/`.
- Later handle native auth callback using Capacitor App URL listeners. Do not assume browser redirects work identically inside Android.
- Use a **publishable** key in JS, never the secret/service-role key. Protect user data through RLS and test cross-account isolation.

### 2.2 Device-local durability

- Use separate IndexedDB namespaces for anonymous data and authenticated users to prevent one user reading another's cached notes.
- Make a write + outbox insertion a single IndexedDB transaction.
- Outbox item contains `operationId`, table/type, record ID, base revision, payload, device ID, client time, and retry state.
- Deduplicate by stable operation ID; coalesce content edits safely but **never discard review events**.
- Show three distinct statuses: saved on device / uploading / verified in cloud; no false success indication.
- Retry with exponential backoff and jitter; wake upon network recovery, page visibility, app resume and auth refresh.
- On initial sign-in, offer a previewed import of local-only notes. Never silently overwrite cloud data; clear anonymous local records only after acknowledgement and cloud verification.

### 2.3 Server reconciliation

- Paginated initial snapshot and incremental pull with a resumable server cursor or overlapping timestamp range with deduplication; do not trust device clocks for server ordering.
- Realtime event subscription scoped to the authenticated user. On reconnect always run a delta pull because realtime messages are not a guaranteed durable event log.
- Use optimistic concurrency controls / expected revisions for note text to prevent a stale client overwriting a newer edit.
- Text-field conflict: merge independent fields, or surface a user-visible conflict for simultaneous changes to the same field. Never silently destroy prose or LaTeX.
- Preserve delete tombstones, including a clear delete-vs-offline-edit policy (prefer conflict display or safe recovery over data loss).
- **Review history must be immutable, per-event and idempotent**: first migrate `notes.log` entries, then replay the ordered canonical `review_events` to compute the FSRS card state. Merely selecting the last card state can lose earlier concurrent reviews.
- Validate against two browsers and Android in airplane mode, including changes after account logout/login and crashes while syncing.
- Implement media migration for oversized data URLs into a private Supabase Storage bucket with owner-scoped policies.

**Exit criteria:** On two devices, reviews, notes, due counts and deletions reconcile; no lost review despite simultaneous edits; user B cannot read or write user A's data. Power loss and offline cases recover from the outbox.

**Recommended model:** Opus High to review concurrency design; Sonnet High for implementation; Opus High for a final data-loss audit.

## Phase 3 — Mathematical sources and a plan/progress model

- Private library of books, lecture notes, scanned pages, paper references and user-entered topics.
- Each source has stable ID, title, edition, citation, chapter/section/page locator, and (if uploaded) private storage path.
- Extraction pipeline: preserve mathematics, equation labels, theorem boundaries and diagrams as needed. OCR is a fallback for scanned pages; detect errors and permit user correction.
- Context retrieval should return small **cited** slices by section/lemma/prerequisites. Never feed the entire book per request by default.
- Store versioned study plans (`study_plans`) with objectives, ordered topics, prerequisite relations, problem sets and evidence criteria.
- Store live session objective and a separate history of `learning_events`: attempt, hint, feedback, misconception, proof step, mastery evidence and source read.
- Maintain a short materialized progress view derived from events. Separate “covered”, “recognised”, “can explain”, and “can prove independently”.
- Add UI tabs or sections for Library, Learning Plan, Study Session and linked Flashcards; make reading comfortable on a phone or while reclining.

**Exit criteria:** Given a named theorem and a known page, Lemma provides exact source/citation and reliably resumes a partially completed learning plan.

**Recommended model:** Sonnet High for implementation; Opus High for learning-data architecture and math content validation.

## Phase 4 — Cross-model connector and handoff protocol [CRITICAL PRODUCT MILESTONE]

Expose a versioned, narrow API via an authenticated adapter/MCP server (subject to the connector mechanisms supported by each chatbot):

| Tool | Purpose | Safety/consistency |
|---|---|---|
| `get_learning_context(session_id)` | Short objective, source locators, plan progress, last attempts and next tutor instruction | Read-only, size-limited |
| `get_source_material(source_id, locators)` | Relevant textbook/notes snippets with stable citations | Read-only, explicitly scoped |
| `append_learning_event(session_id, event)` | Save attempt, hint used, feedback, misconception etc. | Idempotent `event_id` |
| `update_learning_plan(plan_id, patch, revision)` | Update mastery evidence and next planned topics | Revision checked; no blind overwrites |
| `manage_lemma_cards(action, payload)` | Create/update linked cards via existing model contracts | Stable IDs, provenance; never overwrite review state |
| `save_tutor_handoff(session_id, summary, revision)` | Store current proof state for transfer between models | Revision checked; short and explicit |

Handoff packet schema:

```json
{
  "session_id": "uuid",
  "plan_id": "uuid",
  "topic": "Quotient topology",
  "current_question": "Are all quotient maps open?",
  "student_attempt": "Student incorrectly applied inverse-image criterion to forward images.",
  "feedback_given": "Explained the direction of the quotient topology condition.",
  "unresolved_question": "Construct a counterexample without revealing it yet.",
  "hint_level": 1,
  "source_refs": [{"source_id":"uuid", "locator":"Chapter 2, Section 4"}],
  "next_tutor_action": "Ask student to test a concrete quotient map.",
  "updated_at": "ISO-8601"
}
```

- Provide one read-only context action to start a session and one explicit action to save progress before handoff.
- The student's typed proof attempt is saved verbatim in events; a brief handoff summarizes, not replaces, it.
- Tokens scoped to the user and least privileges; never expose project-admin SQL tools as a public tutoring API.
- Model-specific configuration/instructions reside in adapters, not in the canonical database.
- On connection failure, fall back to local draft events and sync later; never report a remote save that did not happen.

**Key acceptance demonstration:** Start a proof discussion in Claude, switch mid-attempt, connect ChatGPT, retrieve the same source and last student attempt, give the **next hint** rather than the solution, then save subsequent progress. Reversing the direction must work too.

**Recommended model:** Opus High for connector/security review, Sonnet High for MCP/HTTP implementation.

## Phase 5 — Mathematical tutor protocol and study experience

1. Tutor first checks the student's existing knowledge and statement comprehension.
2. Present a precise task: state a definition, predict a counterexample, prove a lemma, or identify a missing proof step.
3. Require an attempt before a full solution (except explicit user request or genuine inability after hints).
4. Offer graded hints: structural, targeted, then near-complete. Track hint usage.
5. Validate quantifiers, hypotheses, hidden assumptions and edge cases; do not conflate plausible argument with proof.
6. Ask the student to reconstruct core arguments unaided before awarding proof mastery.
7. Capture misconceptions and source-linked durable notes for retrieval practice.
8. Maintain a portable system prompt/protocol version across Claude, ChatGPT and later agents.

**Exit criteria:** Different models behave consistently as active-learning tutors; mastery rises from demonstrated proof ability, not message count.

## Phase 6 — Flashcard integration and spaced-repetition intelligence

- Preserve existing types: basic/reverse/cloze, proof steps, theorem/proof blocks, prerequisites and KaTeX.
- Every generated card has source citations, target skill and optional linked misconception/session.
- Detect duplicates and near-duplicates; avoid gratuitous atomic cards that fail to test meaningful mathematics.
- FSRS scheduling derived from immutable reviews; surface due counts offline and reconcile after sync.
- Allow manual card editing and rejection; an assistant's card creation is a proposed action, not a silent mutation.
- Support different recall prompts: definition accuracy, counterexample recognition, theorem hypotheses, proof skeleton, reconstruction, and example/nonexample tests.

**Exit criteria:** Cards generated in either chatbot appear in both apps with stable scheduling history; no double-counting and no lost reviews.

## Phase 7 — Native Android and polished app experience

- Build and commit the Android project (`npm run android:add`), native URL handling, Android back button, insets, status/nav bar styling, IME resize and tactile interactions.
- Support unobtrusive local notifications for due reviews (permission asked contextually), not a persistent annoying notification.
- Native share/open-file support for importing PDFs and other lecture material.
- Background sync within Android platform limits; foreground-on-resume catch-up always works. Do not claim realtime delivery when Android suspends the process.
- Publish debug APK through Actions; release signed APK/AAB via protected CI secrets and versioned releases.
- Because the app ships bundled assets, GitHub Pages changes are **not automatically installed** in the APK. Each native update requires a new APK unless a later vetted live-update solution is introduced.

**Exit criteria:** Works offline on physical Android, deep links and keyboard/back navigation work, durable sync after app resume, no surprise notification spam.

## Phase 8 — Reliability, backup, privacy and performance

- Full export (raw source refs, plans, sessions, events, cards, FSRS logs, attachments manifest) plus tested restore.
- RLS and cross-user leakage tests, audit all functions and storage policies.
- Crash/restart, clock-skew, schema migration, high-volume/large-media, and simultaneous edit stress tests.
- Multi-device tests run in CI using local Supabase for reproducibility; smoke tests against staged cloud project before release.
- Measure saved bytes, sync latency, failure rate, problem-solving progression and token usage per learning session.
- Rollbacks and versioned schema migrations, no destructive rollout without backups.

**Release gate:** 0 observed missing review events in fault-injection tests; private data isolated by owner; Claude↔ChatGPT handoffs pass acceptance scenario; no essential workflow depends on a single LLM's quota.

## Ordering / control

Implement in the above order. Use small PRs: (1) packaging, (2) auth+outbox, (3) synchronization/review ledger, (4) sources/plans, (5) connectors, (6) tutor mode, (7) Android polish. Do not mark a phase complete because code compiles; its exit criteria must be tested.

### Current blockers

- Environment for this package could not reach the npm registry, so `npm install`, the full bundle, Playwright E2E, and Android compilation were not executed here.
- A new Lemma Supabase project and GitHub repository do not exist in this workspace yet; no cloud migration has been applied.
- Native Android project (`android/`) has not been generated because Capacitor dependencies could not be downloaded here.

## 2026-10-26 Implementation amendment

- Supabase backend migrations now deployed: initial planning, versioned study context, cards/reviews/sources, plan CAS, note CAS, secured RPC wrappers.
- Browser-side outbox processor and account-isolated adapter created in `src/app/outbox_core.js`, `src/app/sync_browser.js` and their tests.
- Application UI is *not yet connected* to cloud transport. No cross-device or Claude↔ChatGPT live handoff claim.
- Track further work in `docs/PHASE2_SYNC_CONTRACT.md` and the GitHub development roadmap.
