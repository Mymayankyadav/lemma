import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
export const root=fileURLToPath(new URL('../',import.meta.url));
export const file=p=>fs.readFileSync(root+p,'utf8');
export const read=p=>JSON.parse(file(p));
export const write=(p,data)=>fs.writeFileSync(root+p,JSON.stringify(data,null,2)+'\n');
export const sha=p=>createHash('sha256').update(fs.readFileSync(root+p)).digest('hex');
export const assets={phrases:read('engine/legacy/runtime-phrases.json'),veto:read('engine/legacy/runtime-veto.json'),policy:read('engine/legacy/policy.json'),words:file('engine/wordlist.txt'),wordAssets:read('engine/word-assets.json'),ranks:read('engine/math-ranks.json')};
export const tokens=s=>[...s.matchAll(/[\p{L}\p{N}_]+(?:['’][\p{L}\p{N}_]+)*/gu)];
export const quantile=(ns,p)=>{if(!ns.length)return null;const x=[...ns].sort((a,b)=>a-b); const q=(x.length-1)*p,i=Math.floor(q);return x[i]+(x[Math.min(i+1,x.length-1)]-x[i])*(q-i);};
export function randomAt(key){let h=2166136261;for(const c of key)h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return ((h^(h>>>16))>>>0)/4294967296;}
