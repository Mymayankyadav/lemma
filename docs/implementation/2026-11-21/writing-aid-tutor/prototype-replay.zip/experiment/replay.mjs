import {shortcuts} from '../engine/shortcuts.mjs';
import {tokens,randomAt} from './common.mjs';

const tokenChar=/[\p{L}\p{M}\p{N}_'’]/u;
const substantive=/[\p{L}\p{M}\p{N}]/u;
const smartPunct=/^[.,;:!?)\]]$/u;
const knownChords=Object.entries(shortcuts).flatMap(([code,v])=>{
  const capital=v[0].toUpperCase()+v.slice(1);
  return [[code,v],...(capital!==v?[[code[0].toUpperCase()+code.slice(1),capital]]:[])];
});

function wordAt(target,p,word) {
  let start=p;
  while(start>0 && tokenChar.test(target[start-1]))start--;
  if(!target.startsWith(word,start) || start+word.length<=p ||
     tokenChar.test(target[start+word.length]||''))return null;
  const end=start+word.length, autoSpace=target[end]===' ';
  return {end:end+Number(autoSpace),extra:!autoSpace && (end===target.length || !smartPunct.test(target[end]))?1:0,
          punct:!autoSpace && end<target.length && smartPunct.test(target[end])};
}
function matchingWords(target,p,offered){
  const out=[];
  for(const [rank,k] of offered.entries()){
    const m=wordAt(target,p,k.word);
    if(m)out.push({...m,rank:rank+1,kind:k.kind||'legacy',surface:'keys'});
  }
  return out;
}
function commandAt(text,target,p) {
  if(text && !/\s$/u.test(text))return null;
  const rest=target.slice(p);
  let best=null;
  for(const [code,value] of knownChords){
    if(rest.startsWith(value)&&!tokenChar.test(rest[value.length]||'')){
      const gain=value.length-code.length-1;
      if(gain>0 && (!best || gain>best.gain))best={end:p+value.length,typed:code.length+1,gain,
        label:';'+code,kind:'explicit-shortcut',surface:'shortcut',extra:0};
    }
  }
  return best;
}
export function memoizePredict(system,mode){
  const memo=new Map();
  return (text,anchor,surface)=>{
    const key=surface+'|'+anchor.length+'|'+text;
    if(!memo.has(key))memo.set(key,system.predict(text,{surface,origin:'learner',authoredText:anchor,mode}));
    return memo.get(key);
  };
}
const baseCost={charMs:400,tapMs:250,scanMs:75,missMs:0,used:1,keysReadyMs:110,ghostReadyMs:230,allowKeys:true,allowGhost:true,allowChords:false};
export function simulate(row,predict,opts={}){
  const cfg={...baseCost,...opts}, target=row.target, start=row.initial;
  const stats={id:row.id,chars:target.length,baselineMs:target.length*cfg.charMs,ms:0,typed:0,extra:0,taps:0,
    newLists:0,unusedLists:0,ignoredExact:0,savedMs:0,savingsByLane:{},tapsByLane:{},keyRanks:[0,0,0]};
  let p=0,anchor=start,punctuationNext=false,prevList='';
  while(p<target.length){
    const text=start+target.slice(0,p);
    const keys=cfg.allowKeys&&!punctuationNext?predict(text,anchor,'keys').keys||[]:[];
    const ghost=cfg.allowGhost&&!punctuationNext?predict(text,anchor,'ghost').ghost:null;
    const list=JSON.stringify([keys.map(k=>k.word),ghost?.suffix||'']);
    const newList=(keys.length||ghost)&&list!==prevList;
    if(newList)stats.newLists++;
    prevList=list;
    const options=matchingWords(target,p,keys);
    if(ghost?.suffix && target.startsWith(ghost.suffix,p))options.push({end:p+ghost.suffix.length,extra:0,kind:ghost.kind||'legacy-ghost',surface:'ghost'});
    if(cfg.allowChords&&!punctuationNext){const c=commandAt(text,target,p);if(c)options.push(c);}
    let choice=null;
    for(const action of options){
      const ready=action.surface==='keys'?cfg.keysReadyMs:action.surface==='ghost'?cfg.ghostReadyMs:0;
      if(ready>=cfg.charMs)continue; // a continuously typing learner did not see it in time
      const typed=action.typed||0;
      const cost=typed*cfg.charMs + Math.max(ready,cfg.tapMs+cfg.scanMs)+(action.extra||0)*cfg.charMs;
      const saved=(action.end-p)*cfg.charMs-cost;
      if(saved>0 && (!choice||saved>choice.saved))choice={...action,cost,saved};
    }
    if(choice && randomAt(row.id+'/'+p+'/use')>=cfg.used){stats.ignoredExact++;choice=null;}
    if(!choice){
      if(newList){stats.unusedLists++;stats.ms+=cfg.missMs;}
      const c=target[p++];stats.typed++;stats.ms+=cfg.charMs;
      if(substantive.test(c))anchor=start+target.slice(0,p);
      punctuationNext=false;
      continue;
    }
    p=choice.end;stats.taps++;stats.typed+=choice.typed||0;stats.extra+=choice.extra||0;stats.ms+=choice.cost;
    stats.tapsByLane[choice.kind]=(stats.tapsByLane[choice.kind]||0)+1;
    stats.savingsByLane[choice.kind]=(stats.savingsByLane[choice.kind]||0)+choice.saved;
    if(choice.rank)stats.keyRanks[choice.rank-1]++;
    // A command was separately typed and confirmed by the learner.
    if(choice.surface==='shortcut')anchor=start+target.slice(0,p);
    punctuationNext=!!choice.punct;
  }
  stats.savedMs=stats.baselineMs-stats.ms;
  return stats;
}
function withoutLetters(target,p,predict,initial) {
  const anchor=initial+target.slice(0,p);
  while(p<target.length){
    if(!tokenChar.test(target[p])){p++;continue;}
    const keys=predict(initial+target.slice(0,p),anchor,'keys').keys||[];
    const [match]=matchingWords(target,p,keys);
    if(!match)return false;
    p=match.end;
  }
  return true;
}
export function suffixMetrics(row,predict){
  const {target,initial}=row;const ws=tokens(target);
  const stats={id:row.id,wordStarts:ws.length,boundaryHits:0,reciprocal:0,atPrefix:[],slots:[0,0,0,0],
    firstKeyboard:null,firstGhost:null,ghostCharsSaved:0,ghostMismatch:0,ghostSeen:0};
  for(const w of ws) {
    let prefix=null;
    for(let i=0;i<w[0].length;i++) {
      const p=w.index+i,text=initial+target.slice(0,p), keys=predict(text,text,'keys').keys||[];
      const k=keys.findIndex(x=>x.word===w[0]);
      if(i===0){stats.slots[keys.length]++; if(k>=0){stats.boundaryHits++;stats.reciprocal+=1/(k+1);}}
      if(k>=0){prefix=i;break;}
    }
    stats.atPrefix.push(prefix);
  }
  for(let i=0;i<ws.length-1;i++){
    if(withoutLetters(target,ws[i].index,predict,initial)){
      stats.firstKeyboard={typed:i,remaining:ws.length-i,totalObserved:tokens(initial+target.slice(0,ws[i].index)).length};break;}
  }
  for(let p=0;p<target.length;p++){
    const text=initial+target.slice(0,p), g=predict(text,text,'ghost').ghost;
    if(!g)continue;
    stats.ghostSeen++;
    if(!target.startsWith(g.suffix,p))stats.ghostMismatch++;
    if(!stats.firstGhost && g.suffix===target.slice(p) && (tokens(g.suffix).length>=2||g.suffix.trim().length>=4)){
      stats.firstGhost={typed:tokens(target.slice(0,p)).length,remaining:tokens(g.suffix).length,totalObserved:tokens(text).length};
      stats.ghostCharsSaved=g.suffix.length;
    }
  }
  return stats;
}
export function summarize(runs) {
  const sums={docs:runs.length,chars:0,baselineMs:0,ms:0,typed:0,extra:0,taps:0,newLists:0,unusedLists:0,ignoredExact:0,savedMs:0,byLane:{},tapsByLane:{}};
  for(const r of runs){
    for(const k of ['chars','baselineMs','ms','typed','extra','taps','newLists','unusedLists','ignoredExact','savedMs'])sums[k]+=r[k];
    for(const [k,s] of Object.entries(r.savingsByLane))sums.byLane[k]=(sums.byLane[k]||0)+s;
    for(const [k,s] of Object.entries(r.tapsByLane))sums.tapsByLane[k]=(sums.tapsByLane[k]||0)+s;
  }
  sums.timeReduction=sums.savedMs/sums.baselineMs;sums.estimatedWpm=sums.chars/5/(sums.ms/60000);
  sums.physicalActions=sums.typed+sums.taps+sums.extra;
  return sums;
}
