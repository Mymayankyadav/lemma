import {fileURLToPath} from 'node:url';
import fs from 'node:fs';
import {assets, file, read} from '../experiment/common.mjs';
import {memoizePredict, simulate, summarize} from '../experiment/replay.mjs';
import {makeStudyInput} from '../engine/study_input.mjs';

const lines = name => file(name).trim().split('\n').map(JSON.parse);
const final = lines('data/final_mobile.jsonl').filter(row => row.kind === 'natural');
const earlier = [
  ...lines('data/heldout.jsonl').filter(row => row.study === 'natural-factorial' && !row.choices.length),
  ...lines('data/choice-heldout.jsonl').filter(row => row.kind === 'natural')
    .map(row => ({id: row.id, target: row.text, initial: ''})),
];
const model = makeStudyInput({...assets, ranks: read('engine/compact-ranks.json')}, {seed: 58});
const profiles = {
  recorded: {keysReadyMs: 110, used: .75, tapMs: 250, scanMs: 75, missMs: 15},
  earlierKeys: {keysReadyMs: 35, used: .75, tapMs: 250, scanMs: 75, missMs: 15},
  quickerSelection: {keysReadyMs: 35, used: .75, tapMs: 200, scanMs: 25, missMs: 15},
  increasedUse: {keysReadyMs: 35, used: .9, tapMs: 250, scanMs: 75, missMs: 15},
  slowerSelection: {keysReadyMs: 110, used: .5, tapMs: 325, scanMs: 125, missMs: 45},
};
const output = {
  method: 'Cursor replay at 30 WPM (400 ms/character), following intended draft. All timing and uptake settings are modeled.',
  profiles, final: {}, earlier: {},
};
for (const [label, rows] of [['final', final], ['earlier', earlier]]) {
  for (const mode of ['strict', 'balanced', 'fast']) {
    const predict = memoizePredict(model, mode);
    output[label][mode] = {};
    for (const [profile, settings] of Object.entries(profiles)) {
      output[label][mode][profile] = summarize(rows.map(row => simulate(row, predict, settings)));
    }
  }
}
fs.writeFileSync(fileURLToPath(new URL('./typing.json', import.meta.url)), JSON.stringify(output, null, 2) + '\n');
