from pathlib import Path
import re,json
r=Path(__file__).parent;m=r/'modules';o=r/'owners'
p=m/'53__index-DcUkykC4.js';s=p.read_text()
# Calendar host is content-sized. The page now reserves the shared shell.
s=s.replace('height: `100%`,\n          minHeight: 0,\n          flex: 1,\n          overflow: `hidden`,','height: `auto`,\n          minHeight: 0,\n          flex: `none`,\n          overflow: `visible`,')
# Consolidate focus access in one context/clock button, retaining separate pause.
a=s.index('  const dock =');b=s.index('\n}',a);part=s[a:b]
x=part.index('        (0, A.jsx)(`time`,');y=part.index('        (0, A.jsx)(`button`, {\n          type: `button`,\n          className: `cr-button`,\n          onClick: sessionAction',x)
time=part[x:y];part=part[:x]+part[y:]
part=part.replace('(0, A.jsx)(`small`, { className: `cr-meta`, children: label }),','(0, A.jsx)(`small`, { className: `cr-meta`, children: label }),\n            (0,A.jsx)(`time`,{children:clock()}),')
part=re.sub(r'        \(0, A.jsx\)\(`button`, \{\s*type: `button`,\s*className: `cr-button`,\s*onClick: focus,\s*children: `Focus`,\s*\}\),','',part)
s=s[:a]+part+s[b:]
# Scoped batch badge, including project parent active state.
s=s.replace('currentPath = me().pathname;','currentPath = me().pathname;\n  const batch=Math.min(Number(localStorage.getItem("lemma.review.batch"))||33,Math.max(0,Number(t?.due)||0));')
s=s.replace('${t.due>99?"99+":t.due} Review, ${t.due} cards due','${batch>99?"99+":batch} Review, ${batch} cards in today’s batch')
# Replace badge-only due cap in this component.
a=s.index('function Nn()');b=s.index('\nfunction ',a+12);part=s[a:b].replace('t.due > 99 ? `99+` : t.due','batch > 99 ? `99+` : batch').replace('`${t.due} cards due`','`${batch} cards in today’s batch`')
s=s[:a]+part+s[b:]
s=s.replace('"aria-label": `Actions for ` + e.title,','"aria-label": `Actions for ` + e.title,"data-ui":`path-actions`,')
# Native row renderer visual hook.
i=s.index('"aria-label": `Actions for `');j=s.rfind('return (0, A.',0,i);k=s.index('className:',j);s=s[:k]+'"data-ui":`path-row`,\n      '+s[k:]
p.write_text(s)
# Review: remove inline fixed paper dimensions, allocate the actual task surface.
p=m/'15__Page-Cajg06h3.js';s=p.read_text().replace('height: `clamp(208px,42dvh,350px)`,\n        minHeight: 208,','height: `100%`,\n        minHeight: 0,')
s=s.replace('className: `gap-3 lemma-review-run`,','className: `gap-3 lemma-review-run`,"data-ui":`review-task`,')
s=s.replace('children: Q?.[n].label ?? `—`,','children: formatInterval(Q?.[n].label),')
s=s.replace('var de =','var de =',1)
s='function formatInterval(value){return String(value??"—").replace(/(\\d+(?:\\.\\d+)?)mo\\b/g,"$1 mo").replace(/(\\d+(?:\\.\\d+)?)m\\b/g,"$1 min").replace(/(\\d+(?:\\.\\d+)?)h\\b/g,"$1 h").replace(/(\\d+(?:\\.\\d+)?)d\\b/g,"$1 d");}\n'+s
s=s.replace('"aria-label": `Grade ` + e,','"aria-label": `Grade ` + e + `, ` + formatInterval(Q?.[n].label),')
s=s.replace('children: [\n                                (0, I.jsx)(`span`, {\n                                  className: `size-1.5 rounded-full`,\n                                  style: { background: L[t] },\n                                }),','children: [\n                                ["× ","~ ","✓ ","✓✓ "][t],')
p.write_text(s)
# Stack wrappers reserve only a small decorative cue.
p=m/'01__Card-nFooZijf.js';s=p.read_text().replace('relative mb-6','relative mb-1').replace('-bottom-[26px]','-bottom-[8px]').replace('-bottom-[13px]','-bottom-[4px]');p.write_text(s)
# Project consumes the existing effort authority, not a second timer.
p=m/'19__Page-DfokWqaX.js';s=p.read_text();at=s.index('  const ctx = {',s.index('function LemmaProjectStudyContext'))
s=s[:at]+'''  const timer=data.session.timer||{};
  const linked=String(timer.projectId||links[timer.activity]||'');
  const owns=projectIds.has(linked)||(!linked&&timer.activity===proj.title);
  const active=owns?window.__lemmaEffortMetrics?.active(timer,Date.now(),data.session.entries||[])||0:0;
  const hasCurrent=owns&&(timer.running||timer.paused);
'''+s[at:]
s=s.replace('" · timed study",','" logged",\n              active>0?` · ${Math.round(active)} min in progress`:null,')
s=s.replace('onClick: () =>\n              window.__carrelIntegration?.open?.("timer", null, {','onClick: () => hasCurrent ? window.dispatchEvent(new Event("lemma:focus-open")) :\n              window.__carrelIntegration?.open?.("timer", null, {')
s=s.replace('children: "Start focus timer",','children: hasCurrent?"Open current focus":"Start focus timer",')
s=s.replace('children: [n + 1, `.`],','children: ``,')
p.write_text(s)
# Settings language aligns with the plan while preserving the stored keys.
p=o/'lemma-native-calendar-runtime.js';s=p.read_text().replace('Your day','Daily schedule').replace('Reviews & calendar','Review scheduling').replace('Attention & surfaces','Attention & reminders');p.write_text(s)
p=o/'carrel-added-behaviour.js';s=p.read_text().replace('Your day','Daily schedule').replace('Reviews & calendar','Review scheduling').replace('Attention & surfaces','Attention & reminders');p.write_text(s)
# Reviewer-facing documentation is source-owned and reproducible.
p=o/'design-system.css';s=p.read_text()+'''
/* Task and header wrapper allocation; no hidden content-height assumptions. */
body:has(.lemma-review-stage) #main-content>div{height:100%;min-height:0}
[data-ui=review-task]{gap:6px;max-height:100%}
.lemma-review-header{display:block;position:relative}
.lemma-review-progress-track{display:none}
.lemma-review-nav-row{display:flex;align-items:center;justify-content:space-between;gap:8px;height:100%}
.lemma-review-nav-start,.lemma-review-nav-end{display:flex;align-items:center;gap:4px}
.lemma-review-nav-title{flex:1;min-width:0;text-align:center;font-size:.875rem}
.lemma-review-count{font-size:.875rem}.lemma-review-project{font-size:.75rem}
.lemma-review-card-motion>div{display:flex;flex:1;min-height:0;margin-bottom:4px}
[data-ui=review-paper]{background-image:none}
.cr-calendar-native{display:flex;flex-direction:column;height:auto;gap:12px}
.cr-calendar-title{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:44px}
.cr-calendar-title h1{font-size:1.75rem;line-height:2rem;margin:0;padding:0}
#cr-calendar-native-host{flex:none}
[data-ui=path-row]{background:var(--paper)}
@media(max-width:600px){[data-ui=path-row] [role=menu]{position:fixed;inset:auto 0 0;max-height:80dvh;width:100%;z-index:100;background:var(--paper);border-radius:12px 12px 0 0;padding:16px}}
@media(max-height:480px){.lemma-review-header{min-height:44px;height:44px}[data-ui=review-paper]>div:first-child{font-size:.75rem;line-height:1rem;padding-bottom:0}[data-ui=review-paper]{gap:2px}[data-ui=review-grades]{padding-top:0;padding-bottom:0}}
''';p.write_text(s)
