"""Small, ownership-based edits to original, extracted Lemma modules. Idempotent from originals after unpack."""
from pathlib import Path
import re,json
ROOT=Path(__file__).parent;M=ROOT/'modules'
def rep(file,old,new,once=True):
 p=M/file; s=p.read_text(); n=s.count(old)
 if n != 1 if once else n<1:raise AssertionError(f'{file}: {old[:80]!r} found {n} times')
 p.write_text(s.replace(old,new,1 if once else -1))
 print(file,old[:55].replace('\n',' '))

# W06 - Native checkbox owner: bound labels, hit area and visible focus; do not conceal functionality.
check='02__Check-Cuu8pd38.js'
cs=(M/check).read_text()
start=cs.index('function f({checked:e,onChange:t,size:n=22,label:r,disabled:i})')
end=cs.index('export{d as n,l as r,f as t};',start)
replacement='''function f({checked:e,onChange:t,size:n=22,label:r,disabled:i,labelVisibility:v=`visible`}){
 let s=(0,u.useRef)(null),h=(0,u.useId)();
 (0,u.useEffect)(()=>{if(s.current)s.current.indeterminate=e===`mixed`},[e]);
 let hidden=v===`visually-hidden`;
 return(0,c.jsxs)(`label`,{
  "data-ui":`review-checkbox`,"data-state":e===`mixed`?`mixed`:e?`checked`:`unchecked`,
  className:`relative inline-flex min-h-11 min-w-11 cursor-pointer items-center gap-2 text-label text-ink-2 ${hidden?`justify-center`:``}`,
  children:[
   (0,c.jsx)(`input`,{ref:s,id:h,type:`checkbox`,disabled:i,checked:e===!0,
    className:`peer absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0 disabled:cursor-not-allowed`,
    onChange:e=>t(e.currentTarget.checked)}),
   (0,c.jsx)(`span`,{"aria-hidden":`true`,
    className:`pointer-events-none relative flex shrink-0 items-center justify-center rounded-[3px] border border-edge-3 bg-well peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-amber ${e?`border-amber bg-amber text-amber-ink`:``}`,
    style:{width:n,height:n},children:e===`mixed`?(0,c.jsx)(o,{size:14}):e?(0,c.jsx)(a,{size:15,strokeWidth:2.6}):null}),
   (0,c.jsx)(`span`,{className:hidden?`sr-only`:`min-w-0`,children:r})
  ]
 });
}'''
cs=cs[:start]+replacement+cs[end:]
(M/check).write_text(cs)
# W06 review deck list: pagination first 8, remove accidental hidden text CSS and unbounded inner scrolling.
rev='12__Page-Bd_8EoE4.js'
rep(rev,'  let [F, I] = (0, w.useState)(null),','  let [deckLimit,setDeckLimit] = (0,w.useState)(8),\n      [F, I] = (0, w.useState)(null),')
rep(rev,'                        me.map((e) => {','''                        me.length > 8 && (0,E.jsxs)(`div`,{"data-ui":`deck-pagination`,className:`flex flex-wrap items-center justify-between gap-2 py-2 text-label text-ink-2`,children:[
                          (0,E.jsx)(`span`,{children:`Showing ${Math.min(deckLimit,me.length)} of ${me.length} decks`}),
                          (0,E.jsx)(`button`,{type:`button`,className:`min-h-11 rounded-ctl border border-edge px-3 font-semibold`,onClick:()=>setDeckLimit(v=>v>=me.length?8:Math.min(me.length,v+8)),children:deckLimit>=me.length?`Show first 8 decks`:`Show ${Math.min(8,me.length-deckLimit)} more decks`})
                        ]}),
                        me.slice(0,deckLimit).map((e) => {''')
rep(rev,'className: `[&>label]:text-[length:var(--type-hidden)]`,','className: `inline-flex shrink-0 items-center`,',once=False)
rep(rev,'                                        label: `Include ` + e.label,','                                        label: `Include ` + e.label,\n                                        labelVisibility: `visually-hidden`,')
rep(rev,'                                              label: `Include ` + t.label,','                                              label: `Include ` + t.label,\n                                              labelVisibility: `visually-hidden`,')
rep(rev,'className: `min-w-0 flex-1 truncate text-headline font-medium`,','className: `min-w-0 flex-1 text-headline font-medium`,')
rep(rev,'className: `min-w-0 flex-1 truncate text-body text-ink-soft`,','className: `min-w-0 flex-1 text-body text-ink-soft`,')
rep(rev,'children: [`Start `, J],','children: `Start review`,')
rep(rev,'children: `Decks`,','children: `Decks`,') if False else None
rep(rev,'children: `Mix decks`,','children: `Mix decks`,') if False else None
rep(rev,'children: `Use for 7 days`,','children: `Use this budget for 7 days`,') if 'children: `Use for 7 days`' in (M/rev).read_text() else None
# W07 review: leave prompt position stable, use measured scroll end, hint in flow, restore neutral confidence.
run='15__Page-Cajg06h3.js'
rep(run,"        const answer=e.querySelector('[data-answer]');\n        if(answer){e.scrollTop=answer.offsetTop-e.offsetTop;answer.focus({preventScroll:true});window.scrollTo(0,0);}else e.scrollTop=0;", "        // Revealing never moves the reader away from the prompt. Reset only for a new card.\n        if(!t)e.scrollTop=0;")
rep(run,'''          Math.max(
            0,
            Math.ceil((e.scrollHeight - e.scrollTop - e.clientHeight) / 28),
          ),''','''          Number(e.scrollHeight-e.scrollTop-e.clientHeight>8),''')
rep(run,'''                  Math.max(
                    0,
                    Math.ceil(
                      (t.scrollHeight - t.scrollTop - t.clientHeight) / 28,
                    ),
                  ),''','''                  Number(t.scrollHeight-t.scrollTop-t.clientHeight>8),''')
# remove overlay, re-render a footer row after reading area
r=(M/run).read_text();a=r.index('            c > 0 &&\n              (0, I.jsxs)(`div`, {');b=r.index('          ],\n        }),\n        (0, I.jsxs)(`div`, {',a)
assert b>a
r=r[:a]+r[b:]
needle='''          ],
        }),
        (0, I.jsxs)(`div`, {
          className: `flex shrink-0 flex-wrap gap-2 text-ink-3`,'''
assert r.count(needle)==1
r=r.replace(needle,'''          ],
        }),
        c > 0 && (0,I.jsx)(`button`,{
          "data-ui":`review-more-below`,type:`button`,
          className:`min-h-11 w-full shrink-0 rounded-ctl border border-edge bg-well text-label font-semibold text-ink-2`,
          onClick:()=>s.current?.scrollBy({top:s.current.clientHeight*.75,behavior:`auto`}),
          children:`More below ↓`
        }),
        (0, I.jsxs)(`div`, {
          className: `flex shrink-0 flex-wrap gap-2 text-ink-3`,''')
(M/run).write_text(r)
rep(run,'children: `How sure are you? Tapping reveals the answer.`,','children: `Optional confidence · choosing reveals the answer.`,')
rep(run,'(e === `sure` ? `text-amber` : `text-ink-soft`),','`text-ink-2`,')
rep(run,'(e === `sure`\n                                      ? `bg-current`\n                                      : e === `guess`\n                                        ? `border-dashed`\n                                        : ``),','(e === `guess` ? `border-dashed` : ``),')
rep(run,'children: `Show answer`,','children: `Show answer without confidence`,')
# Give back/answer in-flow keyboard jump links, for revealed long cards only.
rep(run,'''                t &&
                  (0, I.jsxs)(`div`, {
                    className: `mt-4 min-w-0 font-math text-[18px] leading-[28px]`,''','''                t && a.length>200 && (0,I.jsx)(`button`,{type:`button`,className:`my-3 min-h-11 text-label font-semibold text-ink underline`,onClick:()=>s.current?.querySelector('[data-answer]')?.scrollIntoView({block:`nearest`}),children:`Jump to answer`}),
                t &&
                  (0, I.jsxs)(`div`, {
                    className: `mt-4 min-w-0 font-math text-[18px] leading-[28px]`,''')
rep(run,'''                    children: [
                      (0, I.jsx)(l.div, {
                        initial: !r && { scaleX: 0 },''','''                    children: [
                      (0,I.jsx)(`h3`,{className:`mb-2 text-headline font-semibold text-ink`,children:`Answer`}),
                      (0,I.jsx)(`span`,{className:`sr-only`,role:`status`,children:`Answer shown`}),
                      (0, I.jsx)(l.div, {
                        initial: !r && { scaleX: 0 },''')
# fix W07 stack via compact edge CSS owner downstream; interval labels use producer in scheduler, do not parse strings.
print('core module edits complete')
