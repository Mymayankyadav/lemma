from pathlib import Path
import re,json
root=Path(__file__).resolve().parent
orig=(root/'Lemma_UI_Final.html').read_text();path=root/'inline-patches.json';p=json.loads(path.read_text())
old=re.search(r"case'entry-save':\{.*?break\}",orig,re.S).group(0)
assert orig.count(old)==1
new='''case'entry-save':{
 const eid=$('[data-entry-id]').dataset.entryId,title=val('cx-entry-title').trim(),date=val('cx-entry-date'),start=val('cx-entry-start'),end=val('cx-entry-end');
 if(!title||!date||!start||!end||start===end){$('#cx-form-error').textContent='Use a title, date and two distinct times.';return}
 const parts=/^(\\d{4})-(\\d{2})-(\\d{2})$/.exec(date),clock=/^([01]\\d|2[0-3]):([0-5]\\d)$/;
 if(!parts||!clock.test(start)||!clock.test(end)){$('#cx-form-error').textContent='Choose a valid local date and time.';return}
 const [,year,month,day]=parts.map(Number),[sh,sm]=start.split(':').map(Number),[eh,em]=end.split(':').map(Number);
 const begins=new Date(year,month-1,day,sh,sm),ends=new Date(year,month-1,day,eh,em);
 if(ends<=begins)ends.setDate(ends.getDate()+1);
 const previous=eid?S.entries.find(x=>x.id===eid):null;
 const timesChanged=!!previous&&(previous.date!==date||previous.start!==start||previous.end!==end);
 snapshot();
 const e={...(previous||{}),id:eid||'e'+Date.now(),title,subject:val('cx-entry-subject'),date,start,end,
  min:previous&&!timesChanged&&Array.isArray(previous.intervals)?previous.min:Math.max(1,Math.round((ends-begins)/60000)),
  focus:val('cx-entry-focus'),note:val('cx-entry-note')};
 if(previous&&timesChanged&&Array.isArray(previous.intervals)){
  // A user-adjusted time range is authoritative, but the old Pomodoro/break
  // subdivisions cannot honestly be presented as observations of that range.
  e.intervals=[{start:begins.toISOString(),end:ends.toISOString()}];
  e.startInstant=begins.toISOString();e.endInstant=ends.toISOString();
  e.timeApproximate=true;e.editedTimeRange=true;
 }
 if(eid)S.entries=S.entries.map(x=>x.id===eid?e:x);else S.entries.push(e);
 save();close();render();toast('Time log updated.',true);break}'''
assert orig.count("case'entry-save':")==1
p.append({'old':old,'new':new})
old_note='<p class="cx-caption">For overnight sessions, an earlier end time means the following day.</p>'
assert orig.count(old_note)==1
new_note='<p class="cx-caption">For overnight sessions, an earlier end time means the following day. Editing the time of a logged focus session replaces its detailed focus/break intervals; changing its title, subject or note preserves them.</p>'
p.append({'old':old_note,'new':new_note})
path.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
print('Time log editor now preserves true segments for metadata-only edits and warns when time edits rebuild intervals.')
