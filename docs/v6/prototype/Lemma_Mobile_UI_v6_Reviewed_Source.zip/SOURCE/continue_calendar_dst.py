#!/usr/bin/env python3
"""One-time modifications to the canonical detached bundle, NOT the repo.
Do not re-run once patch anchors have changed.
"""
from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
orig=(root/'Lemma_UI_Final.html').read_text()
pfile=root/'inline-patches.json'; patches=json.loads(pfile.read_text())

def add(old,new):
 if old==new: return
 assert orig.count(old)==1, (old[:120],orig.count(old))
 assert not any(old in x['old'] or old in x['new'] for x in patches), 'anchor overlaps another patch: '+old[:100]
 patches.append({'old':old,'new':new})

# Use local civil-day boundaries rather than pretending every day is 1440 elapsed minutes.
# Data model: date+wall clock minute and an elapsed duration in minutes. No silent UTC parsing.
patches[16]['new'] = '''const crTime=m=>String(Math.floor(m/60)%24).padStart(2,'0')+':'+String(m%60).padStart(2,'0');
const crStatus=b=>b.actual?'logged':b.busy?'busy':'planned';
const crStatusText=Object.freeze({logged:'Logged',planned:'Planned',busy:'Busy'});
function crLocalDay(day){
 const parts=/^(\\d{4})-(\\d{2})-(\\d{2})$/.exec(day||'');
 if(!parts)return null;
 const [year,month,number]=parts.slice(1).map(Number);
 const start=new Date(year,month-1,number),end=new Date(year,month-1,number+1);
 if(dkey(start)!==day)return null;
 return {start:start.getTime(),end:end.getTime(),minutes:(end-start)/60000};
}
function crBlockInterval(block){
 const date=/^(\\d{4})-(\\d{2})-(\\d{2})$/.exec(block?.date||'');
 const time=/^([01]\\d|2[0-3]):([0-5]\\d)$/.exec(block?.at||'');
 const minutes=Number(block?.min);
 if(!date||!time||!Number.isFinite(minutes)||minutes<=0)return null;
 const [year,month,day]=date.slice(1).map(Number),hour=Number(time[1]),minute=Number(time[2]);
 const at=new Date(year,month-1,day,hour,minute),start=at.getTime();
 if(dkey(at)!==block.date)return null;
 return {start,end:start+minutes*60000,shifted:at.getHours()!==hour||at.getMinutes()!==minute};
}
const crLocalClock=(day,offset)=>{
 const bounds=crLocalDay(day);
 if(!bounds)return crTime(offset);
 const instant=new Date(bounds.start+offset*60000);
 return instant.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit',timeZoneName:'short'});
};
function crDayWorkload(day){
 const bounds=crLocalDay(day);
 if(!bounds)return {sum:0,occupied:0,planned:0,logged:0,busy:0,conflicts:[],affected:0,dayMinutes:0,shiftedEvents:0};
 const seen=new Set(),ranges=[];let shiftedEvents=0;
 for(const b of S.blocks){
  const identity=b.id||b.date+':'+b.at+':'+b.title;
  if(seen.has(identity))continue;
  seen.add(identity);
  const interval=crBlockInterval(b);
  if(!interval||interval.start>=bounds.end||interval.end<=bounds.start)continue;
  if(interval.shifted)shiftedEvents++;
  const start=Math.max(interval.start,bounds.start),end=Math.min(interval.end,bounds.end);
  ranges.push({b,start:(start-bounds.start)/60000,end:(end-bounds.start)/60000,status:crStatus(b)});
 }
 ranges.sort((a,b)=>a.start-b.start||a.end-b.end);
 let sum=0,occupied=0,lastEnd=0,planned=0,logged=0,busy=0;
 for(const x of ranges){
  const span=x.end-x.start;
  sum+=span;
  if(x.status==='planned')planned+=span;
  else if(x.status==='logged')logged+=span;
  else busy+=span;
  occupied+=Math.max(0,x.end-Math.max(x.start,lastEnd));
  lastEnd=Math.max(lastEnd,x.end);
 }
 const conflicts=[];
 for(let i=0;i<ranges.length;i++)for(let j=i+1;j<ranges.length&&ranges[j].start<ranges[i].end;j++){
  const a=ranges[i],b=ranges[j];
  if(a.start<b.end&&b.start<a.end&&a.b.id!==b.b.id)conflicts.push({a:a.b,b:b.b,start:Math.max(a.start,b.start),end:Math.min(a.end,b.end)});
 }
 const affected=new Set(conflicts.flatMap(x=>[x.a.id,x.b.id]));
 return {sum,occupied,planned,logged,busy,conflicts,affected:affected.size,dayMinutes:bounds.minutes,shiftedEvents};
}
'''
# Replace source-owned day-splitting helper with one that supports crossing any actual
# midnight; still returns the same event objects/flags expected by editor and grid.
old=re.search(r'function blocksForDay\(day,split=false\)\{.*?\n\}\nconst endLabel=',orig,re.S).group(0)
new='''function blocksForDay(day,split=false){
 const bounds=crLocalDay(day);
 if(!bounds)return [];
 const results=[];
 for(const b of S.blocks){
  const span=crBlockInterval(b);
  if(!span||span.start>=bounds.end||span.end<=bounds.start)continue;
  const continued=span.start<bounds.start;
  const segmentStart=Math.max(span.start,bounds.start);
  const segmentEnd=Math.min(span.end,bounds.end);
  if(!split&&!continued){results.push({...b,endInstant:span.end});continue}
  const time=new Date(segmentStart);
  const at=String(time.getHours()).padStart(2,'0')+':'+String(time.getMinutes()).padStart(2,'0');
  results.push({...b,date:day,at,min:(segmentEnd-segmentStart)/60000,
   continued,spansMidnight:span.end>bounds.end,endInstant:split?segmentEnd:span.end,
   sourceDate:b.date,sourceAt:b.at,
   title:continued?b.title+' · continued':b.title});
 }
 return results;
}
const endLabel='''
add(old,new)
old="const endLabel=b=>crTime(crClockMin(b.at)+b.min)+(crClockMin(b.at)+b.min>=1440?' (+1 day)':'');"
new="""const endLabel=b=>{
 const span=b.endInstant?{end:b.endInstant}:crBlockInterval(b);
 if(!span)return crTime(crClockMin(b.at)+Number(b.min||0));
 const last=new Date(span.end),day=dkey(last),next=day!==b.date;
 return String(last.getHours()).padStart(2,'0')+':'+String(last.getMinutes()).padStart(2,'0')+(next?' (next day)':'');
};"""
add(old,new)
# Replace only the labels and attributes in the owning renderers, preserving handlers.
add('kind=b.actual?\'logged\':b.busy?\'busy\':\'planned\';return `<button',
    'kind=crStatus(b);return `<button')
add('class="cr-spatial-event ${kind} ${b.min<=35?', 'class="cr-spatial-event ${kind} ${b.min<=35?') if False else None
add('data-cx="edit-block" data-id="${b.id}" title="${esc(b.title)} · ${b.at} · ${duration(b.min)}" data-movable=',
    'data-cx="edit-block" data-id="${b.id}" data-status="${kind}" title="${esc(b.title)} · ${esc(b.subject)} · ${b.at}–${endLabel(b)} · ${crStatusText[kind]}" data-movable=')
add('${esc(b.subject)} · ${duration(b.min)}${b.actual?\' · logged\':\'\'}${b.pin?',
    '${esc(b.subject)} · ${duration(b.min)} · ${crStatusText[kind]}${b.pin?')
old=re.search(r'function agenda\(\)\{.*?\nfunction crPlanner\(\)',orig,re.S).group(0)
new='''function agenda(){
 const list=blocksForDay(dkey(date)).sort((a,b)=>a.at.localeCompare(b.at));
 return `<div class="lemma-agenda" role="region" aria-label="Study agenda">${list.length?list.map(b=>{
  const status=crStatus(b);
  return `<button type="button" data-cx="edit-block" data-id="${b.id}" data-status="${status}" class="lemma-agenda-item" aria-label="${esc(b.title)}, ${esc(b.subject)}, ${b.at} to ${endLabel(b)}, ${crStatusText[status]}"><span>${b.at}–${endLabel(b)}</span><strong>${esc(b.title)}</strong><small>${esc(b.subject)} · ${duration(b.min)} · ${crStatusText[status]}</small></button>`;
 }).join(''):'<p class="cx-paper">No blocks for this day. Add a study block to make a plan.</p>'}</div>`;
}
function crPlanner()'''
add(old,new)
# Replace the month cell renderer with a civil-day implementation, reporting counts and
# only the category markers actually present. Selection and today stay independent.
old=re.search(r'function monthCalendar\(\)\{.*?\nfunction backlog\(\)',orig,re.S).group(0)
new='''function monthCalendar(){
 const first=new Date(date.getFullYear(),date.getMonth(),1),offset=(first.getDay()+6)%7;
 const start=new Date(first.getFullYear(),first.getMonth(),1-offset);
 const total=Math.ceil((offset+new Date(date.getFullYear(),date.getMonth()+1,0).getDate())/7)*7;
 const marks=['logged','planned','busy'];
 return `<div class="cx-month" style="--cr-month-weeks:${total/7}">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(x=>`<div class="cx-date-head">${x}</div>`).join('')}${Array.from({length:total},(_,i)=>{
  const d=new Date(start.getFullYear(),start.getMonth(),start.getDate()+i),day=dkey(d);
  const bs=blocksForDay(day,true),statuses=new Set(bs.map(crStatus));
  const isToday=day===dkey(new Date()),selected=day===dkey(date),outside=d.getMonth()!==date.getMonth();
  return `<div class="cx-month-day ${isToday?'today':''} ${selected?'selected':''} ${outside?'outside-month':''}" data-today="${isToday}" data-selected="${selected}"><button type="button" data-cx="month-day" data-id="${day}" aria-label="Open ${d.toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'})}${isToday?', today':''}${selected?', selected':''}, ${bs.length} blocks">${d.getDate()}</button>${bs.length?`<div class="cr-month-compact" title="${bs.length} blocks"><span class="cr-month-count">${bs.length} blocks</span><span class="cr-month-markers" aria-label="${marks.filter(s=>statuses.has(s)).map(s=>crStatusText[s]).join(', ')}">${marks.filter(s=>statuses.has(s)).map(s=>`<i data-status="${s}" class="${s}" aria-hidden="true"></i>`).join('')}</span></div>`:''}</div>`;
 }).join('')}</div>`;
}
function backlog()'''
add(old,new)
# Conflict details render real local clocks incl. an unambiguous timezone abbreviation.
old="${crTime(c.start)}–${crTime(c.end)}"
assert old in patches[20]['new']
patches[20]['new']=patches[20]['new'].replace(old,"${crLocalClock(dkey(date),c.start)}–${crLocalClock(dkey(date),c.end)}")
# Change calendar date navigation to civil days, not 86400000-ms jumps.
old="else date=new Date(+date+n*(view==='week'?7:1)*DAY);render();break}"
add(old,"else date=new Date(date.getFullYear(),date.getMonth(),date.getDate()+n*(view==='week'?7:1));render();break}")
# Correct the older secondary week rendering, too (still retained).
old="const days=Array.from({length:view==='day'?1:7},(_,i)=>new Date(+start+i*DAY));return `<div class=\"cx-calendar-wrap\">"
add(old,"const days=Array.from({length:view==='day'?1:7},(_,i)=>new Date(start.getFullYear(),start.getMonth(),start.getDate()+i));return `<div class=\"cx-calendar-wrap\">")
old="<div class=\"cx-week-head\">IST</div>"
add(old,"<div class=\"cx-week-head\">${new Intl.DateTimeFormat(undefined,{timeZoneName:'short'}).formatToParts(new Date()).find(x=>x.type==='timeZoneName')?.value||'Local'}</div>")
# Summary separates planned, logged and busy; distinguishes 23/25h elapsed days.
patches[22]['new']='''<span>${duration(workload.sum)} of blocks · ${duration(workload.occupied)} occupied<span class="cr-workload-breakdown"> · ${duration(workload.planned)} planned · ${duration(workload.logged)} logged · ${duration(workload.busy)} busy${workload.dayMinutes!==1440?' · '+duration(workload.dayMinutes)+' local day':''}</span>${workload.conflicts.length?' · '+workload.affected+' conflicting blocks':''}${workload.conflicts.length?` <button type="button" data-cx="calendar-conflicts" class="cr-conflict-action">Review conflicts</button>`:''}${workload.shiftedEvents?` <span title="A wall-clock time did not exist on this date; the browser shifted it">${workload.shiftedEvents} shifted local time${workload.shiftedEvents===1?'':'s'}</span>`:''}</span>'''
# Calendar owner style: statuses visibly distinguishable without relying on hue.
patches[23]['new'] += '''\n/* Source-owned semantic status attributes shared by Agenda, Month and spatial blocks. */
.lemma-agenda-item[data-status="logged"]{border-inline-start:3px solid var(--cx-green);border-bottom-style:solid}
.lemma-agenda-item[data-status="planned"]{border-inline-start:3px dashed var(--cx-blue);border-bottom-style:dashed}
.lemma-agenda-item[data-status="busy"]{border-inline-start:3px double var(--cx-muted);background-image:repeating-linear-gradient(135deg,transparent 0,transparent 8px,rgba(110,123,139,.065) 8px,rgba(110,123,139,.065) 10px)}
.cr-spatial-event[data-status="logged"]{border-style:solid}
.cr-spatial-event[data-status="planned"]{border-style:dashed}
.cr-spatial-event[data-status="busy"]{border-style:double;background-image:repeating-linear-gradient(135deg,transparent 0,transparent 8px,rgba(110,123,139,.08) 8px,rgba(110,123,139,.08) 10px)}
.cx-month-day.outside-month{color:var(--cx-muted);background:var(--cx-paper);opacity:1}
.cx-month-day.today>button{text-decoration:underline;text-decoration-thickness:2px;text-decoration-color:var(--cx-accent);text-underline-offset:3px}
.cx-month-day.selected>button{outline:2px solid var(--cx-ink);outline-offset:-2px}
.cr-month-count{font-size:12px}
.cr-workload-breakdown{font-size:13px}
'''
# Header planner shortcuts only, invoking existing actions. No duplicated editor implementation.
old='<div class="cr-spatial-footer"><button class="cr-footer-session"'
new='''<div class="cr-calendar-shortcuts" role="group" aria-label="Calendar planning shortcuts"><button type="button" data-cx="new-block">Add block</button><button type="button" data-cx="spatial-tools">Tools</button><button type="button" data-cx="spatial-tool" data-id="backlog">Backlog · ${S.tasks.filter(t=>!t.done).length}</button><button type="button" data-cx="spatial-tool" data-id="deadlines">Deadlines · ${S.deadlines.length}</button></div><div class="cr-spatial-footer"><button class="cr-footer-session"'''
add(old,new)
# Verify action for existing tools and shortcut; ensure not duplicate broken route.
old="case'spatial-tool':close();planTab=id;render();break;"
new="case'spatial-tools':crPlannerTools();break;"+old
add(old,new)
patches[23]['new'] += '''\n.cr-calendar-shortcuts{display:flex;flex-wrap:wrap;gap:7px;padding:8px 4px}
.cr-calendar-shortcuts>button{min-height:44px;min-width:44px;border:1px solid var(--cx-line);background:var(--cx-paper);color:var(--cx-ink);padding:6px 10px;border-radius:6px;font:inherit;font-size:14px}
.cr-calendar-shortcuts>button:first-child{background:var(--cx-ink);color:var(--cx-paper)}
'''
# Changing existing p16/22/23 is not additive CSS patch layer. One-off source replacements are specific to their component.
pfile.write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n')
print('Changed canonical detached patch manifest; count',len(patches))
