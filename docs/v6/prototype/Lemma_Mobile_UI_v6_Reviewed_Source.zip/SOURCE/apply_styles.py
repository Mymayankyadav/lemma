"""Edits original named stylesheet declarations in place: no new stylesheet/layer."""
import json
from pathlib import Path
ROOT=Path(__file__).parent
base=Path('/mnt/data/Lemma_UI_Final.html').read_text()
patches=[]
def patch(old,new):
 if base.count(old)!=1:raise AssertionError((old[:80],base.count(old)))
 patches.append({'old':old,'new':new});print('css owner:',old[:77].replace('\n',' '))
patch('section[aria-label="Decks"]{max-height:65dvh;overflow:auto;scrollbar-width:auto}', 'section[aria-label="Decks"]{max-height:none;overflow:visible;scrollbar-width:auto}')
patch('n/* v9: route-owned integrations, no observer-inserted controls. */','/* v9: route-owned integrations, no observer-inserted controls. */')
patch('.lg-outline-list{padding:4px 12px 12px;max-height:300px;overflow-y:auto;display:grid;gap:3px;overscroll-behavior:contain}', '.lg-outline-list{padding:4px 12px 12px;max-height:none;overflow:visible;display:grid;gap:3px}')
patch('.lg-outline-content{max-height:330px;overflow:auto}', '.lg-outline-content{max-height:none;overflow:visible}')
patch('.lg-map{max-width:1200px;height:clamp(455px,67dvh,820px);margin:0 auto;position:relative;overflow:hidden;background:#151D26;border:1px solid #334252;border-radius:12px;touch-action:none}', '.lg-map{max-width:1200px;height:clamp(455px,67dvh,820px);margin:0 auto;position:relative;overflow:hidden;background:#151D26;border:1px solid #334252;border-radius:12px;touch-action:pan-y pinch-zoom}')
patch('.lg-map svg{width:100%;height:100%;display:block;user-select:none;-webkit-user-select:none}', '.lg-map svg{width:100%;height:100%;display:block;user-select:none;-webkit-user-select:none;touch-action:pan-y pinch-zoom}')
# Tie full screen map, graph and inspector to the Atlas CSS owner (not an audit override layer).
patch('/* Atlas outline remains keyboard-operable and uses the same quiet materials. */','''/* Atlas browse/exploration layout owner. The browse map allows native document gestures. */
.lg-explore-action{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:8px 14px;border:1px solid var(--edge);border-radius:6px;background:var(--paper);color:var(--ink);font-size:14px;font-weight:600}
.lg-explore-fullscreen{position:fixed;inset:0;z-index:110;overflow-y:auto;overscroll-behavior:contain;max-width:none!important;padding:18px max(16px,env(safe-area-inset-left)) max(20px,env(safe-area-inset-bottom))!important;background:var(--paper);height:100dvh}
.lg-explore-fullscreen .lg-map{height:min(64dvh,850px)!important;touch-action:none}
.lg-explore-fullscreen .lg-map svg{touch-action:none}
.lg-explore-fullscreen .lg-inspector{max-height:none;overflow:visible}
.lg-inspector{max-height:none;overflow:visible}
@media(max-width:600px){.lg-connection-filter{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));align-items:stretch}.lg-connection-filter button{min-width:0;min-height:44px;justify-content:flex-start;font-size:13px}.lg-explore-fullscreen .lg-map{height:55dvh!important;min-height:260px!important}}
/* Atlas outline remains keyboard-operable and uses the same quiet materials. */''')
patch('.lemma-proposal-layout>#lemma-proposal-detail{grid-column:2;grid-row:1;scroll-margin-top:20px;max-height:60dvh;overflow:auto}', '.lemma-proposal-layout>#lemma-proposal-detail{grid-column:2;grid-row:1;scroll-margin-top:20px;max-height:none;overflow:visible}')
patch('html[data-theme=graph]{--early:#196c42;--ink-3:#526278;--ink-4:#617086;--late:#795100;--accent:#b92f26;--on-accent:#fff;--hair:#1b2a4126;--edge:#aab4c0}', 'html[data-theme=graph]{--early:#196c42;--ink-3:#5b687b;--ink-4:#617086;--late:#795100;--accent:#b92f26;--on-accent:#fff;--hair:#1b2a4126;--edge:#778596}')
patch('html[data-theme=graph-night]{--ink-3:#b0bdcd;--ink-4:#a0aebf;--late:#f2c17e;--edge:#526174;--on-accent:#182029}', 'html[data-theme=graph-night]{--ink-3:#8190a3;--ink-4:#a0aebf;--late:#f2c17e;--edge:#718197;--on-accent:#182029}')
# Replace main content bottom spacing policy with an observed shell CSS variable and expose source-owned selectors.
# Existing dock positioning constants are only touched where an equivalent component now exists.
patch('html{--ctl:44px;--tab:68px}', 'html{--ctl:44px;--tab:56px}')
patch('nav[aria-label="Main navigation"] a>span:last-child{font-size:11px!important;line-height:15px!important;display:block!important;white-space:nowrap}', 'nav[aria-label="Main navigation"] a>span:last-child{font-size:12px!important;line-height:16px!important;display:block!important;white-space:normal}')
# Restore origin and set explicit min button areas for session dock via existing owner block.
old='.cr-mobile-dock{display:none;position:fixed;z-index:26;bottom:calc(var(--tab,64px) + env(safe-area-inset-bottom) + 7px);left:12px;right:12px;max-width:500px;margin:auto;background:var(--paper);border:1px solid var(--edge);border-radius:5px;box-shadow:0 2px 10px #0002;padding:6px 10px;align'
assert base.count(old)==1
patch(old,old.replace('bottom:calc(var(--tab,64px) + env(safe-area-inset-bottom) + 7px)','bottom:calc(var(--tab,56px) + env(safe-area-inset-bottom))').replace('left:12px;right:12px;max-width:500px;','left:0;right:0;max-width:600px;').replace('padding:6px 10px;','padding:0 8px;min-height:44px;'))
# Standalone reconciliation: no new audit CSS block appended; actual old selectors updated.
(ROOT/'inline-patches.json').write_text(json.dumps(patches,indent=2,ensure_ascii=False)+'\n')
print('inline patches',len(patches))
