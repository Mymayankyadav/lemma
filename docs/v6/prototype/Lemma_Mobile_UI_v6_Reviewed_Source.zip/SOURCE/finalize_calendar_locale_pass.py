#!/usr/bin/env python3
"""Package this standalone continuation and record only the checks actually completed."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
root=Path(__file__).resolve().parent; out=root.parent
html=root/'Lemma_UI_Remediated.html'; digest=hashlib.sha256(html.read_bytes()).hexdigest()
report=root/'IMPLEMENTATION_REPORT.md'
s=report.read_text()
s=re.sub(r'(- Updated standalone artifact: `Lemma_UI_Remediated.html`, SHA-256 `)[a-f0-9]{64}(`\.)',lambda m:m[1]+digest+m[2],s,count=1)
s=s.replace('Complete event-editor accessibility, all time zones, repeated-hour user selection and 12/24-hour formatting remain open.','Complete event-editor accessibility, all time zones, repeated-hour user selection and cross-shell clock-preference propagation remain open. Native Calendar Agenda/Day labels now apply its existing 12/24-hour selection.')
s=s.replace('**W01:** user-selected IANA time zone and explicit 12/24-hour preference, coherent across the calendar shell and saved blocks; completed account-scope/provenance contract across Project/Insights and the scheduler.', '**W01:** user-selected IANA time zone and 12/24-hour preference across the *entire* app (Calendar Agenda/Day now obey the setting); completed account-scope/provenance contract across Project/Insights and the scheduler.')
s=s.replace('a later full rerun stalled.', 'a later full rerun stalled. The selected Calendar Week 320/390/768 and 200%-text states are now separately verified.')
if '## Continuation: 3 November 2026 — civil-date planning and Calendar clock preference' not in s:
 s+='''\n\n## Continuation: 3 November 2026 — civil-date planning and Calendar clock preference

This incremental change is entirely within the offline working copy. No GitHub, Supabase, live account data, or scheduled agents were accessed or changed. The immutable original HTML and all 78 module import identifiers are unchanged.

1. **W01/W13 — date-safe quick capture and shutdown:** The native Calendar quick-capture parser now resolves `today` and `tomorrow` from the device's current local civil date, instead of fixed November 1–2 strings. Closing the day now carries selected work to the next local date. The Shutdown card calculates *logged today* from the shared saved-effort selector and reads *daily intention* from the saved daily budget rather than showing an unrelated all-time sum and hardcoded 4h target. A new deadline defaults to 14 local calendar days from creation, not a hardcoded November date.
2. **W13 — backward planning safeguards:** Planning uses the actual number of intervening **local calendar dates** (avoiding DST duration assumptions). At or after 18:01, the first generated 18:00 evening block is tomorrow, not a date/time already past. Dates at/after the deadline are excluded. If no usable planning days exist, the dialog explains why and offers no approval button; the save handler rechecks the date. Generated block identity uses `bw:<deadline-id>:<local-date>` so repeating the action does not create a second block for that same deadline/date. Existing blocks remain intact; this local fixture does not automatically resolve conflicts with other calendar events.
3. **W13 — functioning 12/24-hour display preference:** The existing Day preferences editor already persisted `clock`; it now controls visible and accessible Agenda and Day/Week spatial time labels, hour ruler, now cursor, and conflict details. Stored `HH:mm` fields, original event instants, native time inputs, and drag mathematics remain unchanged. In 12h mode, a block is presented as `6:04 AM–6:29 AM`; selecting 24h returns to `06:04–06:29`. This is **not** an implementation of arbitrary user-selected IANA time zones or fully shared clock preference outside the native Calendar.
4. **W13/W18 — readable seven-day Week overview:** On narrow screens the overview is a two-row grid with seven day controls of at least 44px, each showing a visible `N blocks` count and full accessible label, plus the existing Full week option. The native layout decides whether seven timeline columns fit the available viewport budget. The original 4-view Calendar, event editing, drag/resize and Tools remain available.
5. **W19 — local owner changes:** Clock and civil-date helpers are included in `#lemma-native-calendar-runtime` via the existing deterministic inline-patch system. The Week CSS is changed within its existing native-calendar owner declaration rather than appending another global audit override.

### Verified during this continuation

| Check | Result |
| --- | --- |
| `python evidence/verify_calendar_locale_and_planning.py` | **Pass**: Asia/Kolkata UI shows 12h Agenda and Day labels, toggles to 24h, creates a +14-day deadline, and generates only future evening blocks at the tested after-18:00 time; saved clock survives route remount; no page JS errors. A full browser reload was **not** verified by this test. |
| `python evidence/verify_calendar_reflow.py` | **Pass**: Week at 320×640, 390×844, 390×844 at 200% root text, 768×1024, and 390×844 Night. Seven day targets on narrow screens are ≥44px, no page-level horizontal overflow or page errors. |
| `python evidence/verify_capture_and_closure.py` | **Pass**: Shutdown dialog labels both logged today and daily intention in the mounted Calendar view; no page errors. The separate Quick Capture internal-route test could not mount via its direct hash URL, so its browser-path verification remains **open**. |
| `TZ=America/New_York node evidence/test_calendar_elapsed.js` and `TZ=Asia/Kolkata node evidence/test_calendar_elapsed.js` | **Pass**: 23h/25h DST day boundaries, ordinary 24h days and original overlap fixtures. |
| `TZ=Asia/Kolkata node evidence/test_effort_metrics.js`, `TZ=America/New_York node evidence/test_effort_metrics.js`, `node evidence/test_timer_intervals.js` | **Pass**: saved-effort and timer regression logic. |
| `node --check` all 78 editable JavaScript modules; `node --check evidence/calendar_runtime.js` | **Pass**. |
| `python repack.py pack && python repack.py verify` | **Pass**: byte-identical deterministic offline build, SHA-256 `{digest}`. |

**Still not accepted:** W01 full account/provenance consistency, a user-selected display time zone and DST repeated-hour editing, W13 full keyboard/touch event-controls matrix, W15 2,500-node Atlas stress/accessibility checks, W16 backend partial/unknown-result reconciliation, W18 entire browser/screen-reader/theme matrix, and W19 full token/CSS consolidation. This remains an offline demo HTML and does not prove production data semantics.
'''.replace('{digest}',digest)
report.write_text(s)
build=root/'BUILD.md';btext=build.read_text()
if '## Calendar civil-date and clock work' not in btext:
 build.write_text(btext+'''\n## Calendar civil-date and clock work (W01/W13)\n\nThe native Calendar's saved 12/24-hour preference now formats display labels, not its canonical time fields. Civil-day quick capture, next-day carry, deadline defaults, and future-only backward scheduling live in the existing source-owner inline patches. Inspect `continue_calendar_clock_and_dates.py` for the one-time transformation logic; **do not rerun it** over already-edited `inline-patches.json`. Use `python repack.py pack` and `python repack.py verify` for rebuilding. Focused browser checks: `evidence/verify_calendar_locale_and_planning.py`, `evidence/verify_calendar_reflow.py`, and `evidence/verify_capture_and_closure.py`. Browser scripts run against the known container paths; adjust them when extracting elsewhere.\n''')
(root/'evidence'/'verify_capture_and_closure.py').write_text((root/'evidence'/'verify_capture_and_closure.py').read_text().replace('capture/shutdown date and scope checks','shutdown scope checks'))
(root/'evidence'/'probe_calendar_locale.py').unlink(missing_ok=True)
shutil.copy2(html,out/'Lemma_UI_Remediated.html')
shutil.copy2(report,out/'Lemma_UI_Remediation_Report.md')
zip_path=out/'Lemma_UI_Remediation_Source.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for f in sorted(root.rglob('*')):
  if f.is_file() and not f.name.startswith('.') and f.suffix!='.pyc' and '__pycache__' not in f.parts:
   z.write(f,'lemma-ui-remediation/'+str(f.relative_to(root)))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert z.read('lemma-ui-remediation/Lemma_UI_Remediated.html') == html.read_bytes()
 print('Validated ZIP:',len(z.namelist()),'files,',zip_path.stat().st_size,'bytes')
print('Updated HTML SHA-256:',digest)
for f in [out/'Lemma_UI_Remediated.html',out/'Lemma_UI_Remediation_Source.zip',out/'Lemma_UI_Remediation_Report.md']:
 assert f.exists() and f.stat().st_size>1000
 print('Verified:',f,f.stat().st_size)
