#!/usr/bin/env python3
"""One-time independent edit to the canonical detached Atlas module. No repo writes."""
from pathlib import Path
root=Path(__file__).resolve().parent
path=root/'modules/53__index-DcUkykC4.js'
s=path.read_text()
def once(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old))
 s=s.replace(old,new,1)
once('''  const [selected, setSelected] = (0, k.useState)(null);
  const inspectorRef=''', '''  const [selected, setSelected] = (0, k.useState)(null);
  // Page of directly visible siblings in the bounded phone overview. This does not
  // modify the concept graph, its relationships, or the full-screen exploration.
  const [atlasPages,setAtlasPages]=(0,k.useState)(new Map());
  const inspectorRef=''')
start='''    const nodes = [],
      byId = new Map(),
      roots = tree.roots.filter((id) => tree.nodes.has(id));
    const weights = new Map();'''
new='''    const nodes = [],
      byId = new Map(),
      roots = tree.roots.filter((id) => tree.nodes.has(id));
    // Bounded mobile browse overview: a named parent plus legible child cells.
    // The original radial graph is retained unchanged for Explore map / desktop.
    if(!isFullscreen && size.w<600){
      const picked=selected?tree.nodes.get(selected):null;
      const parentId=picked?(picked.children?.length?picked.id:picked.parentId):null;
      const parent=parentId?tree.nodes.get(parentId):null;
      const ids=(parent?parent.children:roots).filter(id=>tree.nodes.has(id));
      const cols=Math.max(1,Math.floor((size.w-32)/152));
      const rows=Math.max(1,Math.floor((size.h-158)/72));
      const capacity=Math.min(12,cols*rows);
      const key=parentId||'__subjects';
      const page=Math.max(0,atlasPages.get(key)||0);
      const pages=Math.max(1,Math.ceil(ids.length/Math.max(1,capacity-(ids.length>capacity?1:0))));
      const startIndex=page>=pages?0:page*Math.max(1,capacity-1);
      const moreAtEnd=ids.length>startIndex+capacity;
      const showCount=moreAtEnd?Math.max(0,capacity-1):capacity;
      const visibleIds=ids.slice(startIndex,startIndex+showCount);
      const cellWidth=(size.w-32)/cols;
      const invZoom=1/Math.max(.3,zoom);
      const place=(id,node,col,row,depth,cluster=false)=>{
        const px=16+(col+.5)*cellWidth-size.w/2;
        const py=134+row*72-size.h/2;
        const pt={id,node,x:px*invZoom,y:py*invZoom,depth,parentId,compact:true,
          cellWidth:(cellWidth-8)*invZoom,cellHeight:64*invZoom,cluster};
        nodes.push(pt);byId.set(id,pt);
      };
      if(parent){
        const py=62-size.h/2;
        const pt={id:parentId,node:parent,x:0,y:py*invZoom,depth:0,parentId:parent.parentId,
          compact:true,cellWidth:Math.min(size.w-32,280)*invZoom,cellHeight:68*invZoom};
        nodes.push(pt);byId.set(parentId,pt);
      }
      visibleIds.forEach((id,i)=>place(id,tree.nodes.get(id),i%cols,Math.floor(i/cols),parent?1:0));
      if(moreAtEnd){
        const count=ids.length-(startIndex+showCount);
        const id='__atlas-more-'+key;
        place(id,{name:count+' more '+(parent?'concepts':'subjects'),children:[],status:'unseen'},
          visibleIds.length%cols,Math.floor(visibleIds.length/cols),parent?1:0,true);
      }
      const edges=[];
      if(parent)visibleIds.forEach(id=>edges.push({a:parentId,b:id,kind:'structure',count:1}));
      if(edgeMode!=='structure')for(const link of tree.links){
        const kind=link.kind==='related'?'related':'prereq';
        if((edgeMode==='all'||edgeMode===kind)&&byId.has(link.fromId)&&byId.has(link.toId)&&link.fromId!==link.toId)
          edges.push({a:link.fromId,b:link.toId,kind,count:1});
      }
      return {nodes,edges,compact:true,remaining:Math.max(0,ids.length-visibleIds.length),branchId:parentId};
    }
    const weights = new Map();'''
once(start,new)
once('''  }, [tree, open, edgeMode]);
  (0, k.useEffect)(() => {
    if (!focusRequest.current) return;
    const pt = graph.nodes.find((n) => n.id === focusRequest.current);''','''  }, [tree, open, edgeMode, isFullscreen, size.w, size.h, zoom, selected, atlasPages]);
  (0, k.useEffect)(() => {
    if (!focusRequest.current) return;
    if(graph.compact){focusRequest.current=null;setPan({x:0,y:0});return}
    const pt = graph.nodes.find((n) => n.id === focusRequest.current);''')
anchor='''    return H(
      "g",
      {
        key: n.id,
        "data-lx-node": n.id,'''
assert s.count(anchor)==1
# Inject compact renderer with consistent SVG button behavior; label may wrap to
# two lines, but full unabridged name remains in accessible name and inspector.
compact='''    if(n.compact){
      const labelText=String(node.name||'Unnamed concept');
      const textWidth=Math.max(10,Math.floor((n.cellWidth*zoom-20)/7));
      const words=labelText.split(/\\s+/);let lines=[''];
      for(const word of words){
        const i=lines.length-1,joined=(lines[i]?lines[i]+' ':'')+word;
        if(joined.length<=textWidth){lines[i]=joined;continue}
        if(lines[i]&&lines.length<2){lines.push(word);continue}
        if(!lines[i])lines[i]=word;
        else lines[i]+=' '+word;
      }
      if(lines.length>2)lines=lines.slice(0,2);
      if(lines[lines.length-1].length>textWidth)lines[lines.length-1]=lines[lines.length-1].slice(0,Math.max(4,textWidth-1)).trimEnd()+'…';
      const action=()=>{
        if(n.cluster){
          const key=n.parentId||'__subjects',page=atlasPages.get(key)||0;
          setAtlasPages(prev=>new Map(prev).set(key,page+1));
          return;
        }
        fold(n.id);
      };
      const lineHeight=17/Math.max(.3,zoom),font=14/Math.max(.3,zoom);
      return H('g',{
        key:n.id,'data-lx-node':n.id,'data-ui':'atlas-compact-cell',
        'data-cluster':n.cluster?'true':undefined,
        role:'button',tabIndex:0,
        'aria-label':labelText+(n.cluster?', show next group':isParent?(expanded?', collapse children':', expand children'):', inspect idea'),
        'aria-pressed':isActive,'aria-expanded':isParent?expanded:undefined,
        onClick:action,onKeyDown:e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();action()}},
        transform:`translate(${n.x},${n.y})`,style:{cursor:'pointer'},
      },
      H('rect',{x:-n.cellWidth/2,y:-n.cellHeight/2,width:n.cellWidth,height:n.cellHeight,
         rx:5,fill:'var(--paper)',stroke:isActive?'var(--accent)':'var(--ink-3)',
         strokeWidth:isActive?2.5:1.3,strokeDasharray:n.cluster?'5 4':undefined}),
      H('circle',{cx:-n.cellWidth/2+12/zoom,cy:0,r:5/zoom,fill:n.cluster?'var(--ink-3)':nodeFill}),
      H('text',{x:-n.cellWidth/2+23/zoom,y:lines.length===1?4/zoom:-4/zoom,
        fontSize:font,fontFamily:'Instrument Sans, sans-serif',fill:'var(--ink)',fontWeight:isActive?700:500,
        pointerEvents:'none'},...lines.map((line,i)=>H('tspan',{key:i,x:-n.cellWidth/2+23/zoom,dy:i===0?0:lineHeight},line)))
      );
    }
'''
once(anchor,compact+anchor)
# Compact graph no unlabelled circular nodes. Display accurate visible count in overview.
once('''        graph.nodes.length,
        " nodes · Tap a parent to ",''','''        graph.compact?graph.nodes.filter(n=>!n.cluster).length:graph.nodes.length,
        graph.compact?" labeled concepts shown · ":" nodes · Tap a parent to ",''')
# Expose ancestor route for inspecting nearby nodes without losing parent context.
anchor='''    H(
      "div",
      { className: "lg-map", "data-atlas-graph": "true", ref: canvasRef },'''
assert s.count(anchor)==1
new='''    selected&&tree&&H('nav',{'aria-label':'Atlas ancestors',className:'lg-atlas-ancestors'},
      H('button',{type:'button',onClick:()=>{setSelected(null);setPan({x:0,y:0})}},'All subjects'),
      ...(()=>{const result=[];let id=selected,guard=0;
        while(id&&guard++<15){const node=tree.nodes.get(id);if(!node)break;result.unshift(node);id=node.parentId}
        return result.map(n=>H('button',{key:n.id,type:'button',onClick:()=>reveal(n.id)},n.name));
      })()),
'''+anchor
once(anchor,new)
path.write_text(s)
print('Atlas modified, bytes',len(s))
