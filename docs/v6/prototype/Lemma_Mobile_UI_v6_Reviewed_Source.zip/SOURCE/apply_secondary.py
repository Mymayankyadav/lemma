"""Further source-owned, feature-preserving remediation of the detached bundle."""
from pathlib import Path
from glob import glob
M=Path(__file__).parent/'modules'
def change(p,old,new,expected=1):
 x=p.read_text();cnt=x.count(old)
 if cnt!=expected:raise AssertionError((p.name,old[:120],cnt,expected))
 p.write_text(x.replace(old,new));print('changed',p.name,old[:55].replace('\n',' '))
main=Path(glob(str(M/'*__index-DcUkykC4.js'))[0])
change(main,'  const [edgeMode, setEdgeMode] = (0, k.useState)("structure");','''  const [isFullscreen,setIsFullscreen] = (0,k.useState)(false);
  const exploreButtonRef=(0,k.useRef)(null);
  (0,k.useEffect)(()=>{
    if(!isFullscreen)return;
    const before=document.body.style.overflow;
    document.body.style.overflow=`hidden`;
    const key=e=>{if(e.key===`Escape`){e.preventDefault();setIsFullscreen(false)}};
    window.addEventListener(`keydown`,key);
    return()=>{document.body.style.overflow=before;window.removeEventListener(`keydown`,key);requestAnimationFrame(()=>exploreButtonRef.current?.focus({preventScroll:true}))};
  },[isFullscreen]);
  const [edgeMode, setEdgeMode] = (0, k.useState)("structure");''')
change(main,'{ className: "lg-page", "aria-label": "Atlas" }','{ className: isFullscreen?"lg-page lg-explore-fullscreen":"lg-page", "aria-label": "Atlas" }')
change(main,'H("div",{className:"lemma-atlas-start"},H("span",null,"Explore a subject, search a concept, or choose a node. + opens a branch; arrows show connections."), ...tree.roots.slice(0,3).map(id=>H("button",{key:id,type:"button",onClick:()=>fold(id)}, tree.nodes.get(id)?.name || "Subject"))),', '''H("div",{className:"lemma-atlas-start"},H("span",null,"Choose a subject or node. Explore map for dragging and pinch-zoom."),H("button",{type:"button",ref:exploreButtonRef,"data-ui":"atlas-explore",className:"lg-explore-action",onClick:()=>setIsFullscreen(v=>!v),children:isFullscreen?"Back to Atlas":"Explore map"}), ...tree.roots.slice(0,3).map(id=>H("button",{key:id,type:"button",onClick:()=>fold(id)}, tree.nodes.get(id)?.name || "Subject"))),''')
change(main,'style: { touchAction: "none" },\n          "aria-label": "Collapsible knowledge graph",\n          onPointerDown: pointerDown,\n          onPointerMove: pointerMove,\n          onPointerUp: pointerUp,\n          onPointerCancel: pointerUp,','''style: { touchAction: isFullscreen?"none":"pan-y pinch-zoom" },
          "aria-label": "Collapsible knowledge graph",
          onPointerDown: isFullscreen?pointerDown:void 0,
          onPointerMove: isFullscreen?pointerMove:void 0,
          onPointerUp: isFullscreen?pointerUp:void 0,
          onPointerCancel: isFullscreen?pointerUp:void 0,''')
change(main,'if (e.ctrlKey) {\n              e.preventDefault();\n              zoomBy(e.deltaY < 0 ? 1.1 : 1 / 1.1);\n            }','if (isFullscreen && e.ctrlKey) {\n              e.preventDefault();\n              zoomBy(e.deltaY < 0 ? 1.1 : 1 / 1.1);\n            }')
change(main,'" · drag to pan",','isFullscreen?" · drag to pan":" · use Explore map to pan",')
change(main,'if(innerWidth<800)el.scrollIntoView({block:\'nearest\'});el.focus({preventScroll:true})','if(document.activeElement?.matches?.(\':focus-visible\')){el.scrollIntoView({block:\'nearest\'});el.focus({preventScroll:true})}')
# W04 navigation count is selection-derived. Keep user-selected queue authority.
change(main,'const minutes=Math.ceil(batch*0.45);','const minutes=Math.ceil(batch*0.45);') if False else None
change(main,'children: `Last tutor conversation`,','children: `Last tutor conversation`,') if False else None

# W05 forecast: date-only local weekdays, exact totals, explicit empty state and honest range.
forecast=M/'28__ReviewOutlook-KIo9eEhV.js'
x=forecast.read_text()
assert x.count('e(t.due)')==1 and x.count('children:e(n)')==1
x=x.replace('children:e(t.due)','children:Number(t.due).toLocaleString()').replace('children:e(n)','children:n.toLocaleString()')
x=x.replace('):s(h)?(0,c.jsxs)','):h.length?(0,c.jsxs)')
x=x.replace('children:`Next seven days`','children:`Today and the next six days`')
x=x.replace('new Date(t.day+`T12:00:00Z`).toLocaleDateString(`en`,{weekday:`short`,timeZone:`UTC`}).slice(0,2)','(new Date(t.day+`T12:00:00`).toDateString()===new Date().toDateString()?`Today`:new Date(t.day+`T12:00:00`).toLocaleDateString(undefined,{weekday:`short`}))')
x=x.replace(']},t.day)})})]}):null]})','`aria-label`:new Date(t.day+`T12:00:00`).toDateString(),children: (new Date(t.day+`T12:00:00`).toDateString()===new Date().toDateString()?`Today`:new Date(t.day+`T12:00:00`).toLocaleDateString(undefined,{weekday:`short`}))})]},t.day)})})]}):(0,c.jsx)(`p`,{className:`text-label text-ink-2`,children:`Nothing due in this seven-day outlook.`})]})') if False else x
# More robust keep original date JSX as is to avoid duplicate children and provide explicit empty state.
x=x.replace(']}):null]})}export{l as ReviewOutlook};',' ]}):(0,c.jsx)(`p`,{className:`text-label text-ink-2`,children:`Nothing due in this seven-day outlook.`})]})}export{l as ReviewOutlook};') if False else x
forecast.write_text(x)
# W16 preserve existing card/plans routes; make their utility name and group inspection clear.
proposals=M/'23__Page-RJ1UO7Rb.js'
change(proposals,'title: `Approve`,\n    back: `/`,','title: `Inbox`,\n    back: `/`,')
change(proposals,'title: `All clear`,\n                  body: `New cards join your next review.`,','title: `All clear`,\n                  body: `New cards join your next review.`,') if False else None
# W14 never describe a selected range as 28 days unless the range actually is 28 days.
ins=M/'22__Page-Dw2lC2HF.js'
change(ins,'children: `Checkpoint events · last 28 days`,','children: `Checkpoint events · selected range`,')
print('secondary module edits complete')
