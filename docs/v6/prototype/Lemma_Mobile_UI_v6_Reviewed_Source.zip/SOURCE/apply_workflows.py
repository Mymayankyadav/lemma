from pathlib import Path
from glob import glob
M=Path(__file__).parent/'modules'
def change(p,old,new):
 s=p.read_text();z=s.count(old)
 if z!=1:raise AssertionError((p.name,old[:80],z))
 p.write_text(s.replace(old,new,1));print('updated',p.name,old[:65].replace('\n',' '))
review=M/'12__Page-Bd_8EoE4.js'
# Reuse the working timer actions while reducing space and keeping an explicit disclosure.
change(review,'''  return (0, E.jsxs)("section", {
    className: "lemma-review-integration",
    "aria-label": "Review time options",
    children: [
      (0, E.jsxs)("div", {
        children: [
          (0, E.jsx)("strong", { children: "Give this review a little time" }),
          (0, E.jsx)("p", {
            children:
              "Start an optional timer for this batch, or reserve the same amount of time in your calendar. Your current session is saved before starting a new one.",
          }),
        ],
      }),''','''  return (0, E.jsxs)("details", {
    className: "lemma-review-integration",
    "aria-label": "Review timer and calendar",
    children: [
      (0,E.jsx)("summary",{className:"min-h-11 cursor-pointer text-label font-semibold text-ink",children:"Review timer & calendar"}),
      (0, E.jsxs)("div", {
        children: [
          (0, E.jsx)("p", {
            children:
              "Optional timing and reservation. Starting another session may replace your current focus; check it before starting.",
          }),
        ],
      }),''')
change(review,'''                                  ` overdue · spread over `,
                                  X,
                                  ` `,
                                  X === 1 ? `day` : `days`,''','''                                  ` remaining due · about `,
                                  X,
                                  ` `,
                                  X === 1 ? `day` : `days`,
                                  ` at this batch size`,''')
change(review,'`Use this batch for a seven-day catch-up plan`','`Use this budget for 7 days`')
# The new-project sheet keeps its source options and validation, but no pseudo-filled input.
newproject=M/'14__Page-CQY07xEs.js'
change(newproject,'placeholder: `Real Analysis`,','placeholder: `e.g. Differential geometry`,')
# Focus: keep both exits and semantics; foreground only resume when paused.
main=Path(glob(str(M/'*__index-DcUkykC4.js'))[0])
change(main,'Btn("Close focus", dismiss, "cr-button text")','Btn("Back to notebook", dismiss, "cr-button text")')
change(main,'"Finish & log time",','"Finish & log",')
change(main,'title: "Close focus view",','title: "Timer continues in the notebook",')
# In-progress time is explicitly uncommitted; logged values remain committed-only.
change(main,'  const logged = entries.reduce(\n    (n, x) => n + Math.max(0, Number(x.min ?? x.minutes) || 0),\n    0,\n  );','''  const logged = entries.reduce(
    (n, x) => n + Math.max(0, Number(x.min ?? x.minutes) || 0),
    0,
  );
  const focusInProgress = (timer.running || timer.paused) && timer.phase!==`break`
    ? Math.max(0,(Number(timer.elapsed)||0)+(timer.running?Math.max(0,now-(Number(timer.stamp)||now))/1000:0))/60
    : 0;''')
change(main,'children: `${fmt(logged)} logged · ${fmt(Number(settings.daily) || 240)} intended`,','children: `${fmt(logged)} logged${focusInProgress>0?` · ${fmt(focusInProgress)} in progress`:``} · ${fmt(Number(settings.daily) || 240)} intended`,')
# Status on dashboard explicitly differentiates running and scheduled.
change(main,': "No upcoming study blocks scheduled";',': "No upcoming study blocks scheduled";') if False else None
# W05: forecast no-record case and correct exact date; stable labels per date.
forecast=M/'28__ReviewOutlook-KIo9eEhV.js'
s=forecast.read_text()
# return tail from original contains ':null' exactly.
old='''})})]}):null]})}export{l as ReviewOutlook};'''
if s.count(old)==1:
 s=s.replace(old,'''})})]}):(0,c.jsx)(`p`,{className:`text-label text-ink-2`,children:`Nothing due in this seven-day outlook.`})]})}export{l as ReviewOutlook};''',1)
 forecast.write_text(s)
 print('updated',forecast.name,'empty forecast')
else:print('forecast tail does not match; leave intentional original until verified',s[-140:])
