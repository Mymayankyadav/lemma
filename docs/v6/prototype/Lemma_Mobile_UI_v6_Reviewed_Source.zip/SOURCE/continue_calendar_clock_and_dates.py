#!/usr/bin/env python3
"""W01/W13 continued: civil-date-safe planner and existing clock-preference presentation.
Edits only detached inline-patch owners; does not contact or modify any repository.
"""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
path=root/'inline-patches.json'
patches=json.loads(path.read_text())
if any('crNextAvailableStudyDate' in p.get('new','') for p in patches):
    raise SystemExit('This clock-and-date migration is already applied; refusing duplicate patches')
current=(root/'Lemma_UI_Remediated.html').read_text()

def add(old,new,source):
    if current.count(old)!=1:
        raise AssertionError(f'{source}: requires unique current-build anchor; found {current.count(old)}: {old[:120]}')
    assert old != new
    patches.append({'old':old,'new':new})
    print('PATCH',source)

def slice_case(name,next_name):
    start=current.index("case'"+name+"':")
    stop=current.index("\ncase'"+next_name+"':",start)
    return current[start:stop]

helper='''// W01/W13: Calendar-only civil-date helpers. Date fields remain local dates, not UTC-midnight instants.
function crAddCalendarDays(base,n){return new Date(base.getFullYear(),base.getMonth(),base.getDate()+n,12)}
function crCivilDistance(endKey,startKey){
 const parse=key=>{const m=/^(\\d{4})-(\\d{2})-(\\d{2})$/.exec(String(key));return m?Date.UTC(+m[1],+m[2]-1,+m[3]):NaN};
 return Math.round((parse(endKey)-parse(startKey))/86400000);
}
function crNextAvailableStudyDate(now=new Date()){
 // A generated 18:00 block must never be inserted earlier than the time of acceptance.
 return crAddCalendarDays(now,(now.getHours()>18||now.getHours()===18&&now.getMinutes()>0)?1:0);
}
function crClockLabel(text){
 const m=/^([01]\\d|2[0-3]):([0-5]\\d)(.*)$/.exec(String(text));
 if(!m||S.settings.clock!=='12h')return String(text);
 const h=+m[1];return String(h%12||12)+':'+m[2]+' '+(h<12?'AM':'PM')+m[3];
}
'''
add('function parseCapture(text)',helper+'function parseCapture(text)','clock/civil helpers')
old="const d=s.includes('tmr')||s.includes('tomorrow')?'2026-11-02':'2026-11-01';"
new="const d=s.includes('tmr')||s.includes('tomorrow')?dkey(crAddCalendarDays(new Date(),1)):dkey(new Date());"
add(old,new,'capture today/tomorrow')
add("t.due='2026-11-02'","t.due=dkey(crAddCalendarDays(new Date(),1))",'shutdown next-day carry')
add("field('Date','cx-deadline-date','2026-11-20','date')","field('Date','cx-deadline-date',dkey(crAddCalendarDays(new Date(),14)),'date')",'new deadline initial date')

old=slice_case('backward','backward-save')
new='''case'backward':{
 const d=S.deadlines.find(x=>x.id===id);if(!d){toast('This deadline is no longer available.');break}
 const start=crNextAvailableStudyDate(),days=crCivilDistance(d.date,dkey(start));
 if(days<=0){modal('No future planning days',`<p class="cx-sub">${esc(d.title)} is due ${esc(d.date)}. Update the deadline before adding new evening study blocks; the planner will not schedule in the past.</p>`,btn('Close','close'));break}
 const min=Math.min(180,Math.ceil(d.hours*60/days/5)*5);
 modal('Start from the horizon.',`<div class="cx-form"><h3>${esc(d.title)}</h3><p class="cx-sub">${d.hours}h across ${days} local calendar days before ${esc(d.date)}, starting ${dkey(start)}.</p><div class="cx-inset"><strong>${min} min per day</strong><p class="cx-caption">Spread out the practice. Keep the final day lighter.</p></div><p class="cx-caption">This preview adds short blocks on days before the deadline, capped at 3h/day, avoiding times already in the past. Existing generated blocks are left intact.</p></div>`,btn('Keep editing','close')+btn('Add practice blocks','backward-save','primary',`data-id="${id}"`));break}
'''.rstrip()
add(old,new,'backwards planning preview')
old=slice_case('backward-save','new-topic')
new='''case'backward-save':{
 const d=S.deadlines.find(x=>x.id===id);if(!d){toast('This deadline is no longer available.');break}
 const start=crNextAvailableStudyDate(),days=crCivilDistance(d.date,dkey(start));
 if(days<=0){toast('No future evening slots before this deadline.');close();break}
 snapshot();let remain=Math.max(0,Number(d.hours)||0)*60,added=0;
 for(let i=0;i<Math.min(60,days)&&remain>0;i++){
  const day=dkey(crAddCalendarDays(start,i)),generatedId='bw:'+d.id+':'+day;
  if(S.blocks.some(b=>b.id===generatedId))continue;
  const min=Math.min(180,Math.max(5,Math.ceil(remain/(days-i)/5)*5));
  S.blocks.push({id:generatedId,title:'Practice · '+d.title,subject:d.subject,date:day,at:'18:00',min});
  remain-=min;added++;
 }
 save();close();planTab='calendar';render();toast(added?'Added '+added+' practice blocks. Review your calendar.':'Practice blocks already present for this deadline.',true);break}
'''.rstrip()
add(old,new,'backwards planning commit')

# Keep local clock values 24-hour in the data model/inputs; format *only* visible labels.
add('function crSpatialBlocks(day){','function crSpatialBlocks(day){','NOOP') if False else None
add('title="${esc(b.title)} · ${esc(b.subject)} · ${b.at}–${endLabel(b)} · ${crStatusText[kind]}"', 'title="${esc(b.title)} · ${esc(b.subject)} · ${crClockLabel(b.at)}–${crClockLabel(endLabel(b))} · ${crStatusText[kind]}"','spatial tooltip clock')
add('<span id="block-time-${b.id}-${day}">${b.at}–${endLabel(b)} </span>', '<span id="block-time-${b.id}-${day}">${crClockLabel(b.at)}–${crClockLabel(endLabel(b))} </span>','spatial visible clock')
add('aria-label="${esc(b.title)}, ${esc(b.subject)}, ${b.at} to ${endLabel(b)}, ${crStatusText[status]}"', 'aria-label="${esc(b.title)}, ${esc(b.subject)}, ${crClockLabel(b.at)} to ${crClockLabel(endLabel(b))}, ${crStatusText[status]}"','agenda accessible clock')
add('<span>${b.at}–${endLabel(b)}</span><strong>', '<span>${crClockLabel(b.at)}–${crClockLabel(endLabel(b))}</span><strong>','agenda visible clock')
add("line.querySelector('span').textContent=crTime(minute);", "line.querySelector('span').textContent=crClockLabel(crTime(minute));",'now-line clock')
add("line.setAttribute('aria-label','Current time '+crTime(minute));", "line.setAttribute('aria-label','Current time '+crClockLabel(crTime(minute)));",'now-line clock accessible')
add('${crLocalClock(dkey(date),c.start)}–${crLocalClock(dkey(date),c.end)}','${crClockLabel(crLocalClock(dkey(date),c.start))}–${crClockLabel(crLocalClock(dkey(date),c.end))}','conflict clock')
# Hour tick changes only one inline expression, not the persisted 24-hour time values.
add("${String(i+crVisibleDayStartHour).padStart(2,'0')}:00", "${crClockLabel(String(i+crVisibleDayStartHour).padStart(2,'0')+':00')}", 'hour-ruler clock')
# The shutdown dialog currently counts all saved records but falsely calls them today.
old="${duration(S.entries.reduce((n,e)=>n+e.min,0))}</div><p class=\"cx-caption\">logged today</p>"
new="${duration(Math.round(window.__lemmaEffortMetrics?.forDay?.(S.entries,S.timer,dkey(new Date()))?.committedMinutes??S.entries.filter(e=>e.date===dkey(new Date())).reduce((n,e)=>n+(Number(e.min)||0),0)))}</div><p class=\"cx-caption\">logged today</p>"
add(old,new,'shutdown actual today metric')
# Edit the existing native-calendar style *owner*, not a new global override layer.
found=[p for p in patches if 'Week overview belongs to the native calendar' in p.get('new','')]
assert len(found)==1
p=found[0]
p['new']=p['new'].replace(r'font-size:12px}\n.cr-week-overview button.selected',r'font-size:.75rem}\n.cr-week-overview button.selected').replace(r'font-size:14px}\n.cr-conflict-action',r'font-size:.875rem}\n@media(max-width:440px){.cr-week-overview{grid-template-columns:repeat(4,minmax(0,1fr))}}\n.cr-conflict-action')
assert 'repeat(4,minmax(0,1fr))' in p['new']
# Existing 7-column timeline should only appear if the pane can actually fit 7x88px + gutter.
found=[p for p in patches if 'const compactWeek=view' in p.get('new','')]
assert len(found)==1
p=found[0]
assert 'innerWidth<600' in p['new']
p['new']=p['new'].replace('innerWidth<600','(Math.min(innerWidth,document.documentElement.clientWidth)-112)<7*88')
path.write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n')
print('Appended',len(patches),'total patches; 2 calendar style/layout owners updated')
