import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=45000)
  await page.evaluate('location.hash="#/insights"');await page.wait_for_timeout(1600)
  text=await page.locator('#root').inner_text()
  print('INSIGHTS',repr(text[:750]),flush=True)
  print('OTHER',repr(text[text.find('Time by subject'):text.find('Time by subject')+550]),flush=True)
  print('EXAMPLE BTN',await page.get_by_role('button',name='View example').count(),flush=True)
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'insights-continuation.png'),full_page=False)
  if await page.get_by_role('button',name='View example').count():
   await page.get_by_role('button',name='View example').click();await page.wait_for_timeout(100)
   print('EXAMPLE SHOWN',await page.locator('.cr-hour-bars').count(),flush=True)
   print('HOURS',(await page.evaluate("[...document.querySelectorAll('.cr-hour-bar')].map(e=>e.style.left)")),flush=True)
  print('ERRORS',errors,flush=True)
  await b.close()
asyncio.run(main())
