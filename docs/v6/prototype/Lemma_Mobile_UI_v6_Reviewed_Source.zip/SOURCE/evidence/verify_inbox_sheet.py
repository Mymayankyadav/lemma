import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:await page.route(pat,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda msg:print('CONSOLE',msg.type,msg.text[:800],flush=True) if msg.type=='error' else None)
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/proposals"');await page.wait_for_timeout(2800);print('ROOT',repr((await page.locator('#root').inner_text())[:700]),flush=True);print('PAGE ERRORS',errors,flush=True)
  trigger=page.get_by_role('button',name='Browse queue',exact=False)
  print('trigger count',await trigger.count(),'visible',await trigger.is_visible(),flush=True)
  if not await trigger.count():
   await b.close();return
  print('before',await page.locator('.lemma-proposal-queue').evaluate('(e)=>({display:getComputedStyle(e).display, height:e.getBoundingClientRect().height})'),flush=True)
  await trigger.click();await page.wait_for_timeout(250)
  dialog=page.get_by_role('dialog',name='Proposal groups')
  print('dialog',await dialog.count(),await dialog.is_visible(),flush=True)
  print('open',await page.locator('.lemma-proposal-queue').evaluate('(e)=>({position:getComputedStyle(e).position,overflow:getComputedStyle(e).overflowY,height:e.getBoundingClientRect().height,top:e.getBoundingClientRect().top,z:getComputedStyle(e).zIndex})'),flush=True)
  print('first focus',await page.evaluate('document.activeElement?.textContent'),flush=True)
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'inbox-queue-sheet.png'),full_page=False)
  await page.keyboard.press('Escape');await page.wait_for_timeout(150)
  print('closed',await page.locator('.lemma-proposal-queue').get_attribute('data-queue-open'),'focus',await page.evaluate('document.activeElement?.textContent'),flush=True)
  await trigger.click();await page.wait_for_timeout(150)
  select=page.locator('.lemma-proposal-queue [aria-label="Cards in this proposal group"] button').nth(1)
  await select.click();await page.wait_for_timeout(250)
  print('selected close',await page.locator('.lemma-proposal-queue').get_attribute('data-queue-open'),'detail',await page.locator('#lemma-proposal-detail').count(),flush=True)
  print('errors',errors[:5],flush=True)
  await b.close()
asyncio.run(main())
