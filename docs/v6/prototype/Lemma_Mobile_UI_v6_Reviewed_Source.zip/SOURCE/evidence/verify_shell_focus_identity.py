import asyncio
from pathlib import Path
from playwright.async_api import async_playwright

async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda route:route.abort())
  errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.get_by_text('Study time today',exact=True).first.wait_for(timeout=18000)
  result=await page.evaluate('''()=>{
    const store=window.__lemmaSessionStore,state=window.__carrelIntegration.getState(),now=Date.now();
    const incoming={...store.get(),sessionId:'browser-interval-check',startedAt:now-900000,
      activeStudyStart:now-120000,studyIntervals:[{start:now-900000,end:now-600000}],
      elapsed:420,stamp:now-1000,studyElapsed:0,mode:'open',phase:'study',
      running:true,paused:false,focus:50,activity:'Topology'};
    store.commit(incoming,'fixture',store.get()?.rev);
    window.__carrelIntegration.open('timer','finish');
    const matches=state.entries.filter(x=>x.id==='focus:browser-interval-check');
    window.__carrelIntegration.open('timer','finish');
    return {count:matches.length,total:state.entries.filter(x=>x.id==='focus:browser-interval-check').length,
      record:matches[0]&&{id:matches[0].id,minutes:matches[0].min,intervals:matches[0].intervals.length,
        approximate:matches[0].timeApproximate,projectId:matches[0].projectId}};
  }''')
  print('SHELL RECORD',result,flush=True)
  assert result['count']==result['total']==1,result
  assert result['record']['intervals']==2 and not result['record']['approximate'],result
  await page.evaluate('location.hash="#/calendar"')
  await page.locator('lemma-native-calendar').wait_for(timeout=20000)
  await page.wait_for_timeout(300)
  after=await page.evaluate('''()=>window.__carrelIntegration.getState().entries.filter(x=>x.id==='focus:browser-interval-check').length''')
  assert after==1,after
  assert not errors,errors
  print('PASS shell->Calendar: stable identity, two intervals, repeated Finish does not duplicate, no JS errors',flush=True)
  await b.close()
asyncio.run(main())
