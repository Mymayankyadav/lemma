import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:await page.route(pat,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/proposals"');await page.wait_for_timeout(1800)
  for theme in ['graph','graph-night']:
   await page.evaluate('(theme)=>document.documentElement.dataset.theme=theme',theme)
   for width,height,scale in [(320,640,1),(360,640,1),(390,844,1),(844,390,1),(768,1024,1),(1280,800,1),(390,844,2)]:
    await page.set_viewport_size({'width':width,'height':height})
    await page.evaluate('(scale)=>document.documentElement.style.fontSize=(16*scale)+"px"',scale)
    await page.wait_for_timeout(80)
    data=await page.evaluate('''() => {const btn=document.querySelector('.lemma-queue-mobile-trigger button');return {
      viewport:innerWidth,docW:document.documentElement.scrollWidth,
      triggerVisible:!!btn&&getComputedStyle(btn).display!=='none'&&btn.getBoundingClientRect().height>0,
      trigger:btn?{left:Math.round(btn.getBoundingClientRect().left),right:Math.round(btn.getBoundingClientRect().right)}:null,
      proposalVisible:!!document.querySelector('#lemma-proposal-detail'),
      root:document.getElementById('root')?.innerText?.slice(0,40)}}''')
    print(theme,width,height,scale,data,flush=True)
  print('ERRORS',errors,flush=True)
  await b.close()
asyncio.run(main())
