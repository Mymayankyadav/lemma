import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html'))
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  for k in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(k,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(HTML.read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/calendar"')
  await page.locator('lemma-native-calendar').wait_for(timeout=25000)
  await page.locator('lemma-native-calendar').locator('[data-cx="new-block"]').first.wait_for(timeout=25000)
  before=await page.evaluate('''() => {const s=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1')); return {running:s.timer.running,n:s.entries.length,stamp:s.timer.stamp,phase:s.timer.phase}}''')
  await page.evaluate('''() => {const r=document.querySelector('lemma-native-calendar').shadowRoot;let b=document.createElement('button');b.dataset.cx='finish';r.append(b);b.click();b.remove()}''')
  dialog=page.locator('lemma-native-calendar').locator('#cx-modal')
  await dialog.wait_for(timeout=15000)
  await page.locator('lemma-native-calendar').locator('[data-cx="session-skip"]').click()
  await page.wait_for_timeout(300)
  after=await page.evaluate('''() => {const s=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1'));let e=s.entries.filter(x=>x.id.startsWith('focus:')); return {running:s.timer.running,n:s.entries.length,focusLogs:e.map(x=>({id:x.id,minutes:x.min,start:x.start,end:x.end,approx:x.timeApproximate,segments:x.intervals?.length}))}}''')
  focusid=after['focusLogs'][0]['id']
  async def open_edit():
   await page.evaluate("""id => {const r=document.querySelector('lemma-native-calendar').shadowRoot;let b=document.createElement('button');b.dataset.cx='edit-entry';b.dataset.id=id;r.append(b);b.click();b.remove()}""",focusid)
  async def commit_edit():
   await page.evaluate("""() => {const r=document.querySelector('lemma-native-calendar').shadowRoot;let b=document.createElement('button');b.dataset.cx='entry-save';r.append(b);b.click();b.remove()}""")
  await open_edit()
  await page.locator('lemma-native-calendar').locator('#cx-entry-note').fill('Edited metadata only')
  await commit_edit()
  kept=await page.evaluate("""id=>{const e=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1')).entries.find(x=>x.id===id);return {note:e.note,segments:e.intervals,approx:e.timeApproximate,edited:e.editedTimeRange||false,minutes:e.min}}""",focusid)
  await open_edit()
  original_end=await page.locator('lemma-native-calendar').locator('#cx-entry-end').input_value()
  hh,mm=map(int,original_end.split(':'))
  changed_end=f'{(hh+1)%24:02d}:{mm:02d}'
  await page.locator('lemma-native-calendar').locator('#cx-entry-end').fill(changed_end)
  await commit_edit()
  replaced=await page.evaluate("""id=>{const e=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1')).entries.find(x=>x.id===id);return {start:e.start,end:e.end,segments:e.intervals,approx:e.timeApproximate,edited:e.editedTimeRange||false,minutes:e.min}}""",focusid)
  print(json.dumps({'before':before,'saved':after,'metadataOnly':kept,'editedTimes':replaced,'errors':errors},indent=2),flush=True)
  assert kept['note']=='Edited metadata only'
  assert kept['segments']==after['focusLogs'][0]['segments']*kept['segments']
  assert kept['minutes']==after['focusLogs'][0]['minutes']
  assert replaced['edited'] and replaced['approx'] and replaced['end']==changed_end
  assert len(replaced['segments'])==1 and not errors
  await browser.close()
asyncio.run(main())
