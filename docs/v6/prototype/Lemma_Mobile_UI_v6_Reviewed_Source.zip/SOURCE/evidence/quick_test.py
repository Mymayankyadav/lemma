from pathlib import Path
import asyncio,sys,time,json
from playwright.async_api import async_playwright
async def run():
 f=sys.argv[1] if len(sys.argv)>1 else str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  print('setting content',flush=True)
  await page.set_content(open(f).read(),wait_until='domcontentloaded',timeout=25000)
  print('content loaded',flush=True)
  try:await page.wait_for_function('''() => document.querySelector('#root')?.innerText.includes('Review') && !document.querySelector('#root')?.innerText.includes('Loading screen…')''',timeout=18000)
  except Exception as e:print('waiting error',str(e)[:150],flush=True)
  print('text',repr((await page.locator('#root').inner_text())[:150]),flush=True)
  await page.evaluate('location.hash="#/review"')
  await page.wait_for_timeout(1800)
  print('review text',repr((await page.locator('#root').inner_text())[:700]),flush=True)
  print('errors',errs[:5],flush=True)
  print('height',await page.evaluate('document.documentElement.scrollHeight'),flush=True)
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'review-after.png'),full_page=False)
  await b.close()
asyncio.run(run())
