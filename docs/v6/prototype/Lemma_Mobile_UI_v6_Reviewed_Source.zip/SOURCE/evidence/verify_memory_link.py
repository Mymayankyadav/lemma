import asyncio
from pathlib import Path
from playwright.async_api import async_playwright

async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pattern in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pattern, lambda route:route.abort())
  failures=[]
  page.on('pageerror',lambda error:failures.append(str(error)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/settings"')
  await page.wait_for_timeout(900)
  print('Settings excerpt',repr((await page.locator('#root').inner_text())[:1800]),flush=True)
  print('Settings html controls',await page.get_by_text('Reviews & calendar').count(),flush=True)
  await page.get_by_text('Reviews & calendar',exact=True).click()
  link=page.get_by_role('button',name='Edit in Memory')
  print('Edit controls',await link.count(),flush=True)
  assert await link.count()==1
  await link.click()
  state=await page.evaluate('''() => { const m=document.getElementById('lemma-memory-settings'); return {selected:document.activeElement===m, id:m?.id, scrollY:scrollY, input:m?.querySelector('input[type=range]')?.getAttribute('aria-valuetext'), rootWidth:document.documentElement.scrollWidth, windowWidth:innerWidth}; }''')
  print('MEMORY',state,flush=True)
  assert state['selected'] and state['input'] and state['rootWidth']<=state['windowWidth']
  assert not failures,failures
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'settings-memory-linked.png'))
  await browser.close()
asyncio.run(main())
