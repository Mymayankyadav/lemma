import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':390,'height':844})
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda r:r.abort())
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  for route in ['review','atlas']:
   await page.evaluate('(r)=>location.hash="#/"+r',route)
   await page.wait_for_timeout(1000)
   print('\n',route,flush=True)
   a=await page.evaluate('''()=>[...document.querySelectorAll('main button,main a[href],main input:not([type="hidden"])')].filter(e=>{const r=e.getBoundingClientRect();return r.width>4&&r.height>4&&(r.width<44||r.height<44)}).slice(0,15).map(el=>({tag:el.tagName,cls:String(el.className),html:el.outerHTML.slice(0,200),rect:{w:el.getBoundingClientRect().width,h:el.getBoundingClientRect().height}}))''')
   for x in a:print(x,flush=True)
  await b.close()
asyncio.run(main())
