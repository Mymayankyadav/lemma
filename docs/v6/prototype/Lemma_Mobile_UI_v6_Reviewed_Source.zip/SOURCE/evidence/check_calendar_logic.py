from pathlib import Path
import re,subprocess,tempfile
s=Path(str(Path(__file__).resolve().parent / 'calendar_runtime.js')).read_text()
m=re.search(r'function crDayWorkload\(day\)\{.*?\n\}\nlet crVisibleDayStartHour',s,re.S)
assert m
fn=m.group(0).rsplit('\nlet crVisibleDayStartHour',1)[0]
code='''const assert=require('node:assert/strict');
function crClockMin(t){const [h,m]=t.split(':').map(Number);return h*60+m}
function blocksForDay(){return [
{id:'a',at:'06:49',min:50},
{id:'b',at:'07:34',min:75},
{id:'c',at:'07:49',min:100}
]}
'''+fn+'''\nconst result=crDayWorkload('2026-11-03');
assert.equal(result.conflicts.length,2);assert.equal(result.affected,3);
assert.equal(result.sum,225);assert.equal(result.occupied,160);
assert.deepEqual(result.conflicts.map(x=>[x.a.id,x.b.id,x.start,x.end]),[['a','b',454,459],['b','c',469,529]]);
console.log(JSON.stringify({overlapPairs:result.conflicts.length,involvedBlocks:result.affected,sumMin:result.sum,occupiedMin:result.occupied}));
'''
p=Path(str(Path(__file__).resolve().parent / 'calendar-unit.js'));p.write_text(code)
print(subprocess.check_output(['node',str(p)],text=True).strip())
