import asyncio,sys,time,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  await page.route('**/fonts.googleapis.com/**',lambda r:r.abort());await page.route('**/fonts.gstatic.com/**',lambda r:r.abort());await page.route('**/cdn.jsdelivr.net/**',lambda r:r.abort())
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)[:300]))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=22000)
  for route in ['/review','/calendar','/atlas','/insights','/proposals','/today','/paths','/settings']:
   await page.evaluate('(h)=>location.hash=h','#'+route)
   try: await page.wait_for_function("!document.querySelector('#root')?.innerText?.includes('Loading screen…')",timeout=8000)
   except: pass
   await page.wait_for_timeout(500)
   data=await page.evaluate('''() => ({scrollHeight:document.documentElement.scrollHeight,scrollWidth:document.documentElement.scrollWidth,root:(document.querySelector('#root')?.innerText||'').slice(0,340),calendar:!!document.querySelector('lemma-native-calendar')?.shadowRoot,btns:document.querySelector('lemma-native-calendar')?.shadowRoot?.querySelectorAll('button').length || 0})''')
   print(route, json.dumps(data),flush=True)
   if route in ['/calendar','/atlas','/review','/proposals']:
    await page.screenshot(path=fstr(Path(__file__).resolve().parent / '{route[1:]}-updated.png'))
   if route=='/calendar':
    print('CAL_HTML',repr((await page.evaluate("document.querySelector('lemma-native-calendar')?.shadowRoot?.innerText||''"))[:600]),flush=True)
    try:
     await page.evaluate('''() => {const r=document.querySelector('lemma-native-calendar')?.shadowRoot;let b=[...r.querySelectorAll('button')].find(x=>x.textContent.trim()==='Week');if(b)b.click()}''')
     await page.wait_for_timeout(450)
     print('WEEK',await page.evaluate('''() => ({nav:[...document.querySelector('lemma-native-calendar')?.shadowRoot?.querySelectorAll('button')||[]].slice(0,15).map(x=>x.textContent.trim()),overview:document.querySelector('lemma-native-calendar')?.shadowRoot?.querySelectorAll('.cr-week-overview button').length})'''),flush=True)
     await page.screenshot(path=str(Path(__file__).resolve().parent / 'calendar-week-updated.png'))
    except Exception as e:print('weekerror',str(e)[:200])
  print('ERRORS',errs,flush=True)
  await b.close()
asyncio.run(main())
