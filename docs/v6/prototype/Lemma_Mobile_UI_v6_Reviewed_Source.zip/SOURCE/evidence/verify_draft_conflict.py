import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844})
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:await page.route(pat,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/proposals"');await page.wait_for_timeout(2100)
  print('root',(await page.locator('#root').inner_text())[:200],flush=True)
  await page.get_by_role('button',name='Edit card').click()
  print('edit opens',await page.get_by_role('button',name='Approve edits').count(),flush=True)
  await page.get_by_role('button',name='Save draft').click();await page.wait_for_timeout(250)
  print('save toast',(await page.locator('#root').inner_text())[:130],flush=True)
  print('keys',await page.evaluate('''() => {const k=[];for(let i=0;i<localStorage.length;i++)k.push(localStorage.key(i));return k.filter(s=>s.includes('proposal.draft'))}'''),flush=True)
  # Memory fallback lacks key enumeration; obtain ID from likely demo adapter via interceptor of getItem.
  await page.evaluate('''() => {
    const old=localStorage.getItem.bind(localStorage);
    localStorage.getItem=(key)=>{const s=old(key);if(String(key).startsWith('lemma.proposal.draft:')&&s){let d=JSON.parse(s);d.baseFront='stale original text';return JSON.stringify(d)}return s}
  }''')
  await page.get_by_role('button',name='Edit card').click();await page.wait_for_timeout(200)
  print('conflict present',await page.get_by_text('Proposal changed — review before approval').count(),flush=True)
  print('approve disabled',await page.get_by_role('button',name='Approve edits').is_disabled(),flush=True)
  if await page.get_by_role('button',name='Keep my draft after comparing').count():
   await page.get_by_role('button',name='Keep my draft after comparing').click()
   print('approve re-enabled',await page.get_by_role('button',name='Approve edits').is_enabled(),flush=True)
  print('errors',errors[:3],flush=True)
  await b.close()
asyncio.run(main())
