const path=require('node:path');
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const patch=JSON.parse(fs.readFileSync(path.join(__dirname,'..','inline-patches.json'),'utf8'));
const block=patch.find(x=>x.old.startsWith('const crTime=m=>')).new;
const stub=`const dkey=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');let S={blocks:[]};const crClockMin=t=>{const [h,m]=t.split(':').map(Number);return h*60+m;};`;
const raw=fs.readFileSync(path.join(__dirname,'calendar_runtime.js'),'utf8');
const blocks=raw.slice(raw.indexOf('function blocksForDay(day,split=false){'),raw.indexOf('function crSpatialBlocks(day){'));
const program=stub+'\n'+block+'\n'+blocks+'\n'+`(function(){
let info=crDayWorkload('2026-11-03');
S.blocks=[
{id:'a',date:'2026-11-03',at:'06:49',min:50},
{id:'b',date:'2026-11-03',at:'07:34',min:75},
{id:'c',date:'2026-11-03',at:'07:49',min:100},
{id:'m',date:'2026-11-03',at:'23:30',min:90},
];
info=crDayWorkload('2026-11-03');
assert.equal(info.sum,255);assert.equal(info.occupied,190);assert.equal(info.conflicts.length,2);assert.equal(info.affected,3);
assert.equal(info.dayMinutes,1440);
const next=crDayWorkload('2026-11-04');assert.equal(next.sum,60);assert.equal(next.occupied,60);
const carried=blocksForDay('2026-11-04',true);assert.equal(carried.length,1);assert.equal(carried[0].at,'00:00');assert.equal(carried[0].min,60);
S.blocks=[{id:'x',date:'2026-03-08',at:'01:30',min:120}];
const spring=crDayWorkload('2026-03-08');
const springNext=blocksForDay('2026-03-08',true);
S.blocks=[{id:'x',date:'2026-11-01',at:'01:30',min:120}];
const fall=crDayWorkload('2026-11-01');
return {overlapPairs:info.conflicts.length,involved:info.affected,midnightCarry:next.occupied,springDay:spring.dayMinutes,fallDay:fall.dayMinutes,springSpan:spring.occupied,fallSpan:fall.occupied,springEnd:endLabel(springNext[0])}
})();`;
const result=vm.runInNewContext(program,{assert,console,Intl,Date,Set,Number,String,Object,Math});
if(process.env.TZ==='America/New_York'){
 assert.equal(result.springDay,1380);assert.equal(result.fallDay,1500);assert.equal(result.springSpan,120);assert.equal(result.fallSpan,120);assert(result.springEnd.startsWith('04:30'),result.springEnd);
} else {assert.equal(result.springDay,1440);assert.equal(result.fallDay,1440)}
console.log(JSON.stringify({tz:process.env.TZ,...result}));
