import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html'))
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  for k in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(k,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(HTML.read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/calendar"')
  await page.locator('lemma-native-calendar').wait_for(timeout=25000)
  await page.locator('lemma-native-calendar').locator('[data-cx="new-block"]').first.wait_for(timeout=25000)
  before=await page.evaluate('''() => {const s=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1')); return {running:s.timer.running,n:s.entries.length,stamp:s.timer.stamp,phase:s.timer.phase}}''')
  await page.evaluate('''() => {const r=document.querySelector('lemma-native-calendar').shadowRoot;let b=document.createElement('button');b.dataset.cx='finish';r.append(b);b.click();b.remove()}''')
  dialog=page.locator('lemma-native-calendar').locator('#cx-modal')
  await dialog.wait_for(timeout=15000)
  await page.locator('lemma-native-calendar').locator('[data-cx="session-skip"]').click()
  await page.wait_for_timeout(300)
  after=await page.evaluate('''() => {const s=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1'));let e=s.entries.filter(x=>x.id.startsWith('focus:')); return {running:s.timer.running,n:s.entries.length,focusLogs:e.map(x=>({id:x.id,minutes:x.min,start:x.start,end:x.end,approx:x.timeApproximate,segments:x.intervals?.length}))}}''')
  await page.evaluate('''() => {const r=document.querySelector('lemma-native-calendar').shadowRoot;let b=document.createElement('button');b.dataset.cx='session-skip';r.append(b);b.click();b.remove()}''')
  await page.wait_for_timeout(150)
  repeated=await page.evaluate('''() => {const s=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1'));return {n:s.entries.length,focus:s.entries.filter(x=>x.id.startsWith('focus:')).length}}''')
  print(json.dumps({'before':before,'after':after,'repeat':repeated,'errors':errors},indent=2),flush=True)
  assert after['n']==before['n']+1
  assert after['focusLogs'] and after['focusLogs'][0]['segments']
  assert repeated['n']==after['n']
  assert not errors
  await browser.close()
asyncio.run(main())
