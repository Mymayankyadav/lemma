import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text()
async def main():
 results=[];errors=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda route:route.abort())
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
  await page.locator('#root').wait_for(timeout=20000)
  for route in ['','review','projects','calendar','insights','atlas','proposals','settings']:
   await page.evaluate('(r)=>{location.hash="#/"+r}',route)
   await page.wait_for_timeout(700)
   await page.wait_for_function("!document.querySelector('#root')?.innerText.includes('Loading screen…') && (document.querySelector('#root')?.innerText.length||0)>180",timeout=20000)
   for theme in ['graph','graph-night']:
    await page.evaluate('(t)=>document.documentElement.dataset.theme=t',theme)
    for width,height,scale in [(360,640,1),(390,844,2)]:
     await page.set_viewport_size({'width':width,'height':height})
     await page.evaluate('(x)=>document.documentElement.style.fontSize=(16*x)+"px"',scale)
     await page.wait_for_timeout(80)
     result=await page.evaluate('''()=>{
       const html=document.documentElement;
       const nav=document.querySelector('nav[aria-label="Main navigation"]');
       const box=nav?.getBoundingClientRect();
       const links=[...document.querySelectorAll('main button,main a[href],main input:not([type="hidden"])')].filter(el=>{
         const r=el.getBoundingClientRect(),cs=getComputedStyle(el);
         return r.width>4&&r.height>4&&cs.visibility!=='hidden'&&cs.display!=='none';
       });
       const small=links.filter(el=>{const r=el.getBoundingClientRect();return r.width<44||r.height<44}).length;
       return {width:innerWidth,scrollWidth:html.scrollWidth,overflow:html.scrollWidth-innerWidth,
         navTop:box?.top??null,navHeight:box?.height??null,
         interactiveTargets:links.length,under44:small,main:!!document.querySelector('main')};
     }''')
     result.update(route=route,theme=theme,textScale=scale)
     results.append(result)
     print(route,theme,width,'scale',scale,'over',result['overflow'],'small',result['under44'],'/',result['interactiveTargets'],flush=True)
  print('ERRS',errors[:10],flush=True)
  Path(str(Path(__file__).resolve().parent / 'mobile_core_matrix_v2.json')).write_text(json.dumps({'states':results,'errors':errors},indent=2))
  await b.close()
asyncio.run(main())
