import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html'))
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  for k in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(k,lambda r:r.abort())
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  await page.set_content(HTML.read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/calendar"')
  c=page.locator('lemma-native-calendar')
  await c.wait_for(timeout=20000)
  await c.locator('[data-cx="new-block"]').first.wait_for(timeout=20000)
  modes={}
  for mode in ['agenda','day','week','month']:
   await c.locator('[data-cx="cal-view"][data-id="'+mode+'"]').click()
   await page.wait_for_timeout(140)
   modes[mode]={'events':await c.locator('[data-status]').count(), 'visible':(await c.inner_text())[:120], 'today':await c.locator('.cx-month-day.today').count() if mode=='month' else None}
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'calendar-dst-current.png'))
  print('CALENDAR',json.dumps(modes),flush=True)
  await page.evaluate('location.hash="#/atlas"')
  atlas=page.locator('.lg-map')
  await atlas.wait_for(timeout=30000)
  await page.wait_for_timeout(600)
  defrect=await page.evaluate('''() => ({w:document.documentElement.scrollWidth,sw:innerWidth,compact:document.querySelectorAll('[data-ui="atlas-compact-cell"]').length,labels:[...document.querySelectorAll('[data-ui="atlas-compact-cell"]')].map(n=>n.getAttribute('aria-label')).slice(0,20),clusters:document.querySelectorAll('[data-cluster="true"]').length})''')
  print('ATLAS_OVERVIEW',json.dumps(defrect),flush=True)
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'atlas-bounded-current.png'))
  nodes=page.locator('[data-ui="atlas-compact-cell"]')
  if await nodes.count():
   await nodes.first.click()
   await page.wait_for_timeout(600)
   details=await page.evaluate('''() => ({compact:document.querySelectorAll('[data-ui="atlas-compact-cell"]').length,clusters:document.querySelectorAll('[data-cluster="true"]').length,labels:[...document.querySelectorAll('[data-ui="atlas-compact-cell"]')].map(n=>n.getAttribute('aria-label')).slice(0,15)})''')
   print('ATLAS_BRANCH',json.dumps(details),flush=True)
   await page.screenshot(path=str(Path(__file__).resolve().parent / 'atlas-bounded-branch.png'))
   cluster=page.locator('[data-cluster="true"]')
   if await cluster.count():
    before=await cluster.first.get_attribute('aria-label')
    await cluster.first.click();await page.wait_for_timeout(300)
    after=await page.evaluate('''() => [...document.querySelectorAll('[data-ui="atlas-compact-cell"]')].map(n=>n.getAttribute('aria-label')).slice(0,5)''')
    print('ATLAS_MORE',before,after,flush=True)
  await page.get_by_role('button',name='Explore map',exact=True).click()
  await page.wait_for_timeout(350)
  full=await page.evaluate('''() => ({compact:document.querySelectorAll('[data-ui="atlas-compact-cell"]').length,nodes:document.querySelectorAll('[data-lx-node]').length})''')
  await page.keyboard.press('Escape')
  print('ATLAS_FULLSCREEN',json.dumps(full),flush=True)
  print('PAGE_ERRORS',errs[:12],flush=True)
  await browser.close()
  if errs:raise RuntimeError('Browser errors: '+str(errs[:3]))
asyncio.run(main())
