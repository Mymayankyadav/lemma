from pathlib import Path
import asyncio
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  await page.set_content(open(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read(),wait_until='domcontentloaded',timeout=20000)
  await page.locator('text=Review today').first.wait_for(timeout=20000)
  print('loaded',flush=True)
  await page.evaluate('location.hash="#/atlas"')
  try:
   await page.get_by_role('button',name='Explore map',exact=True).wait_for(timeout=25000)
   print('atlas title',repr((await page.locator('#root').inner_text())[:300]),flush=True)
   print('touch',await page.evaluate('''() => {let m=document.querySelector('.lg-map');return {style:getComputedStyle(m).touchAction,svg:m.querySelector('svg').style.touchAction,docHeight:document.documentElement.scrollHeight}}'''),flush=True)
   await page.get_by_role('button',name='Explore map',exact=True).click()
   print('fullscreen',await page.evaluate('''() => ({class:document.querySelector('.lg-page').className,style:getComputedStyle(document.querySelector('.lg-map')).touchAction})'''),flush=True)
   await page.keyboard.press('Escape')
   print('escape',await page.evaluate('document.querySelector(".lg-page").className'),flush=True)
   await page.screenshot(path=str(Path(__file__).resolve().parent / 'atlas-after.png'))
  except Exception as e:print('failed',str(e)[:500],flush=True)
  print('errors',errs[:10],flush=True)
  await b.close()
asyncio.run(main())
