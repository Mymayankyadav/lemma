import asyncio
from playwright.async_api import async_playwright
from pathlib import Path
async def run():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda r:r.abort())
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=45000)
  await page.evaluate('location.hash="#/atlas"');await page.wait_for_timeout(1000)
  out=await page.evaluate('''() => ({innerWidth,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth, visualViewport:visualViewport.width,
   offenders:[...document.querySelectorAll('*')].map(el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return {tag:el.tagName,id:el.id,cls:typeof el.className==='string'?el.className.slice(0,140):'',w:Math.round(r.width),left:Math.round(r.left),right:Math.round(r.right),scrollWidth:el.scrollWidth,overflowX:s.overflowX,text:(el.innerText||'').slice(0,30)}}).filter(x=>x.right>392||x.left< -3).sort((a,b)=>b.right-a.right).slice(0,35)})''')
  print(out)
  await b.close()
asyncio.run(run())
