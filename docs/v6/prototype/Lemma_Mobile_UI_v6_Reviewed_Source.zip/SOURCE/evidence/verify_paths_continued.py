import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in [360,390,1280]:
   page=await b.new_page(viewport={'width':width,'height':640 if width<500 else 800},has_touch=width<500,is_mobile=width<500)
   for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
    await page.route(pat,lambda r:r.abort())
   errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=40000)
   await page.evaluate('location.hash="#/projects"');await page.wait_for_timeout(1300)
   before=await page.evaluate('''() => ({root:document.querySelector('#root')?.innerText.slice(0,550),height:document.documentElement.scrollHeight})''')
   print('PATHS',width,before,flush=True)
   row=page.locator('[data-project-row]').first
   if await row.count():
    await row.get_by_role('button',name='Actions for',exact=False).click();await page.wait_for_timeout(150)
    menu=page.get_by_role('menu',name='Manage',exact=False).first
    if await menu.count():
     print('MENU',width,await menu.evaluate('''el=>({rect:(()=>{let r=el.getBoundingClientRect();return [r.left,r.top,r.width,r.height,r.bottom]})(),label:el.textContent.slice(0,230),position:getComputedStyle(el).position})'''),flush=True)
     await menu.get_by_role('button',name='Close').click();await page.wait_for_timeout(100)
     print('MENU_CLOSED',width,await page.get_by_role('menu',name='Manage',exact=False).count(),flush=True)
   print('ERRORS',width,errs,flush=True)
   if width==390:await page.screenshot(path=str(Path(__file__).resolve().parent / 'paths-continued.png'))
   await page.close()
  await b.close()
asyncio.run(main())
