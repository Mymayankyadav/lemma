import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844})
  await page.route('**/fonts.googleapis.com/**',lambda r:r.abort());await page.route('**/fonts.gstatic.com/**',lambda r:r.abort());await page.route('**/cdn.jsdelivr.net/**',lambda r:r.abort())
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)[:140]))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=40000)
  await page.evaluate('location.hash="#/settings"')
  await page.get_by_role('button',name='Sign out',exact=True).first.wait_for(timeout=30000)
  await page.get_by_role('button',name='Sign out',exact=True).first.click()
  print('sign out confirm visible',await page.get_by_text('Sign out of Lemma?',exact=True).is_visible(),flush=True)
  await page.get_by_role('button',name='Cancel',exact=True).last.click()
  await page.wait_for_timeout(400)
  print('cancelled confirmation',not await page.get_by_text('Sign out of Lemma?',exact=True).is_visible(),flush=True)
  print('replace link',await page.get_by_role('button',name='Replace connector address').count(),flush=True)
  await page.evaluate('location.hash="#/projects/new"')
  await page.get_by_role('textbox',name='Name').wait_for(timeout=12000)
  print('new-project name placeholder',await page.locator('#project-title').get_attribute('placeholder'),flush=True)
  print('required reason',await page.get_by_text('Enter a project name to continue.').is_visible(),flush=True)
  print('errors',errs[:4],flush=True)
  await b.close()
asyncio.run(main())
