const assert=require('node:assert/strict');
function crClockMin(t){const [h,m]=t.split(':').map(Number);return h*60+m}
function blocksForDay(){return [
{id:'a',at:'06:49',min:50},
{id:'b',at:'07:34',min:75},
{id:'c',at:'07:49',min:100}
]}
function crDayWorkload(day){
 const seen=new Set(),ranges=blocksForDay(day,true).filter(b=>{
  const key=b.id+':'+b.at+':'+b.min;
  if(seen.has(key))return false;
  seen.add(key);return Number.isFinite(+b.min)&&b.min>0;
 }).map(b=>({b,start:Math.max(0,crClockMin(b.at)),end:Math.min(1440,crClockMin(b.at)+b.min)})).filter(x=>x.end>x.start).sort((a,b)=>a.start-b.start||a.end-b.end);
 let sum=0,occupied=0,lastEnd=0;
 for(const x of ranges){sum+=x.end-x.start;occupied+=Math.max(0,x.end-Math.max(x.start,lastEnd));lastEnd=Math.max(lastEnd,x.end)}
 const conflicts=[];for(let i=0;i<ranges.length;i++)for(let j=i+1;j<ranges.length&&ranges[j].start<ranges[i].end;j++){
  const a=ranges[i],b=ranges[j];if(a.start<b.end&&b.start<a.end)conflicts.push({a:a.b,b:b.b,start:Math.max(a.start,b.start),end:Math.min(a.end,b.end)});
 }
 const affected=new Set(conflicts.flatMap(x=>[x.a.id,x.b.id]));
 return {sum,occupied,conflicts,affected:affected.size};
}
const result=crDayWorkload('2026-11-03');
assert.equal(result.conflicts.length,2);assert.equal(result.affected,3);
assert.equal(result.sum,225);assert.equal(result.occupied,160);
assert.deepEqual(result.conflicts.map(x=>[x.a.id,x.b.id,x.start,x.end]),[['a','b',454,459],['b','c',469,529]]);
console.log(JSON.stringify({overlapPairs:result.conflicts.length,involvedBlocks:result.affected,sumMin:result.sum,occupiedMin:result.occupied}));
