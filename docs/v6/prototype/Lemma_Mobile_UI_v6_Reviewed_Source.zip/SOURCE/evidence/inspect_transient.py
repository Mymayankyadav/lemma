import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']: await page.route(pat,lambda r:r.abort())
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=30000)
  await page.evaluate('location.hash="#/atlas"')
  for ms in [0,90,200,350,500,1000]:
   await page.wait_for_timeout(ms if ms==0 else (ms-(prev if 'prev' in locals() else 0)))
   prev=ms
   obj=await page.evaluate('''() => ({s:document.documentElement.scrollWidth,w:window.innerWidth,c:document.documentElement.clientWidth,v:visualViewport.width,off:[...document.querySelectorAll('body *')].map(e=>({e, r:e.getBoundingClientRect(), c:getComputedStyle(e)})).filter(x=>x.r.right>390.5&&x.c.position!=='fixed').sort((a,b)=>b.r.right-a.r.right).slice(0,10).map(x=>[x.e.tagName,typeof x.e.className==='string'?x.e.className.slice(0,90):'',x.r.left.toFixed(0),x.r.right.toFixed(0),x.c.overflowX])})''')
   print(ms,obj,flush=True)
  await b.close()
asyncio.run(main())
