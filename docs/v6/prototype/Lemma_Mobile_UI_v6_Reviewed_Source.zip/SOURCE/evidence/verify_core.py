from pathlib import Path
import asyncio,json,sys
from playwright.async_api import async_playwright
async def main():
 f=str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(open(f).read(),wait_until='domcontentloaded',timeout=25000)
  await page.locator('text=Review today').first.wait_for(timeout=25000)
  await page.evaluate('location.hash="#/review"')
  await page.get_by_role('button',name='Start review',exact=True).wait_for(timeout=15000)
  res=await page.evaluate('''() => ({h:document.documentElement.scrollHeight,w:document.documentElement.scrollWidth,deckTotal:[...document.querySelectorAll('[data-ui="review-checkbox"]')].length,check:[...document.querySelectorAll('[data-ui="review-checkbox"]')].slice(0,3).map(x=>({t:x.getBoundingClientRect().toJSON(),input:x.querySelector('input').getBoundingClientRect().toJSON(),label:x.innerText,name:x.querySelector('input').labels?.[0]?.innerText}))})''')
  print('review:',json.dumps(res),flush=True)
  await page.get_by_role('button',name='Start review',exact=True).click()
  await page.wait_for_timeout(700)
  print('route',await page.evaluate('location.hash'),flush=True)
  print('review run',repr((await page.locator('#root').inner_text())[:420]),flush=True)
  if 'review/run' in await page.evaluate('location.hash'):
   try:
    await page.get_by_role('button',name='Show answer without confidence').click(timeout=7000)
    print('after reveal',repr((await page.locator('#root').inner_text())[:550]),flush=True)
    stat=await page.evaluate('''() => {let x=document.querySelector('[data-review-card-scroll]');return x?{scrollTop:x.scrollTop,scrollHeight:x.scrollHeight,clientHeight:x.clientHeight,hasAnswer:!!x.querySelector('[data-answer]'),scrollHelp:!!document.querySelector('[data-ui="review-more-below"]')}:null}''')
    print('readstat',stat,flush=True)
   except Exception as e:print('reveal failure',str(e)[:200],flush=True)
   await page.screenshot(path=str(Path(__file__).resolve().parent / 'review-run-after.png'))
  print('errors',errors[:8],flush=True)
  await b.close()
asyncio.run(main())
