from pathlib import Path
import asyncio,json,sys
from playwright.async_api import async_playwright
async def main():
 path=sys.argv[1] if len(sys.argv)>1 else str(Path(__file__).resolve().parents[2] / '01_Original_Unmodified.html')
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':390,'height':844},device_scale_factor=2,has_touch=True,is_mobile=True)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(open(path).read(),wait_until='domcontentloaded')
  await page.wait_for_timeout(2500)
  for route in ['/','/review','/review/run','/atlas','/proposals','/settings','/insights','/paths','/calendar']:
   await page.evaluate('(r)=>{window.location.hash="#"+r}',route)
   await page.wait_for_timeout(350)
   val=await page.evaluate('''() => ({path:location.hash,title:document.title,rootText:document.querySelector('#root')?.innerText.slice(0,240),bodyH:document.documentElement.scrollHeight,innerW:document.documentElement.scrollWidth,buttons:[...document.querySelectorAll('button')].slice(0,10).map(x=>x.innerText.slice(0,45))})''')
   print(route,json.dumps(val,ensure_ascii=False))
   if route in ['/review','/atlas','/proposals']:
    await page.screenshot(path=str(Path(__file__).resolve().parents[1])+route.strip('/')+'.png',full_page=False)
  print('errors',errors[:12]);await b.close()
asyncio.run(main())
