const path=require('node:path');
const fs=require('fs'), vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(path.join(__dirname,'calendar_runtime.js'),'utf8');
const part=src.slice(src.indexOf('function crSessionIdentity('),src.indexOf('function finish(){',src.indexOf('function crSessionIdentity(')));
assert(part.includes('function crCommitTimerSession'));
function test(name,timer,now,expect){
 const S={timer,entries:[]};
 const sandbox={S, Date:class extends Date {constructor(x){super(x===undefined?now:x)}static now(){return now}}, dkey:d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'), jointContext:t=>({projectId:t.projectId||null,checkpointId:t.checkpointId||null}), elapsed:()=>timer.elapsed+(timer.running?(now-timer.stamp)/1000:0),Number,Math,String,Array,Object};
 vm.createContext(sandbox);vm.runInContext(part+';this.crCommit=crCommitTimerSession;',sandbox);
 const a=sandbox.crCommit('Deep','memo',['topic1']); const b=sandbox.crCommit('Deep','memo',['topic1']);
 assert(a,'commit should have nonzero entry');assert.strictEqual(a,b,'duplicate should return same record');assert.strictEqual(S.entries.length,1);assert.strictEqual(a.sessionId,timer.sessionId);assert.strictEqual(a.min,expect.min);assert.strictEqual(a.intervals.length,expect.intervals);assert.strictEqual(a.timeApproximate,expect.approx);assert(a.startInstant&&a.endInstant);assert.notStrictEqual(a.start,'20:00');
 console.log(name,JSON.stringify({min:a.min,start:a.start,end:a.end,segments:a.intervals,approx:a.timeApproximate}));
}
const at=Date.parse('2026-11-03T13:30:00Z');
test('one interval',{sessionId:'study-1',running:true,phase:'study',activity:'Topology',intent:'Proofs',elapsed:0,studyElapsed:0,stamp:at-30*60000,startedAt:at-30*60000,activeStudyStart:at-30*60000,studyIntervals:[]},at,{min:30,intervals:1,approx:false});
test('two intervals excluding break',{sessionId:'study-2',running:true,phase:'study',activity:'Topology',elapsed:20*60,studyElapsed:20*60,stamp:at-15*60000,startedAt:at-50*60000,activeStudyStart:at-15*60000,studyIntervals:[{start:at-50*60000,end:at-30*60000}],lastStudyElapsed:20*60},at,{min:35,intervals:2,approx:false});
test('paused segment excluding pause',{sessionId:'study-paused',running:false,paused:true,phase:'study',activity:'Topology',elapsed:35*60,studyElapsed:20*60,stamp:at-25*60000,startedAt:at-60*60000,activeStudyStart:at-25*60000,studyIntervals:[{start:at-60*60000,end:at-40*60000}],lastStudyElapsed:20*60},at,{min:35,intervals:2,approx:false});
test('legacy fallback',{sessionId:'legacy-1',running:false,phase:'study',activity:'Topology',elapsed:20*60,stamp:at-20*60000,studyIntervals:[]},at,{min:20,intervals:1,approx:true});
console.log('timer tests PASSED');
