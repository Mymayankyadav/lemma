"""W01 demo shutdown scope checks, actual browser UI."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(__file__).parents[2]/'Lemma_UI_Implemented.html'
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='Asia/Kolkata')
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:await page.route(pat,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(HTML.read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/calendar"')
  cal=page.locator('lemma-native-calendar')
  await cal.locator('[data-cx="spatial-tools"]').first.wait_for(timeout=20000)
  await cal.locator('[data-cx="spatial-tools"]').first.click()
  await cal.locator('[data-cx="spatial-tool"][data-id="rituals"]').last.click()
  await cal.locator('[data-cx="shutdown"]').first.click()
  content=await cal.locator('#cx-modal').inner_text()
  print('SHUTDOWN',content[:200].replace('\n',' / '),flush=True)
  assert 'logged today' in content and 'daily intention' in content, content[:400]
  assert not errors,errors
  print('PASS shutdown daily effort and intention labels, no JS errors',flush=True)
  await b.close()
asyncio.run(main())
