id="lemma-session-store">/* v8: One authority for session timing across the calendar and Lemma shell.
   A calendar view can propose changes, but it never owns a separate final revision. */
(function(){'use strict';
 const KEY='lemma.carrel.saturation.20261102.v1';
 const copy=x=>JSON.parse(JSON.stringify(x));
 const normalize=x=>({...{focus:50,short:10,long:20,every:4,cycle:1,mode:'pomo',phase:'study',running:false,paused:false,elapsed:0},...x});
 let current;
 try{const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved&&saved.timer)current=normalize(copy(saved.timer))}catch(_){}
 const fingerprint=x=>JSON.stringify({...x,rev:undefined});
 const listeners=new Set();
 function get(){return current?copy(current):null}
 function announce(source){const payload={timer:get(),source};queueMicrotask(()=>{
  for(const fn of [...listeners])try{fn(payload)}catch(error){console.error('Lemma session subscriber:',error)}
  window.dispatchEvent(new CustomEvent('lemma:sessionchange',{detail:payload}));
 })}
 function init(timer){if(!current){current=normalize(copy(timer));current.rev=Number(current.rev)||0;}return get()}
 function commit(incoming,source='unknown',expectedRev){
  if(!incoming||typeof incoming!=='object')return {timer:get(),accepted:false};
  if(!current)return {timer:init(incoming),accepted:true};
  const version=Number(current.rev)||0;
  if(expectedRev!==undefined&&Number(expectedRev)!==version)
    return {timer:get(),accepted:false,conflict:true};
  if(fingerprint(incoming)===fingerprint(current))return {timer:get(),accepted:true,unchanged:true};
  current={...normalize(copy(incoming)),rev:Math.max(Date.now(),version+1)};
  // Persist the timer without overwriting planner blocks, reviews, or settings.
  try{const doc=JSON.parse(localStorage.getItem(KEY)||'{}');localStorage.setItem(KEY,JSON.stringify({...doc,timer:current}))}catch(_){}
  announce(source);
  return {timer:get(),accepted:true};
 }
 function subscribe(callback){listeners.add(callback);return()=>listeners.delete(callback)}
 window.addEventListener('storage',event=>{
  if(event.key!==KEY||!event.newValue)return;
  try{const next=JSON.parse(event.newValue)?.timer;if(next&&Number(next.rev)>Number(current?.rev||0)){
   current=copy(next);announce('storage');
  }}catch(_){}
 });
 window.__lemmaSessionStore=Object.freeze({init,get,commit,subscribe});
})();</script>
<script 