import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda r:r.abort())
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=45000)
  await page.evaluate('location.hash="#/proposals"')
  await page.wait_for_timeout(1200)
  before=(await page.locator('#root').inner_text())
  print('INITIAL',repr(before[:260]),flush=True)
  reject=page.get_by_role('button',name='Reject card',exact=True)
  print('REJECT FOUND',await reject.count(),flush=True)
  if await reject.count():
   await reject.click();await page.wait_for_timeout(240)
   mid=(await page.locator('#root').inner_text())
   print('AFTER STAGE',repr(mid[:470]),flush=True)
   undo=page.get_by_role('button',name='Undo',exact=True)
   print('UNDO COUNT',await undo.count(),flush=True)
   if await undo.count():
    await undo.first.click();await page.wait_for_timeout(180)
    print('AFTER UNDO',repr((await page.locator('#root').inner_text())[:300]),flush=True)
  # stage again and visit another route before delay to ensure durable service lifetime
  if await reject.count():
   await reject.click();await page.wait_for_timeout(200)
   op=await page.evaluate('''() => {try{return JSON.parse(localStorage.getItem('lemma.ui.proposalDecisions.v2')||'[]')}catch{return []}}''')
   print('QUEUED',[(x.get('state'),len(x.get('ids',[]))) for x in op],flush=True)
   await page.evaluate('location.hash="#/atlas"');await page.wait_for_timeout(6800)
   await page.evaluate('location.hash="#/proposals"');await page.wait_for_timeout(600)
   op=await page.evaluate('''() => {try{return JSON.parse(localStorage.getItem('lemma.ui.proposalDecisions.v2')||'[]')}catch{return []}}''')
   print('AFTER NAV 7s',[(x.get('state'),x.get('results')) for x in op],flush=True)
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'inbox-ledger-continued.png'),full_page=False)
  print('ERRORS',errs[:10],flush=True)
  await b.close()
asyncio.run(main())
