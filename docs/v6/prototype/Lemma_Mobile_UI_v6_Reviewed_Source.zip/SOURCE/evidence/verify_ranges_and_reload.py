from pathlib import Path
import asyncio, json
from playwright.async_api import async_playwright
URL=str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda r:r.abort())
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  await page.set_content(open(URL).read(),wait_until='domcontentloaded',timeout=45000);await page.evaluate('location.hash="#/insights"');await page.wait_for_timeout(1500)
  for n in [7,30,90]:
   await page.get_by_text(f'{n} days',exact=True).first.click();await page.wait_for_timeout(550)
   data=await page.evaluate('''() => ({range:location.hash,
     heading:(document.querySelector('#root')?.innerText||'').match(/Reviews by (?:day|week|six-day period)/)?.[0],
     chart:document.querySelectorAll('.lemma-chart-data')[1]?.textContent.slice(0,90),
     checkpoint:[...document.querySelectorAll('p')].find(x=>x.textContent.includes('No checkpoint events'))?.textContent,
     width:document.documentElement.scrollWidth,
     viewport:innerWidth})''')
   print('RANGE',n,json.dumps(data),flush=True)
  await page.evaluate('location.hash="#/proposals"');await page.wait_for_timeout(800)
  reject=page.get_by_role('button',name='Reject card',exact=True)
  if await reject.count():
   await reject.click();await page.wait_for_timeout(80)
   print('STAGE',await page.evaluate("JSON.parse(localStorage.getItem('lemma.ui.proposalDecisions.v2')||'[]').map(x=>x.state)"),flush=True)
   saved=await page.evaluate("localStorage.getItem('lemma.ui.proposalDecisions.v2')")
   # New isolated document with the saved ledger injected as a stand-in for browser storage.
   other=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
   await other.evaluate('''(saved)=>{const m=new Map([["lemma.ui.proposalDecisions.v2",saved]]);Object.defineProperty(window,"localStorage",{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k)}})}''',saved)
   for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
    await other.route(pat,lambda r:r.abort())
   await other.set_content(open(URL).read(),wait_until='domcontentloaded',timeout=45000)
   await other.evaluate('location.hash="#/proposals"');await other.wait_for_timeout(750)
   print('RELOAD',repr((await other.locator('#root').inner_text())[:330]),flush=True)
   undo=other.get_by_role('button',name='Undo',exact=True)
   print('RELOAD_UNDO_AVAILABLE',await undo.count(),flush=True)
   if await undo.count():
    await undo.first.click();print('AFTER_UNDO',await other.evaluate("JSON.parse(localStorage.getItem('lemma.ui.proposalDecisions.v2')||'[]').map(x=>x.state)"),flush=True)
   await other.close()
  print('JS ERRORS',errs[:7],flush=True)
  await browser.close()
asyncio.run(main())
