import asyncio, re
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  await page.route('**/fonts.googleapis.com/**',lambda r:r.abort());await page.route('**/fonts.gstatic.com/**',lambda r:r.abort());await page.route('**/cdn.jsdelivr.net/**',lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)[:300]))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=30000)
  await page.evaluate('location.hash="#/proposals"')
  try:
   await page.get_by_role('heading',name='Inbox',exact=True).wait_for(timeout=20000)
   await page.get_by_role('button',name=re.compile('Inspect & approve')).first.wait_for(timeout=10000)
   print('btn sample',await page.get_by_role('button',name=re.compile('Inspect & approve')).first.inner_text(),flush=True)
   print('group',await page.get_by_text(re.compile(r'\d+ shown · \d+ pending in this group')).first.inner_text(),flush=True)
   await page.get_by_role('button',name=re.compile('Inspect & approve')).first.click()
   print('batchdialog',(await page.get_by_role('dialog').last.inner_text())[:260],flush=True)
   await page.get_by_role('button',name='Cancel',exact=True).last.click()
   await page.get_by_role('button',name='Edit card').click()
   print('editbuttonlist',[b.strip() for b in await page.locator('[role="dialog"] button').all_inner_texts()][-6:],flush=True)
   await page.get_by_role('button',name='Save draft',exact=True).click()
   print('draftkeys',await page.evaluate('Object.keys(localStorage).filter(x=>x.startsWith("lemma.proposal.draft:"))'),flush=True)
  except Exception as e: print('verify error',str(e)[:340],flush=True)
  print('pageerrors',errors[:5],flush=True)
  await b.close()
asyncio.run(main())
