import asyncio,sys,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for url in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(url,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=40000)
  await page.evaluate('location.hash="#/projects"')
  await page.wait_for_timeout(1500)
  links=await page.evaluate('''() => [...document.querySelectorAll('a[href*="/p/"]')].slice(0,7).map(e=>({text:e.textContent.slice(0,90),href:e.getAttribute('href')}))''')
  print('PROJECT LINKS',json.dumps(links),flush=True)
  if links:
   href=links[0]['href'];await page.evaluate('(s)=>location.hash=s',(href if href.startswith('#') else '#'+href))
   await page.wait_for_timeout(1250)
   print('PROJECT',repr((await page.locator('#root').inner_text())[:950]),flush=True)
   print('project tabs',await page.locator('#root').get_by_text('Sessions',exact=True).count(),flush=True)
   if await page.get_by_text('Sources',exact=True).count():
    await page.get_by_text('Sources',exact=True).first.click();await page.wait_for_timeout(350)
    print('SOURCE',repr((await page.locator('#root').inner_text())[:1100]),flush=True)
    await page.screenshot(path=str(Path(__file__).resolve().parent / 'sources-continuation.png'),full_page=False)
   if await page.get_by_text('Sessions',exact=True).count():
    await page.get_by_text('Sessions',exact=True).first.click();await page.wait_for_timeout(350)
    print('SESSIONS',repr((await page.locator('#root').inner_text())[:650]),flush=True)
    print('FIND',await page.get_by_placeholder('Title, number, tutor or date').count(),flush=True)
    await page.screenshot(path=str(Path(__file__).resolve().parent / 'sessions-continuation.png'),full_page=False)
  print('JS ERRORS',errors,flush=True)
  await browser.close()
asyncio.run(main())
