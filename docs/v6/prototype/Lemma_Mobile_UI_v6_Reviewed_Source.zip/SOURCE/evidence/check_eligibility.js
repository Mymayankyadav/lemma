const fs=require('fs'),vm=require('vm'),assert=require('assert');
const p=__dirname+'/../modules/55__insights-DjL4G0LE.js';
const source=fs.readFileSync(p,'utf8');
const code=source.slice(source.indexOf('function eligibleReviews('),source.indexOf('function c(e,t){'));
const ctx=vm.createContext({Intl,Date,Number,Math,Array,Map,Set,String,Object});
vm.runInContext(code,ctx);
const go=(rows,settings)=>vm.runInContext('eligibleReviews('+JSON.stringify(rows)+','+JSON.stringify(settings)+')',ctx);
let rows=[
 {cardId:'a',rating:4,reviewedAt:'2026-11-03T01:30:00+05:30'},
 {cardId:'a',rating:3,reviewedAt:'2026-11-03T04:30:00+05:30'},
 {cardId:'b',rating:4,reviewedAt:'2026-11-03T05:30:00+05:30'},
 {cardId:'b',rating:2,reviewedAt:'2026-11-03T06:30:00+05:30'},
 {cardId:'c',rating:8,reviewedAt:'2026-11-03T03:00:00+05:30'},
];
let r=go(rows,{timeZone:'Asia/Kolkata',rolloverHour:4});
assert.equal(r.eligible,1);assert.equal(r.total,5);assert.equal(r.invalid,1);assert.equal(r.sameDayOrFirst,3);
let fallback=go(null,{});assert.equal(fallback.status,'unavailable');
let empty=go([],{timeZone:'UTC',rolloverHour:4});assert.equal(empty.status,'ready');assert.equal(empty.eligible,0);
let dst=go([
 {cardId:'dst',rating:3,reviewedAt:'2026-11-01T01:30:00-04:00'},
 {cardId:'dst',rating:3,reviewedAt:'2026-11-01T01:30:00-05:00'},
 {cardId:'dst',rating:3,reviewedAt:'2026-11-02T05:30:00-05:00'},
],{timeZone:'America/New_York',rolloverHour:4});assert.equal(dst.eligible,1);
console.log('W17 verified eligible interval counting, local rollover, DST repeat hour, empty/unavailable states:',r,dst);
