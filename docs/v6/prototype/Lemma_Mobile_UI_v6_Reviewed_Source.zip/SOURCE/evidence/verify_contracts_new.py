import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for src in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(src,lambda req:req.abort())
  errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  for route in ['#/settings','#/review','#/today']:
   await page.evaluate('(r)=>location.hash=r',route)
   await page.wait_for_timeout(1200)
   txt=await page.locator('#root').inner_text()
   print('\nROUTE',route, repr(txt[:1200]),flush=True)
   if route=='#/settings':
    for k in ['eligible review','Requires','history','Tune to my reviews']:
     print('match',k,[txt[max(0,txt.find(k)-100):txt.find(k)+150]] if k in txt else [],flush=True)
    await page.screenshot(path=str(Path(__file__).resolve().parent / 'settings-eligibility.png'),full_page=False)
   if route=='#/review':
    print('FORECAST',txt[txt.lower().find('seven-day'):txt.lower().find('seven-day')+900],flush=True)
    await page.screenshot(path=str(Path(__file__).resolve().parent / 'review-forecast-new.png'),full_page=False)
   print('ERRORS',errors[:3],flush=True)
  await browser.close()
asyncio.run(main())
