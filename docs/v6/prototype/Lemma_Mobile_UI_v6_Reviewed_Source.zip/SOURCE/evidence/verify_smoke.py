import asyncio, sys, time, json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 t=time.monotonic()
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-background-networking'])
  page=await b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  page.on('pageerror',lambda e: print('JS_ERROR',str(e)[:400],flush=True))
  await page.route('**/fonts.googleapis.com/**',lambda route: route.abort())
  await page.route('**/fonts.gstatic.com/**',lambda route: route.abort())
  await page.route('**/cdn.jsdelivr.net/**',lambda route: route.abort())
  print('starting set_content',round(time.monotonic()-t,1),flush=True)
  try:
   await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=45000)
   print('domcontentloaded',round(time.monotonic()-t,1),flush=True)
  except Exception as e: print('SET_CONTENT_FAILURE',str(e)[:160],flush=True)
  try:
   for h in ['#/review','#/calendar','#/atlas','#/insights','#/proposals','#/today']:
    await page.evaluate('(h)=>{location.hash=h}',h)
    await page.wait_for_timeout(450)
    out=await page.evaluate('''() => ({title:document.title,body:document.querySelector('#root')?.innerText?.slice(0,180),scroll:document.documentElement.scrollHeight,nativeCalendar:!!document.querySelector('lemma-native-calendar')})''')
    print(h,json.dumps(out),flush=True)
  except Exception as e: print('ROUTE_FAILURE',str(e)[:200],flush=True)
  await b.close()
asyncio.run(main())
