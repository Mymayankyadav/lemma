import asyncio
from pathlib import Path
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
        page=await browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
        for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
            await page.route(pat, lambda route: route.abort())
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
        await page.evaluate('location.hash="#/today"')
        await page.get_by_text('Study time today',exact=True).first.wait_for(timeout=20000)
        result=await page.evaluate('''() => {
           const now=new Date(),today=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');
           const start=new Date(now.getFullYear(),now.getMonth(),now.getDate(),10,58),end=new Date(now.getFullYear(),now.getMonth(),now.getDate(),11,2);
           const sample={id:'test-effort-1',sessionId:'already-committed',date:today,min:4,intervals:[{start:start.toISOString(),end:end.toISOString()}]};
           const state=window.__carrelIntegration.getState();
           state.entries=[sample,{...sample}];state.timer.running=false;state.timer.paused=false;
           localStorage.setItem('lemma.carrel.saturation.20261102.v1',JSON.stringify(state));
           window.dispatchEvent(new Event('lemma:integrationchange'));
           return {today,counts:window.__lemmaEffortMetrics.forDay(state.entries,state.timer,today).committedMinutes,hours:window.__lemmaEffortMetrics.forDay(state.entries,state.timer,today).loggedHours};
        }''')
        await page.wait_for_timeout(200)
        visible=await page.locator('.lemma-time-heading').inner_text()
        print('SELECTOR',result,'TODAY',visible.replace('\n',' | '),flush=True)
        assert result['counts']==4 and result['hours']==[10,11],result
        assert '4 min logged' in visible,visible
        await page.evaluate('location.hash="#/calendar"')
        await page.locator('lemma-native-calendar').wait_for(timeout=20000)
        await page.wait_for_timeout(250)
        log=await page.evaluate('''()=>{const s=window.__carrelIntegration.getState();return window.__lemmaEffortMetrics.allTime(s.entries)}''')
        assert log['committedMinutes']==4,log
        assert not errors,errors
        print('PASS browser: Today and Calendar share one saved interval stream; no JS page errors',flush=True)
        await browser.close()
asyncio.run(main())
