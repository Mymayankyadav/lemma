import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  text=Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text()
  for vp in [{'width':360,'height':640},{'width':390,'height':844},{'width':844,'height':390},{'width':1280,'height':800}]:
   page=await browser.new_page(viewport=vp,has_touch=vp['width']<500,is_mobile=vp['width']<500)
   for url in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
    await page.route(url,lambda r:r.abort())
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.set_content(text,wait_until='domcontentloaded',timeout=45000)
   for target in ['#/projects','#/p/real-analysis','#/atlas','#/settings','#/calendar','#/proposals']:
    await page.evaluate('(v)=>location.hash=v',target);await page.wait_for_timeout(350)
    data=await page.evaluate('''() => ({w:document.documentElement.scrollWidth,v:innerWidth,menu:!!document.querySelector('[data-ui="utility-menu"]'),shell:!!document.querySelector('nav[aria-label="Main navigation"]')})''')
    print(vp['width'],target,json.dumps(data),flush=True)
    if target=='#/atlas':
     menu=page.locator('[data-ui="utility-menu"]')
     if await menu.count():
      await menu.locator('summary').click();await page.wait_for_timeout(80)
      print('MENU_ITEMS',await page.locator('nav[aria-label="Notebook utilities"] a').all_text_contents(),flush=True)
    if target=='#/projects' and vp['width']==390:
     await page.screenshot(path=str(Path(__file__).resolve().parent / 'paths-with-menu.png'))
   print('ERRORS',vp['width'],errors[:5],flush=True)
   await page.close()
  await browser.close()
asyncio.run(main())
