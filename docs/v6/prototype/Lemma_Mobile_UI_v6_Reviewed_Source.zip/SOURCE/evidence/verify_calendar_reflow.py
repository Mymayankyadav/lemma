import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(__file__).parents[2]/'Lemma_UI_Implemented.html'
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='Asia/Kolkata')
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:await page.route(pat,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(HTML.read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/calendar"')
  cal=page.locator('lemma-native-calendar')
  await cal.locator('[data-cx="new-block"]').first.wait_for(timeout=20000)
  outputs=[]
  for w,h,scale,theme in [(320,640,1,'graph'),(390,844,1,'graph'),(390,844,2,'graph'),(768,1024,1,'graph'),(390,844,1,'graph-night')]:
   await page.set_viewport_size({'width':w,'height':h})
   await page.evaluate('''([s,t])=>{document.documentElement.style.fontSize=s*16+'px';document.documentElement.dataset.theme=t}''',[scale,theme])
   await cal.locator('[data-cx="cal-view"][data-id="week"]').click()
   await page.wait_for_timeout(100)
   r=await page.evaluate('''()=>{const c=document.querySelector('lemma-native-calendar')?.shadowRoot;
     const strip=c?.querySelector('.cr-week-overview'),btns=[...(c?.querySelectorAll('[data-cx="week-select"]')||[])],stripWidth=strip?.getBoundingClientRect().width||0;
     return {width:innerWidth,scrollWidth:document.documentElement.scrollWidth,strip:!!strip,
       weekButtons:btns.length,minButtonW:Math.round(Math.min(...btns.map(b=>b.getBoundingClientRect().width))),
       minButtonH:Math.round(Math.min(...btns.map(b=>b.getBoundingClientRect().height))),
       columns:strip?.getBoundingClientRect().width,fullWeek:!!c?.querySelector('.cr-full-week-action'),
       currentView:c?.querySelector('.cr-grid-scroller')?.getAttribute('data-view')}}''')
   if w<=390:
    assert r['weekButtons']==7 and r['strip'],r
    assert r['minButtonW']>=44 and r['minButtonH']>=44,r
   assert r['scrollWidth']<=w+2,r
   outputs.append(dict(r,scale=scale,theme=theme))
   print('REFLOW',w,scale,theme,r,flush=True)
   if w==320:await page.screenshot(path=str(Path(__file__).parent/'calendar-week-320.png'))
  print('PAGE_ERRORS',errors,flush=True)
  assert not errors,errors
  (Path(__file__).parent/'calendar_reflow_results.json').write_text(json.dumps(outputs,indent=2))
  await b.close()
asyncio.run(main())
