import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text()
SIZES=[(320,640),(360,640),(390,844),(844,390),(768,1024),(1280,800)]
async def main():
 reports=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
  for w,h in SIZES:
   page=await browser.new_page(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600)
   for d in ['fonts.googleapis.com','fonts.gstatic.com','cdn.jsdelivr.net']:
    await page.route('**/'+d+'/**',lambda r:r.abort())
   errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   await page.set_content(HTML,wait_until='domcontentloaded',timeout=45000)
   for theme in ['graph','graph-night']:
    await page.evaluate('(t)=>{document.documentElement.dataset.theme=t}',theme)
    for route in ['atlas','calendar']:
     await page.evaluate('(r)=>{location.hash="#/"+r}',route)
     if route=='atlas':await page.locator('.lg-map').wait_for(timeout=20000)
     else:await page.locator('lemma-native-calendar').wait_for(timeout=20000)
     await page.wait_for_timeout(220)
     data=await page.evaluate('''(r)=>{const el=document.documentElement;
      const inspector=document.querySelector('.lg-inspector');
      return {route:r,scrollWidth:el.scrollWidth,viewport:innerWidth,overflow:el.scrollWidth-innerWidth,
       compact:document.querySelectorAll('[data-ui="atlas-compact-cell"]').length,
       inspectorPosition:inspector?getComputedStyle(inspector).position:null,
       gridDisplay:r==='atlas'?getComputedStyle(document.querySelector('.lg-connection-filter')).display:null,
       footer:document.querySelector('nav[aria-label="Main navigation"]')?.getBoundingClientRect().height||null};
     }''',route)
     reports.append({'width':w,'height':h,'theme':theme,**data,'errors':errs[-2:]})
   if w in (320,390):
    await page.add_style_tag(content='html{font-size:200%!important}')
    await page.evaluate('location.hash="#/atlas"');await page.locator('.lg-map').wait_for(timeout=20000);await page.wait_for_timeout(300)
    data=await page.evaluate('''()=>({scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth,route:'atlas-200pct',compact:document.querySelectorAll('[data-ui="atlas-compact-cell"]').length})''')
    reports.append({'width':w,'height':h,'theme':'graph-night',**data,'overflow':data['scrollWidth']-w,'errors':errs[-2:]})
   await page.close()
  await browser.close()
 Path(str(Path(__file__).resolve().parent / 'calendar_atlas_matrix.json')).write_text(json.dumps(reports,indent=2))
 for r in reports:print(r,flush=True)
 print('FAILURES:',[r for r in reports if r.get('overflow',0)>2 or r.get('errors')],flush=True)
asyncio.run(main())
