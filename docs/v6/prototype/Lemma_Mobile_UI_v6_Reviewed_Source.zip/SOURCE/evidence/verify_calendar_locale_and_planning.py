"""Focused W01/W13 browser verification: saved 12/24 clock, civil dates, future-only backplanning."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(__file__).parents[2]/'Lemma_UI_Implemented.html'

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  ctx=await browser.new_context(viewport={'width':390,'height':844},timezone_id='Asia/Kolkata',is_mobile=True,has_touch=True)
  page=await ctx.new_page()
  for pat in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pat,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(HTML.read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/calendar"')
  cal=page.locator('lemma-native-calendar')
  await cal.locator('[data-cx="new-block"]').first.wait_for(timeout=20000)
  today=await page.evaluate('''()=>{const d=new Date(),v=n=>String(n).padStart(2,'0');return [d.getFullYear(),v(d.getMonth()+1),v(d.getDate())].join('-')}''')
  print('TODAY',today,flush=True)

  # Existing Day preferences saves a clock field; it now affects the real labels.
  await cal.locator('[data-cx="spatial-tools"]').first.click()
  await cal.locator('[data-cx="day-settings"]').click()
  await cal.locator('#cx-hour-clock').select_option(label='12h')
  await cal.locator('[data-cx="day-save"]').click()
  await cal.locator('[data-cx="cal-view"][data-id="agenda"]').click()
  label=await cal.locator('.lemma-agenda-item').first.inner_text()
  print('12H_FIRST',label.replace('\n',' | ')[:110],flush=True)
  assert 'AM' in label or 'PM' in label, label
  await cal.locator('[data-cx="cal-view"][data-id="day"]').click()
  await cal.locator('.cr-spatial-event').first.wait_for(timeout=6000)
  text=await cal.locator('.cr-spatial-event').first.locator('[id^=block-time]').text_content()
  print('12H_SPATIAL',text.replace('\n',' | ')[:100],flush=True)
  assert 'AM' in text or 'PM' in text, text

  # Switch back and confirm old canonical HH:mm times remain unchanged.
  await cal.locator('[data-cx="spatial-tools"]').first.click()
  await cal.locator('[data-cx="day-settings"]').click()
  await cal.locator('#cx-hour-clock').select_option(label='24h')
  await cal.locator('[data-cx="day-save"]').click()
  await cal.locator('[data-cx="cal-view"][data-id="agenda"]').click()
  label24=await cal.locator('.lemma-agenda-item').first.inner_text()
  assert 'AM' not in label24 and 'PM' not in label24,label24
  print('24H_FIRST',label24.replace('\n',' | ')[:100],flush=True)

  # New deadlines default to two weeks after the actual current date.
  await cal.locator('[data-cx="spatial-tool"][data-id="deadlines"]').first.click()
  await cal.locator('[data-cx="new-deadline"]').first.click()
  default=await cal.locator('#cx-deadline-date').input_value()
  expected=await page.evaluate('''()=>{const d=new Date();d.setDate(d.getDate()+14);return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}''')
  assert default==expected,(default,expected)
  await cal.locator('#cx-deadline-title').fill('E2E deadline date fixture')
  await cal.locator('#cx-deadline-date').fill(expected)
  await cal.locator('[data-cx="deadline-save"]').click()
  # The deadline is persisted in the planner; its resulting blocks should never be before tomorrow at 19:xx.
  await cal.locator('[data-cx="backward"]').last.click()
  dialog=cal.locator('#cx-modal')
  info=(await dialog.inner_text())[:800]
  assert 'starting' in info,info
  await dialog.locator('[data-cx="backward-save"]').click()
  rows=await page.evaluate('''()=>{let s=JSON.parse(localStorage.getItem('lemma.carrel.saturation.20261102.v1')||'{}');return (s.blocks||[]).filter(b=>String(b.id).startsWith('bw:')).map(b=>({id:b.id,date:b.date,at:b.at}))}''')
  assert rows, rows
  assert all(r['date']>today for r in rows),rows[:5]
  ids={r['id'] for r in rows};assert len(rows)==len(ids),rows
  print('GENERATED_FUTURE_BLOCKS',rows[:5],len(rows),flush=True)

  # State survives a route remount; persisted clock is 24 hours.
  await page.evaluate('location.hash="#/today"')
  await page.wait_for_timeout(300)
  await page.evaluate('location.hash="#/calendar"')
  await cal.locator('[data-cx="new-block"]').first.wait_for(timeout=20000)
  await cal.locator('[data-cx="spatial-tools"]').first.click()
  await cal.locator('[data-cx="day-settings"]').click()
  saved_clock=await cal.locator('#cx-hour-clock').input_value()
  assert saved_clock=='24h',saved_clock
  assert not errors,errors
  print('PASS calendar clock, civil planning, saved preferences, route remount, no page JS errors',flush=True)
  await browser.close()

if __name__=='__main__':asyncio.run(main())
