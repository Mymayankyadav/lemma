import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
  for k in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:await page.route(k,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html')).read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/today"')
  await page.get_by_text('View seven-day forecast').click()
  await page.wait_for_timeout(1800)
  details=page.locator('.lemma-forecast')
  print('forecast text',repr((await details.inner_text())[:2500]),flush=True)
  print('forecast entire',await details.get_attribute('open'),flush=True)
  print('errors',errors,flush=True)
  await page.screenshot(path=str(Path(__file__).resolve().parent / 'forecast-full-new.png'),full_page=True)
  await browser.close()
asyncio.run(main())
