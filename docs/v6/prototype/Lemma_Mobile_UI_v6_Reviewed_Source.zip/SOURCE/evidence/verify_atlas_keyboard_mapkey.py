"""Focused Atlas keyboard/map-key regression test on the detached standalone build."""
import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  errors=[]; outcomes=[]
  page=await browser.new_page(viewport={'width':390,'height':844},timezone_id='Asia/Kolkata',has_touch=True,is_mobile=True)
  page.on('pageerror',lambda e:errors.append(str(e)))
  for pattern in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(pattern,lambda r:r.abort())
  await page.set_content((ROOT.parent/'Lemma_UI_Implemented.html').read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/atlas"')
  key=page.locator('[data-ui="atlas-map-key"] summary')
  await key.wait_for(timeout=30000)
  await key.click()
  legend=await page.locator('[data-ui="atlas-map-key"]').inner_text()
  assert all(term in legend for term in ['Demonstrated','Re-check due','In progress','Not started','arrow keys','Prerequisites']),legend
  nodes=page.locator('[data-ui="atlas-compact-cell"]')
  n=await nodes.count()
  assert n>=2,n
  await nodes.nth(0).focus()
  before=await page.evaluate('document.activeElement?.getAttribute("data-lx-node")')
  await page.keyboard.press('ArrowRight')
  after=await page.evaluate('document.activeElement?.getAttribute("data-lx-node")')
  assert before!=after,(before,after)
  await page.keyboard.press('Home')
  first=await page.evaluate('document.activeElement?.getAttribute("data-lx-node")')
  assert first==before,(first,before)
  await page.keyboard.press('End')
  last=await page.evaluate('document.activeElement?.getAttribute("data-lx-node")')
  assert last!=(first), (first,last)
  focus=await page.evaluate('''() => {const e=document.activeElement;const f=e?.querySelector('.lg-node-focus');return {isNode:e?.hasAttribute('data-lx-node'),focusRect:f?.tagName?.toLowerCase(),opacity:f?getComputedStyle(f).opacity:null}}''')
  assert focus['isNode'] and focus['focusRect']=='rect',focus
  # Native keyboard activation for the selected node.
  await nodes.nth(0).focus()
  await page.keyboard.press('Enter')
  assert await page.locator('.lg-inspector').count()>=1
  # The original full-screen graph and outline must survive this change.
  await page.get_by_role('button',name='Explore map',exact=True).click()
  assert 'lg-explore-fullscreen' in await page.locator('.lg-page').get_attribute('class')
  assert await page.get_by_role('button',name='Zoom in').count()==1
  assert await page.get_by_role('button',name='Fit map').count()==1
  await page.keyboard.press('Escape')
  assert 'lg-explore-fullscreen' not in await page.locator('.lg-page').get_attribute('class')
  outline=page.locator('.lg-outline summary')
  await outline.click()
  await page.locator('.lg-outline input[type="search"]').wait_for(timeout=5000)
  outcomes.append({'width':390,'compactNodes':n,'first':before,'arrowRight':after,'home':first,'end':last,'focus':focus,'legend':True,'fullscreen':True,'outline':True})
  # Desktop graph also exposes the movement affordance, with its native radial graph preserved.
  await page.set_viewport_size({'width':1280,'height':800})
  await page.wait_for_timeout(160)
  desktop=page.locator('[data-lx-node][tabindex="0"]')
  await desktop.first.wait_for(timeout=10000)
  count=await desktop.count()
  assert count>=2,count
  await desktop.first.focus()
  x=await page.evaluate('document.activeElement?.getAttribute("data-lx-node")')
  await page.keyboard.press('ArrowRight')
  y=await page.evaluate('document.activeElement?.getAttribute("data-lx-node")')
  assert x!=y,(x,y)
  outcomes.append({'width':1280,'graphNodes':count,'arrowRight':x!=y})
  # Reflow/contrast-owner smoke checks for the new map legend and focus affordance.
  for width,scale,theme in [(320,1,'graph'),(390,2,'graph'),(390,1,'graph-night'),(844,1,'graph-night')]:
   await page.set_viewport_size({'width':width,'height':640 if width<844 else 390})
   await page.evaluate('''([scale,theme])=>{document.documentElement.style.fontSize=scale*16+'px';document.documentElement.dataset.theme=theme}''',[scale,theme])
   await page.wait_for_timeout(110)
   sizes=await page.evaluate('''()=>({viewport:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,key:document.querySelector('[data-ui=atlas-map-key]')?.getBoundingClientRect().width})''')
   assert sizes['scroll']<=sizes['viewport']+2,(width,scale,theme,sizes)
   outcomes.append({'width':width,'scale':scale,'theme':theme,'overflow':sizes['scroll']-sizes['viewport']})
  print('ATLAS_KEYBOARD_RESULTS',json.dumps(outcomes,indent=2),flush=True)
  print('PAGE_ERRORS',errors,flush=True)
  assert not errors,errors
  (ROOT/'evidence'/'atlas_keyboard_results.json').write_text(json.dumps(outcomes,indent=2))
  await browser.close()
asyncio.run(main())
