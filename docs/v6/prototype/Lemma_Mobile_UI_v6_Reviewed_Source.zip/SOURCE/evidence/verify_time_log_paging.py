import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(str(Path(__file__).resolve().parents[2] / 'Lemma_UI_Implemented.html'))
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  page=await browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  for k in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
   await page.route(k,lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(HTML.read_text(),wait_until='domcontentloaded',timeout=60000)
  await page.evaluate('location.hash="#/calendar"')
  cal=page.locator('lemma-native-calendar');await cal.locator('[data-cx="new-block"]').first.wait_for(timeout=20000)
  await page.evaluate('''() => {document.querySelector('lemma-native-calendar').shadowRoot.querySelector('a[href="#/carrel/log"]').click()}''')
  await cal.get_by_text('All-time study log').wait_for(timeout=12000)
  summary=await cal.locator('[role=status]').all_text_contents()
  rows=await cal.locator('.cx-log-row').count()
  print('LOG_INITIAL',json.dumps({'summary':summary,'rows':rows}),flush=True)
  await cal.locator('[data-cx="log-more"]').click()
  rows2=await cal.locator('.cx-log-row').count()
  print('LOG_MORE',json.dumps({'rows':rows2}),flush=True)
  assert rows==30 and rows2==60
  assert 'all time' in ' '.join(summary).lower()
  assert not errors,errors
  print('PAGE_ERRORS',errors,flush=True)
  await browser.close()
asyncio.run(main())
