"""Continue plan W14: truthful subject aggregation, clear demo rhythm provenance, linear hour sample."""
from pathlib import Path
p=Path(__file__).parent/'modules/22__Page-Dw2lC2HF.js';s=p.read_text()
def rep(a,b):
 global s
 if s.count(a)!=1:raise RuntimeError(f'{s.count(a)} anchors: {a[:90]}')
 s=s.replace(a,b,1)
# "Other" is a real aggregate on the same scale as named subjects, sorted by time.
rep('''    { top: s, other: c, otherMinutes: l } = A(e),
    u = n ? [...s, ...c] : s,
    d = Math.max(1, ...u.map((e) => e.minutes));''','''    { top: s, other: c, otherMinutes: l } = A(e),
    otherAggregate={subject:{name:`Other`,glyph:`⋯`},minutes:l,aggregateOther:true},
    u = (n ? [...e] : c.length ? [...s,otherAggregate] : [...s])
      .sort((a,b)=>b.minutes-a.minutes||a.subject.name.localeCompare(b.subject.name)),
    d = Math.max(1, ...u.map((e) => e.minutes));''')
rep('''                            title: o(e.subject.name),
                            "aria-label": o(e.subject.name),
                            onClick: () =>
                              a(i === e.subject.name ? null : e.subject.name),''','''                            title: e.aggregateOther?`Expand ${c.length} other subjects`:o(e.subject.name),
                            "aria-label": e.aggregateOther?`Expand Other (${c.length}) subjects, ${t(l)} total`:o(e.subject.name),
                            "aria-expanded":e.aggregateOther?false:undefined,
                            onClick: () => e.aggregateOther?r(true):a(i === e.subject.name ? null : e.subject.name),''')
rep('''                                  source: e.subject.name,
                                }),''','''                                  source: e.aggregateOther?`Other (${c.length}) · Expand`:e.subject.name,
                                }),''')
# Remove the obsolete separate "Other" row (its bar was hidden behind false&&).
start=s.index('''              c.length > 0 &&
                (0, O.jsxs)(`div`, {'''); end=s.index('''            ],
          }),
  });
}
function M''',start)
s=s[:start]+'''              n && c.length>0 && (0,O.jsx)(`button`,{
                type:`button`,onClick:()=>r(false),
                className:`min-h-11 self-start rounded-ctl border border-edge px-3 text-label font-semibold text-ink`,
                children:`Collapse to top subjects and Other`,
              }),
'''+s[end:]
# Clear provenance when the most revisited concept is absent.
rep('''  let n = e || t || `No repeats yet`,''','''  let n = e || (t && !/no repeats yet/i.test(t) ? t : `No verified concept-linked repeats in this range`),''')
# Study rhythm: default to actual/unknown, explicit opt-in for synthetic examples.
key='''  const sample = [
    ["09", 2],'''
rep(key,'''  const [showExample,setShowExample]=(0,E.useState)(false);
  const sample = [
    ["09", 2],''')
rep('''              tab === "attention"
                ? "Demo session log"
                : "Sample data · not range-filtered",''','''              tab === "attention"
                ? "Demo session log"
                : showExample ? "Example · not personal data" : "No verified rhythm history",''')
rep('''              tab === "attention"
                ? "Local demonstration activity, not a verified account history"
                : "Illustrative examples, not measurements or predictions of your focus",''','''              tab === "attention"
                ? "Local demonstration activity, not a verified account history"
                : showExample
                  ? "Illustrative examples, not measurements or predictions of your focus"
                  : "These records do not contain verified focus-by-hour or estimation accuracy history.",''')
rep('''          tab === "focus"
            ? (0, O.jsxs)("div", {''','''          tab!=="attention" && (0,O.jsx)(`button`,{
            type:`button`,onClick:()=>setShowExample(value=>!value),
            className:`min-h-11 self-start rounded-ctl border border-edge bg-[var(--paper)] px-3 text-label font-semibold text-ink`,
            "aria-pressed":showExample,
            children:showExample?`Hide example`:`View example`,
          }),
          !showExample && tab!=="attention"
            ? (0,O.jsx)(`div`,{role:`tabpanel`,className:`py-3 text-label text-ink-2`,children:
                `Not available from these records. Choose View example for an illustrative ${tab===`focus`?`focus-by-hour`:`planning accuracy`} chart.`})
            : tab === "focus"
            ? (0, O.jsxs)("div", {''')
# Chart is spatially linear by actual hour, not ordered slots (09→11=2h, 19→20=1h).
rep('''                    className: "cr-hour-bars",
                    role: "img",''','''                    className: "cr-hour-bars",
                    style:{position:`relative`,display:`block`,height:`130px`,width:`100%`,overflow:`visible`},
                    role: "img",''')
rep('''                          className:
                            "cr-hour-bar " + (Number(hour) >= 19 ? "peak" : ""),
                          children: [''','''                          className:
                            "cr-hour-bar " + (Number(hour) >= 19 ? "peak" : ""),
                          style:{position:`absolute`,left:`${(Number(hour)-9)/13*100}%`,bottom:0,transform:`translateX(-50%)`,width:`30px`,minWidth:0},
                          children: [''')
p.write_text(s)
print('W14 refinements applied',len(s))
