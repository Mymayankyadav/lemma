#!/usr/bin/env python3
"""One-time owner-source edit to improve Atlas spatial keyboard controls and help.
Operate on the detached editable module, never the repository or original.
"""
from pathlib import Path
import json
root=Path(__file__).parent
p=root/'modules/53__index-DcUkykC4.js'
s=p.read_text()

def one(old,new):
 global s
 n=s.count(old)
 if n!=1:raise ValueError(f'expected one owner anchor, got {n}: {old[:130]}')
 s=s.replace(old,new,1)

one('  const renderNode = (n) => {', '''  // Spatial keyboard movement is a convenience alongside the full searchable outline.
  // Focus moves between *visible* nodes; selection and expansion still require Enter/Space.
  const moveAtlasKeyboardFocus = (e) => {
    const order = [...(canvasRef.current?.querySelectorAll('[data-lx-node][tabindex="0"]') || [])];
    if (order.length < 2) return false;
    const index = order.indexOf(e.currentTarget);
    if (index < 0) return false;
    const key = e.key;
    if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(key)) return false;
    e.preventDefault();
    let next;
    if (key === 'Home') next = 0;
    else if (key === 'End') next = order.length - 1;
    else if (key === 'ArrowLeft' || key === 'ArrowUp') next = (index + order.length - 1) % order.length;
    else next = (index + 1) % order.length;
    order[next]?.focus();
    return true;
  };
  const renderNode = (n) => {''')

one("onKeyDown:e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();keyboardSelectRef.current=!n.cluster;action()}}", "onKeyDown:e=>{if(moveAtlasKeyboardFocus(e))return;if(e.key==='Enter'||e.key===' '){e.preventDefault();keyboardSelectRef.current=!n.cluster;action()}}")

one("H('rect',{x:-n.cellWidth/2,y:-n.cellHeight/2,width:n.cellWidth,height:n.cellHeight,\n         rx:5,fill:'var(--paper)',stroke:isActive?'var(--accent)':'var(--ink-3)',\n         strokeWidth:isActive?2.5:1.3,strokeDasharray:n.cluster?'5 4':undefined}),", "H('rect',{x:-n.cellWidth/2,y:-n.cellHeight/2,width:n.cellWidth,height:n.cellHeight,\n         rx:5,fill:'var(--paper)',stroke:isActive?'var(--accent)':'var(--ink-3)',\n         strokeWidth:isActive?2.5:1.3,strokeDasharray:n.cluster?'5 4':undefined}),\n      H('rect',{className:'lg-node-focus',x:-n.cellWidth/2+2/zoom,y:-n.cellHeight/2+2/zoom,\n         width:n.cellWidth-4/zoom,height:n.cellHeight-4/zoom,rx:5/zoom,\n         fill:'none',stroke:'var(--accent)',strokeWidth:3/zoom,opacity:0,pointerEvents:'none'}),")

one('''        onKeyDown: (e) => {
          if (e.key === "Enter" || e.key === " ") {''', '''        onKeyDown: (e) => {
          if (moveAtlasKeyboardFocus(e)) return;
          if (e.key === "Enter" || e.key === " ") {''')

one('''      H(
        "div",
        { className: "lg-zoom" },
        H(
          "button",
          { onClick: () => zoomBy(1.23), "aria-label": "Zoom in" },
          "+",
        ),
        H("span", null, Math.round(zoom * 100) + "%"),
        H(
          "button",
          { onClick: () => zoomBy(1 / 1.23), "aria-label": "Zoom out" },
          "−",
        ),
      ),''', '''      H(
        "div",
        { className: "lg-zoom", "aria-label": "Map zoom controls" },
        H("button", {type:"button", onClick:()=>zoomBy(1/1.23),"aria-label":"Zoom out"}, "−"),
        H("button", {type:"button", onClick:fit,"aria-label":"Fit map"}, "Fit"),
        H("button", {type:"button", onClick:()=>zoomBy(1.23),"aria-label":"Zoom in"}, "+"),
        H("span", {"aria-label":"Current zoom"}, Math.round(zoom*100)+"%"),
      ),''')

one('''    H(
      "details",
      {
        className: "lg-outline",''', '''    H('details',{className:'lg-map-key', 'data-ui':'atlas-map-key'},
      H('summary',null,'Map key and keyboard help'),
      H('div',{className:'lg-map-key-content'},
        H('p',null,'Focus a visible concept; use arrow keys or Home/End to move, then Enter or Space to inspect or expand. Browse the outline below to search every concept.'),
        H('ul',null,
          H('li',null,H('span',{className:'lg-map-key-mark',style:{background:'#86D39C'},'aria-hidden':'true'}),'Demonstrated'),
          H('li',null,H('span',{className:'lg-map-key-mark',style:{background:'#EAAF64'},'aria-hidden':'true'}),'Re-check due'),
          H('li',null,H('span',{className:'lg-map-key-mark',style:{background:'#FF7B6B'},'aria-hidden':'true'}),'In progress'),
          H('li',null,H('span',{className:'lg-map-key-mark',style:{background:'#263441',border:'1px solid var(--ink-3)'},'aria-hidden':'true'}),'Not started')
        ),
        H('p',null,'Structure links connect parent and child concepts. Prerequisites show required ideas; Related shows other linked concepts. The All edges filter combines them.')
      )
    ),
    H(
      "details",
      {
        className: "lg-outline",''')
p.write_text(s)

# Inline patch edits source-owned Atlas visual-system declaration, not an extra CSS layer.
patches=root/'inline-patches.json'
data=json.loads(patches.read_text())
anchor='.lg-outline{margin:12px 0 18px;'
if any(anchor in x['old'] for x in data):raise ValueError('owner CSS anchor already patched')
styles='''.lg-map-key{max-width:1200px;margin:12px auto 0;border:1px solid var(--edge);border-radius:6px;background:var(--paper);color:var(--ink)}
.lg-map-key>summary{min-height:44px;display:flex;align-items:center;cursor:pointer;padding:10px 16px;font-size:14px;font-weight:600}
.lg-map-key-content{padding:0 16px 14px;font-size:14px;line-height:1.5;color:var(--ink-2)}
.lg-map-key-content p{margin:8px 0}
.lg-map-key-content ul{display:flex;flex-wrap:wrap;gap:8px 20px;list-style:none;margin:12px 0;padding:0}
.lg-map-key-content li{display:flex;align-items:center;gap:8px;min-height:28px}
.lg-map-key-mark{display:inline-block;width:12px;height:12px;flex:none;border-radius:50%}
.lg-map-key>summary:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
'''
data.append({'old':anchor,'new':styles+anchor})
patches.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
print('Atlas owner module and original-style declaration amended')
