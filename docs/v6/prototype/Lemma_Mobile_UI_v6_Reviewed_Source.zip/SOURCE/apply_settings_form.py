from pathlib import Path
base=Path('/mnt/data/lemma-ui-remediation/modules')
def patch(path,a,b):
 s=path.read_text()
 if s.count(a)!=1:raise Exception(f'{path.name}: {s.count(a)} anchors for {a[:60]!r}')
 path.write_text(s.replace(a,b))
f=next(base.glob('*__Page-CQY07xEs.js'))
patch(f,'id: `project-title`,\n                  required: !0,','id: `project-title`,\n                  "aria-describedby": !S.trim() ? `project-name-help` : void 0,\n                  required: !0,')
patch(f,'''            (0, x.jsx)(v, {
              size: `xl`,
              className: `w-full`,
              type: `submit`,''','''            !S.trim() && (0,x.jsx)(`p`,{
              id:`project-name-help`,
              className:`text-label text-ink-2`,
              children:`Enter a project name to continue.`,
            }),
            (0, x.jsx)(v, {
              size: `xl`,
              className: `w-full`,
              type: `submit`,''')
settings=next(base.glob('*__Page--IE2f0uU.js'))
patch(settings, 'children: `Two graph-paper worlds. Text is compact and motion stays calm.`,','children: `Automatic follows your device. Day and Night retain the notebook design.`,')
patch(settings, 'children: `Make a new address`,','children: `Replace connector address`,')
patch(settings, 'title: `Make a new address?`,','title: `Replace connector address?`,')
patch(settings, 'children: `Make new`,','children: `Replace address`,')
# Change direct sign-out to explicit confirmation, retaining existing mutation and navigation.
patch(settings, '''            onClick: async () => {
              try {
                (await x.mutateAsync(), E() !== `demo` && C(`/sign-in`));
              } catch {
                S(`Couldn't sign out.`, { tone: `danger` });
              }
            },
            children: `Sign out`,''','''            onClick: () => N(`signout`),
            children: `Sign out`,''')
patch(settings,'''      (0, W.jsxs)(m, {
        open: M === `rotate`,
        onClose: () => N(null),''','''      (0,W.jsxs)(m,{
        open:M===`signout`,
        onClose:()=>N(null),
        title:`Sign out of Lemma?`,
        children:[
          (0,W.jsx)(`p`,{className:`mb-5 text-ink-2`,children:`Sign out ends access to this workspace on this device. Review any unsaved edits and finish or pause an active focus session before signing out.`}),
          (0,W.jsxs)(`div`,{className:`grid grid-cols-2 gap-3`,children:[
            (0,W.jsx)(D,{variant:`ghost`,onClick:()=>N(null),children:`Cancel`}),
            (0,W.jsx)(D,{disabled:x.isPending,onClick:async()=>{try{await x.mutateAsync();N(null);E()!==`demo`&&C(`/sign-in`)}catch{S(`Couldn't sign out.`,{tone:`danger`})}},children:`Sign out`}),
          ]}),
        ],
      }),
      (0, W.jsxs)(m, {
        open: M === `rotate`,
        onClose: () => N(null),''')
print('settings and project form patched')
