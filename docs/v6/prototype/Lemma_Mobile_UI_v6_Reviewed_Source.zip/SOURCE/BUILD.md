# Build the mobile UI redesign

Reviewed-source follow-up: see `../REVIEW_FIX_REPORT.md`. After the existing
source/state/style checks, run the rendered Inbox regression:

```bash
python SOURCE/tests/inbox-chrome.browser.py
```

It requires Python Playwright and Chromium at `/usr/bin/chromium`. It writes
current evidence to `validation/inbox-chrome/` and must fail against the original
v6 HTML. The original uploaded input remains immutable. Keep `dist/index.html`
identical to the packed output when sharing this reviewed source.

From the extracted root containing the HTML inputs and `SOURCE/`:

```bash
python SOURCE/repack.py pack
python SOURCE/repack.py verify
```

The output is `Lemma_UI_Implemented.html`. Input `01_Original_Unmodified.html` is immutable. The manifest preserves the original 78 import IDs. Gzip timestamp and OS byte are fixed for reproducible bytes. `DESIGN_HANDOFF.md` describes the mobile redesign and its verification limits.

Edit `modules/` for React components, `owners/design-system.css` for shared application styles, `owners/lemma-native-calendar-runtime.js` for Calendar rendering, and `styles/calendar.css` for its stylesheet. The packer embeds that CSS at `__LEMMA_CALENDAR_CSS__`. Historical apply/continue/migration scripts are retained for provenance: do not replay them over the edited source.

Run the current source checks:

```bash
node --experimental-vm-modules SOURCE/tests/mobile-ui.test.mjs
node SOURCE/tests/v5-reaudit.test.cjs  # includes 26 original + 10 follow-up + 17 re-audit checks
node --experimental-vm-modules SOURCE/tests/syntax.test.mjs
node SOURCE/evidence/test_effort_metrics.js
python SOURCE/tests/check_styles.py  # requires tinycss2
```

Repack before state/syntax checks: they inspect generated HTML too. These checks do not substitute for browser/device testing. Current results are in `validation/mobile-redesign/` and `validation/audit/`. Read `../V5_REAUDIT_RESPONSE.md` and `../AUDIT_RESPONSE.md` before reusing historical evidence.

`domain/notebook-runtime.js` owns shared records/feedback; `domain/effort-metrics.js` owns saved-time calculations. They are embedded through source-file anchors in `inline-patches.json`. Edit them rather than generated HTML. Copy the final rebuilt HTML to `dist/index.html` before publishing.

The following historical browser scripts target the preceding screenshot-fixes layout and some old control names. Adapt them to the redesigned controls before reuse:

```bash
python -m http.server 8765 --bind 127.0.0.1
python validation/screenshot-feedback/capture.py after 393 night
python validation/screenshot-feedback/capture.py after 320 night
python validation/screenshot-feedback/capture.py after 393 day
python validation/screenshot-feedback/capture.py after 1365 night
python validation/screenshot-feedback/verify.py
python validation/check.py
python SOURCE/evidence/verify_atlas_keyboard_mapkey.py
```

The scripts require Python Playwright and Chromium; update `/usr/bin/chromium` in the scripts if your executable differs. Current results and screenshots are in `validation/screenshot-feedback/`; the preceding full-layout evidence remains in the separate November 3 source archive. The current report is `../SCREENSHOT_FIX_REPORT.md`.
