"""W16 mobile queue: full-height modal with focus and scroll ownership.
Changes only Page-RJ1UO7Rb packed-module owner and source stylesheet anchors.
"""
from pathlib import Path
import json
root=Path(__file__).resolve().parent
p=root/'modules/23__Page-RJ1UO7Rb.js';s=p.read_text()
def change(old,new):
 global s
 assert s.count(old)==1,(s.count(old),old[:100]);s=s.replace(old,new,1)
change('''    [q, ue] = (0, k.useState)(0),
    J =''','''    [q, ue] = (0, k.useState)(0),
    [queueOpen, setQueueOpen] = (0,k.useState)(false),
    queueOpener=(0,k.useRef)(null),
    queuePanel=(0,k.useRef)(null),
    J =''')
change('''  (0,k.useEffect)(()=>lemmaDecisionLedger.subscribe(setLedger),[]);''','''  (0,k.useEffect)(()=>lemmaDecisionLedger.subscribe(setLedger),[]);
  (0,k.useEffect)(()=>{
    if(!queueOpen)return;
    const panel=queuePanel.current;
    if(!panel)return;
    const priorOverflow=document.body.style.overflow;
    document.body.style.overflow=`hidden`;
    // One scroll owner while the queue is modal on mobile.
    const focusable=()=>Array.from(panel.querySelectorAll(`button:not([disabled]),input:not([disabled]),select:not([disabled]),a[href]`))
      .filter(el=>el.getClientRects().length>0);
    requestAnimationFrame(()=>{panel.querySelector(`[data-queue-close]`)?.focus()});
    const onKey=(event)=>{
      if(event.key===`Escape`){event.preventDefault();setQueueOpen(false);return}
      if(event.key!==`Tab`)return;
      const items=focusable();if(!items.length)return;
      const first=items[0],last=items[items.length-1];
      if(event.shiftKey&&(document.activeElement===first||!panel.contains(document.activeElement))){event.preventDefault();last.focus()}
      else if(!event.shiftKey&&(document.activeElement===last||!panel.contains(document.activeElement))){event.preventDefault();first.focus()}
    };
    document.addEventListener(`keydown`,onKey,true);
    return()=>{document.removeEventListener(`keydown`,onKey,true);document.body.style.overflow=priorOverflow;
      queueOpener.current?.focus({preventScroll:true})};
  },[queueOpen]);''')
change('''                  children: [
                    (0, N.jsxs)(`section`, {
                      "aria-label": `Proposal groups`,
                      className: `flex flex-col gap-3`,
                      children: [''','''                  children: [
                    (0,N.jsxs)(`div`,{className:`lemma-queue-mobile-trigger`,children:[
                      (0,N.jsx)(`span`,{className:`text-label text-ink-2`,children:
                        `Card ${X.indexOf(Q)+1} of ${X.length} · ${P(Q.projectSlug)}`}),
                      (0,N.jsx)(`button`,{ref:queueOpener,type:`button`,className:`min-h-12 rounded-ctl border border-edge bg-[var(--paper)] px-4 text-label font-semibold text-ink`,
                        onClick:()=>setQueueOpen(true),children:`Browse queue · ${X.length.toLocaleString()} cards`})
                    ]}),
                    (0, N.jsxs)(`section`, {
                      ref:queuePanel,
                      "aria-label": `Proposal groups`,
                      role:queueOpen?`dialog`:`region`,
                      "aria-modal":queueOpen?`true`:undefined,
                      "data-queue-open":queueOpen?`true`:`false`,
                      className: `lemma-proposal-queue flex flex-col gap-3`,
                      children: [
                        (0,N.jsxs)(`div`,{className:`lemma-queue-mobile-header`,children:[
                          (0,N.jsxs)(`div`,{children:[(0,N.jsx)(`strong`,{className:`text-body text-ink`,children:`Browse proposal queue`}),
                            (0,N.jsx)(`p`,{className:`text-label text-ink-2`,children:`${X.length.toLocaleString()} cards to inspect · 20 per page`})]}),
                          (0,N.jsx)(`button`,{type:`button`,`data-queue-close`:true,className:`min-h-11 rounded-ctl border border-edge px-4 text-label font-semibold text-ink`,
                            onClick:()=>setQueueOpen(false),children:`Close queue`})
                        ]}),''')
change('''                                          (F(e.id), V(!1)); requestAnimationFrame(()=>{const el=document.getElementById('lemma-proposal-detail');el?.scrollIntoView({block:'start'});el?.focus({preventScroll:true})});''','''                                          (F(e.id), V(!1),setQueueOpen(false)); requestAnimationFrame(()=>{const el=document.getElementById('lemma-proposal-detail');el?.scrollIntoView({block:'start'});el?.focus({preventScroll:true})});''')
p.write_text(s)
fixes_path=root/'inline-patches.json';fixes=json.loads(fixes_path.read_text())
old='@media(max-width:799px){#main-content{padding-inline:16px!important}.lemma-proposal-layout{display:flex;flex-direction:column}.lemma-proposal-layout>section[aria-label="Proposal groups"]{width:100%;max-height:200px;overflow:auto}.lemma-proposal-layout>#lemma-proposal-detail{width:100%;max-height:none}'
new='''@media(max-width:799px){#main-content{padding-inline:16px!important}.lemma-proposal-layout{display:flex;flex-direction:column}.lemma-proposal-layout>section[aria-label="Proposal groups"]{width:100%;max-height:none;overflow:visible}.lemma-proposal-layout>#lemma-proposal-detail{width:100%;max-height:none}'''
# Replace the original exact compact CSS while retaining all unrelated media styles.
assert (root/'Lemma_UI_Final.html').read_text().count(old)==1
fixes.append({'old':old,'new':new})
fixes.append({'old':'.lemma-proposal-layout{display:grid;grid-template-columns:minmax(250px,340px) minmax(0,1fr);gap:16px;align-items:start}',
'new':'''/* W16 Inbox queue owner: desktop list, phone full-height modal.
   The editable component controls open state, focus trap and background scroll. */
.lemma-queue-mobile-trigger,.lemma-queue-mobile-header{display:none}
.lemma-proposal-layout{display:grid;grid-template-columns:minmax(250px,340px) minmax(0,1fr);gap:16px;align-items:start}
@media(max-width:799px){
 .lemma-queue-mobile-trigger{display:flex;min-width:0;align-items:start;flex-wrap:wrap;gap:10px;justify-content:space-between}
 .lemma-queue-mobile-header{display:flex;align-items:start;justify-content:space-between;gap:12px;position:sticky;top:0;background:var(--paper);z-index:2;border-bottom:1px solid var(--edge);padding:8px 0 12px}
 .lemma-proposal-layout>.lemma-proposal-queue[data-queue-open="false"]{display:none}
 .lemma-proposal-layout>.lemma-proposal-queue[data-queue-open="true"]{display:flex;position:fixed;inset:0;z-index:110;box-sizing:border-box;
   max-height:100dvh;min-height:100dvh;width:100vw;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;
   background:var(--paper);padding:calc(12px + env(safe-area-inset-top)) 16px calc(28px + env(safe-area-inset-bottom));
   border:0;border-radius:0;scrollbar-gutter:stable}
}
'''})
fixes_path.write_text(json.dumps(fixes,ensure_ascii=False,indent=2)+'\n')
print('W16 mobile queue sheet applied')
