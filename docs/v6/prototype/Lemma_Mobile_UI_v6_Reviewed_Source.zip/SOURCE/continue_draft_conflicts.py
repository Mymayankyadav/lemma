"""W16: protect local card drafts against stale upstream versions and accidental loss."""
from pathlib import Path
p=Path(__file__).resolve().parent/'modules/23__Page-RJ1UO7Rb.js'
s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a[:90]);s=s.replace(a,b,1)
rep('''    [W, G] = (0, k.useState)(``),
    [le, K]''','''    [W, G] = (0, k.useState)(``),
    [editorBase,setEditorBase]=(0,k.useState)(null),
    [editorStart,setEditorStart]=(0,k.useState)(null),
    [draftConflict,setDraftConflict]=(0,k.useState)(false),
    [le, K]''')
rep('''                            if(saved && (saved.baseFront!==Q.card.front || saved.baseBack!==Q.card.back)){
                              a(`This proposal changed since your local draft was saved. Review both versions before approval.`,{tone:`danger`});
                            }
                            U(saved?.front??Q.card.front);G(saved?.back??Q.card.back);V(!0);''','''                            const conflict=!!saved&&(saved.baseFront!==Q.card.front||saved.baseBack!==Q.card.back);
                            if(conflict)a(`This proposal changed since your draft. Compare both versions before approval.`,{tone:`danger`});
                            const nextFront=saved?.front??Q.card.front,nextBack=saved?.back??Q.card.back;
                            setEditorBase({id:Q.id,front:saved?.baseFront??Q.card.front,back:saved?.baseBack??Q.card.back});
                            setEditorStart({front:nextFront,back:nextBack});
                            setDraftConflict(conflict);
                            U(nextFront);G(nextBack);V(!0);''')
rep('''      (0, N.jsx)(S, {
        open: ce,
        onClose: () => V(!1),''','''      (0, N.jsx)(S, {
        open: ce,
        onClose: () => {
          if(editorStart&&(H!==editorStart.front||W!==editorStart.back)&&!window.confirm(`Discard unsaved card edits?`))return;
          V(!1);
        },''')
rep('''            (0, N.jsx)(`p`, {
              className: `text-label text-ink-3`,
              children: `Preview`,
            }),''','''            (draftConflict || (editorBase&&Q?.card&&(Q.id!==editorBase.id||Q.card.front!==editorBase.front||Q.card.back!==editorBase.back)))&&
              (0,N.jsxs)(`section`,{role:`alert`,className:`flex flex-col gap-3 rounded-ctl border border-edge bg-[var(--paper)] p-3`,children:[
                (0,N.jsx)(`strong`,{className:`text-body text-ink`,children:`Proposal changed — review before approval`}),
                (0,N.jsx)(`p`,{className:`text-label text-ink-2`,children:`The current pending proposal differs from the version on which this draft was based. Compare the latest proposal with your edited content. Nothing has been approved.`}),
                (0,N.jsxs)(`div`,{className:`grid grid-cols-1 gap-2`,children:[
                  (0,N.jsxs)(`details`,{children:[(0,N.jsx)(`summary`,{className:`min-h-11 cursor-pointer font-semibold text-ink`,children:`Latest proposal from Inbox`}),
                    (0,N.jsx)(T,{source:Q.card?.front??``,variant:`card`}),(0,N.jsx)(T,{source:Q.card?.back??``,variant:`answer`})]}),
                  (0,N.jsxs)(`details`,{children:[(0,N.jsx)(`summary`,{className:`min-h-11 cursor-pointer font-semibold text-ink`,children:`My saved/edited draft`}),
                    (0,N.jsx)(T,{source:H,variant:`card`}),(0,N.jsx)(T,{source:W,variant:`answer`})]})
                ]}),
                (0,N.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[
                  (0,N.jsx)(`button`,{type:`button`,className:`min-h-11 rounded-ctl border border-edge px-3 text-label font-semibold text-ink`,
                    onClick:()=>{U(Q.card?.front??``);G(Q.card?.back??``);setEditorBase({id:Q.id,front:Q.card?.front??``,back:Q.card?.back??``});setDraftConflict(false)},children:`Use latest proposal`}),
                  (0,N.jsx)(`button`,{type:`button`,className:`min-h-11 rounded-ctl border border-edge px-3 text-label font-semibold text-ink`,
                    onClick:()=>{setEditorBase({id:Q.id,front:Q.card?.front??``,back:Q.card?.back??``});setDraftConflict(false)},children:`Keep my draft after comparing`})
                ]})
              ]}),
            (0, N.jsx)(`p`, {
              className: `text-label text-ink-3`,
              children: `Preview`,
            }),''')
rep('''              (0,N.jsx)(C,{variant:`ghost`,onClick:()=>V(!1),children:`Cancel`}),''','''              (0,N.jsx)(C,{variant:`ghost`,onClick:()=>{
                if(editorStart&&(H!==editorStart.front||W!==editorStart.back)&&!window.confirm(`Discard unsaved card edits?`))return;
                V(!1);
              },children:`Cancel`}),''')
rep('''                try{localStorage.setItem(`lemma.proposal.draft:${Q.projectSlug}:${Q.id}`,JSON.stringify({front:H,back:W,baseFront:Q.card.front,baseBack:Q.card.back,savedAt:new Date().toISOString()}));a(`Draft saved on this device`);V(!1)}catch{a(`Could not save the local draft`,{tone:`danger`})}''','''                try{localStorage.setItem(`lemma.proposal.draft:${Q.projectSlug}:${Q.id}`,JSON.stringify({front:H,back:W,
                  baseFront:editorBase?.front??Q.card.front,baseBack:editorBase?.back??Q.card.back,
                  savedAt:new Date().toISOString()}));a(`Draft saved on this device`);V(!1)}catch{a(`Could not save the local draft`,{tone:`danger`})}''')
rep('''              (0,N.jsx)(C,{disabled:J||!H.trim(),onClick:()=>Q&&void $(Q,!0,{front:H,back:W}),children:`Approve edits`}),''','''              (0,N.jsx)(C,{disabled:J||!H.trim()||draftConflict||!Q?.card||!editorBase||Q.id!==editorBase.id||Q.card.front!==editorBase.front||Q.card.back!==editorBase.back,
                onClick:()=>Q&&void $(Q,!0,{front:H,back:W}),children:`Approve edits`}),''')
p.write_text(s)
print('W16 draft conflict guard and dirty Cancel applied')
