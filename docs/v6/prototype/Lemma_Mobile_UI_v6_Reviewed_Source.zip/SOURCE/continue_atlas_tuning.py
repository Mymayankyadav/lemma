from pathlib import Path
p=Path(__file__).resolve().parent/'modules/53__index-DcUkykC4.js'
s=p.read_text()
def change(a,b):
 global s
 assert s.count(a)==1,(a[:80],s.count(a))
 s=s.replace(a,b,1)
change('''  const inspectorRef=(0,k.useRef)(null);
  (0,k.useEffect)(()=>{if(!selected)return;const id=requestAnimationFrame(()=>{const el=inspectorRef.current;if(!el)return;if(document.activeElement?.matches?.(':focus-visible')){el.scrollIntoView({block:'nearest'});el.focus({preventScroll:true})}});return()=>cancelAnimationFrame(id)},[selected]);''',
'''  const inspectorRef=(0,k.useRef)(null),keyboardSelectRef=(0,k.useRef)(false);
  // Keyboard selection may move reading focus to the details; pointer selection
  // must not scroll the whole browsing page out from under the map.
  (0,k.useEffect)(()=>{if(!selected||!keyboardSelectRef.current)return;
    const id=requestAnimationFrame(()=>{const el=inspectorRef.current;
      if(el&&keyboardSelectRef.current){el.scrollIntoView({block:'nearest'});el.focus({preventScroll:true})}
      keyboardSelectRef.current=false;
    });return()=>cancelAnimationFrame(id)
  },[selected]);''')
change('''      const cols=Math.max(1,Math.floor((size.w-32)/152));''', '''      const cols=Math.max(1,Math.floor((size.w-16)/152));''')
change('''      const page=Math.max(0,atlasPages.get(key)||0);
      const pages=Math.max(1,Math.ceil(ids.length/Math.max(1,capacity-(ids.length>capacity?1:0))));
      const startIndex=page>=pages?0:page*Math.max(1,capacity-1);
      const moreAtEnd=ids.length>startIndex+capacity;
      const showCount=moreAtEnd?Math.max(0,capacity-1):capacity;''',
'''      const pageSize=Math.max(1,capacity-1),totalPages=Math.max(1,Math.ceil(ids.length/pageSize));
      const page=Math.max(0,(atlasPages.get(key)||0)%totalPages);
      const startIndex=page*pageSize;
      const hasContinuation=ids.length>capacity;
      const moreAtEnd=hasContinuation&&startIndex+pageSize<ids.length;
      const showCount=hasContinuation?pageSize:capacity;''')
change('''      if(moreAtEnd){
        const count=ids.length-(startIndex+showCount);
        const id='__atlas-more-'+key;
        place(id,{name:count+' more '+(parent?'concepts':'subjects'),children:[],status:'unseen'},
          visibleIds.length%cols,Math.floor(visibleIds.length/cols),parent?1:0,true);
      }''',
'''      if(hasContinuation){
        const count=ids.length-(startIndex+showCount);
        const id='__atlas-more-'+key;
        const label=moreAtEnd?count+' more '+(parent?'concepts':'subjects'):'Back to first '+(parent?'concepts':'subjects');
        place(id,{name:label,children:[],status:'unseen'},
          visibleIds.length%cols,Math.floor(visibleIds.length/cols),parent?1:0,true);
      }''')
change('''        onClick:action,onKeyDown:e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();action()}},''',
'''        onClick:()=>{keyboardSelectRef.current=false;action()},onKeyDown:e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();keyboardSelectRef.current=!n.cluster;action()}},''')
change('''        onClick: () => fold(n.id),
        onKeyDown: (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            fold(n.id);''',
'''        onClick: () => {keyboardSelectRef.current=false;fold(n.id)},
        onKeyDown: (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();keyboardSelectRef.current=true;
            fold(n.id);''')
# Remove decorative radial markers only in compact overview; full-screen graph is unchanged.
change('''          H("circle", {
            r: 70,
            stroke: "#334354",''', '''          !graph.compact&&H("circle", {
            r: 70,
            stroke: "#334354",''')
change('''          H("circle", {
            r: 180,
            stroke: "#2C3947",''', '''          !graph.compact&&H("circle", {
            r: 180,
            stroke: "#2C3947",''')
change('''          H("circle", {
            r: 335,
            stroke: "#2C3947",''', '''          !graph.compact&&H("circle", {
            r: 335,
            stroke: "#2C3947",''')
change('''          H("circle", {
            r: 21,
            fill: "#212E3B",''', '''          !graph.compact&&H("circle", {
            r: 21,
            fill: "#212E3B",''')
change('''          H(
            "text",
            {
              textAnchor: "middle",
              y: 3.8,
              fontFamily: "Newsreader,Georgia,serif",
              fontSize: 13,
              fill: "#E7EEF4",
            },
            "A",
          ),''', '''          !graph.compact&&H(
            "text",
            {
              textAnchor: "middle",
              y: 3.8,
              fontFamily: "Newsreader,Georgia,serif",
              fontSize: 13,
              fill: "#E7EEF4",
            },
            "A",
          ),''')
p.write_text(s)
print('Atlas tuning updated',len(s))
