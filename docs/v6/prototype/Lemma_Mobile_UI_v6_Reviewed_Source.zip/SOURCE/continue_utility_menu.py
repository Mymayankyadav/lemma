"""W02: consistent, named utility navigation on non-Today browse/detail routes.
No routes are removed, no extra bottom tab and no persistent store added.
"""
from pathlib import Path
p=Path(__file__).parent/'modules/53__index-DcUkykC4.js';s=p.read_text()
anchor='''        children: [
          !a && (0, A.jsx)(Pn, {}),
          (0, A.jsx)(Hn, { path: t.pathname }),'''
replace='''        children: [
          i && !r && t.pathname!==`/` && (0,A.jsx)(`div`,{
            "data-ui":`utility-menu-row`,
            className:`relative z-40 mb-1 flex min-h-11 justify-end`,
            children:(0,A.jsxs)(`details`,{
              key:t.pathname,
              "data-ui":`utility-menu`,
              className:`relative`,
              children:[
                (0,A.jsx)(`summary`,{
                  className:`flex min-h-11 min-w-11 cursor-pointer items-center justify-center gap-2 rounded-ctl border border-edge-3 bg-[var(--paper)] px-3 text-label font-semibold text-ink`,
                  children:`Menu`,
                }),
                (0,A.jsx)(`nav`,{
                  "aria-label":`Notebook utilities`,
                  className:`absolute right-0 top-full z-50 mt-1 flex min-w-48 flex-col gap-1 rounded-ctl border border-edge-3 bg-[var(--paper)] p-2 shadow-lg`,
                  children:[
                    [`/atlas`,`Atlas`],[`/proposals`,`Inbox`],[`/settings`,`Settings`]
                  ].map(([to,label])=>(0,A.jsx)(_e,{
                    to,className:`flex min-h-11 items-center rounded-ctl px-3 text-body text-ink hover:bg-[var(--paper-2)] focus-visible:outline-2 focus-visible:outline-[var(--ink)]`,
                    children:label,
                  },to)),
                }),
              ],
            }),
          }),
          !a && (0, A.jsx)(Pn, {}),
          (0, A.jsx)(Hn, { path: t.pathname }),'''
assert s.count(anchor)==1,(s.count(anchor))
s=s.replace(anchor,replace)
p.write_text(s)
print('utility menu added to browsing shell')
