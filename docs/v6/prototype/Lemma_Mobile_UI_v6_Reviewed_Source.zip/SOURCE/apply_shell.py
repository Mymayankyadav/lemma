from pathlib import Path
p=Path('/mnt/data/lemma-ui-remediation/modules/53__index-DcUkykC4.js')
s=p.read_text()
def sub(a,b):
 global s
 n=s.count(a)
 if n!=1:raise Exception(f'{n} occurrences {a[:160]!r}')
 s=s.replace(a,b)
sub('var Un = new Set([`/`, `/projects`, `/calendar`, `/review`, `/insights`]);',
    'var Un = new Set([`/`, `/projects`, `/calendar`, `/review`, `/insights`]);\nvar BrowseDetailPaths = new Set([`/atlas`, `/settings`, `/proposals`, `/projects/new`, `/cards`, `/review/done`, `/kit`]);')
sub('    i = Un.has(t.pathname),\n    a = t.pathname === `/atlas`,\n    o = i,',
    '    i = Un.has(t.pathname) || BrowseDetailPaths.has(t.pathname) || t.pathname.startsWith(`/p/`) || t.pathname.startsWith(`/cards/`) || t.pathname.startsWith(`/s/`) || t.pathname.startsWith(`/proposals/`),\n    a = t.pathname === `/atlas`,\n    o = Un.has(t.pathname),')
sub('          ? `relative min-h-dvh w-full overflow-hidden`',
    '          ? `relative min-h-dvh w-full pb-[calc(var(--tab)+env(safe-area-inset-bottom)+24px)]`')
sub('          className: ({ isActive: e }) =>\n            `relative flex min-h-11 min-w-0 flex-1 basis-0 flex-col items-center justify-center gap-[2px] rounded-ctl ${e ? `text-amber` : `text-ink-3`}`,',
    '          className: ({ isActive: e }) =>\n            `relative flex min-h-11 min-w-0 flex-1 basis-0 flex-col items-center justify-center gap-[2px] rounded-ctl ${e ? `text-ink border-t-2 border-current` : `text-ink-3`}`,')
sub('                  className: `relative`,\n                  children: [\n                    (0, A.jsx)(i,',
    '                    className: `relative inline-flex items-center gap-1`,\n                  children: [\n                    (0, A.jsx)(i,')
sub('className: `absolute -right-3 -top-2 flex min-w-5 items-center justify-center rounded-[4px] px-1 text-[10px] font-bold tabular-nums`,',
    'className: `flex min-w-5 items-center justify-center rounded-[4px] px-1 text-[12px] font-bold tabular-nums`,')
# mark parent route accessible in nav: current pathname and selected state as a class and aria-current.  `NavLink` uses route end true so highlight only if exactly matched.
sub('function Nn() {\n  let e = !!T(),\n    { data: t } = Ht();',
    'function Nn() {\n  let e = !!T(),\n    { data: t } = Ht(),\n    currentPath = me().pathname;')
sub('          className: ({ isActive: e }) =>\n            `relative flex min-h-11 min-w-0 flex-1 basis-0 flex-col items-center justify-center gap-[2px] rounded-ctl ${e ? `text-ink border-t-2 border-current` : `text-ink-3`}`,',
    '          className: ({ isActive: e }) =>\n            `relative flex min-h-11 min-w-0 flex-1 basis-0 flex-col items-center justify-center gap-[2px] rounded-ctl ${(e || (r === `Paths` && (currentPath.startsWith(`/p/`) || currentPath === `/projects/new`)) || (r === `Review` && (currentPath.startsWith(`/cards`) || currentPath.startsWith(`/review/`)))) ? `text-ink border-t-2 border-current` : `text-ink-3`}`,')
p.write_text(s)
print('shell patch applied',len(s))
