"""One-time source-owner patch for timer-to-log record semantics in detached mockup."""
from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
orig=(root/'Lemma_UI_Final.html').read_text();pfile=root/'inline-patches.json';patches=json.loads(pfile.read_text())
def add(old,new):
 assert orig.count(old)==1,(old[:90],orig.count(old))
 patches.append({'old':old,'new':new})
# A stable per-focus session identity and elapsed-time segments survive rerenders,
# break transitions, reloads and duplicate click/commit. Persist only a single log row.
helper='''function crSessionIdentity(t){return t.sessionId||('legacy-'+String(t.startedAt||t.stamp||t.rev||'unknown')+'-'+String(t.activity||''));}
function crCommitTimerSession(rating='Unrated',note='',topics=[]){
 const t=S.timer,now=Date.now();
 const seconds=Math.max(0,t.phase==='break'?Number(t.studyElapsed||0):elapsed());
 if(!Number.isFinite(seconds)||seconds<=0)return null;
 const id='focus:'+crSessionIdentity(t);
 const existing=S.entries.find(e=>e.id===id);
 if(existing)return existing;
 const intervals=Array.isArray(t.studyIntervals)?t.studyIntervals.map(x=>({...x})).filter(x=>Number.isFinite(x.start)&&Number.isFinite(x.end)&&x.end>x.start):[];
 if(t.phase==='study'&&t.running){
  const since=t.activeStudyStart||Math.max(Number(t.startedAt)||0,now-Math.max(0,seconds-Number(t.studyElapsed||0))*1000);
  if(since&&since<now)intervals.push({start:since,end:now});
 }
 // Legacy/mock sessions lack interval anchors. Keep their logged duration and
 // record the inferred interval as approximate rather than a fictitious time.
 const approximate=!intervals.length;
 if(approximate)intervals.push({start:now-seconds*1000,end:now});
 const startEpoch=Math.min(...intervals.map(x=>x.start));
 const start=new Date(startEpoch),finish=new Date(now);
 const hhmm=x=>String(x.getHours()).padStart(2,'0')+':'+String(x.getMinutes()).padStart(2,'0');
 const entry={id,sessionId:crSessionIdentity(t),subject:t.activity,
  title:t.intent||t.activity,date:dkey(start),start:hhmm(start),end:hhmm(finish),
  min:Math.max(1,Math.round(seconds/60)),focus:rating,note,
  startInstant:start.toISOString(),endInstant:finish.toISOString(),
  intervals:intervals.map(x=>({start:new Date(x.start).toISOString(),end:new Date(x.end).toISOString()})),
  timeApproximate:approximate,...jointContext(t),topics};
 S.entries.push(entry);
 return entry;
}
'''
add('function finish(){',helper+'function finish(){')
old=re.search(r'function stopSession\(skip=false\)\{.*?\}\nfunction takeBreak\(\)',orig,re.S).group(0)
new='''function stopSession(skip=false){
 const rating=val('cx-rating');
 if(!skip&&rating==='Choose a rating'){$('#cx-form-error').textContent='Choose a focus rating before saving.';return}
 if(!S.timer.running&&!S.timer.paused){close();toast('This session was already saved.');return}
 snapshot();
 const entry=crCommitTimerSession(skip?'Unrated':rating,skip?'':val('cx-recall'),$$('input[name="cx-topic-tag"]:checked').map(x=>x.value));
 const t=S.timer;t.running=false;t.paused=false;t.elapsed=0;t.studyElapsed=0;t.phase='study';t.activeStudyStart=null;
 save();close();updateHome();render();
 toast(entry?'Session saved once to this demo notebook.':'Nothing to log yet.',true);
}
function takeBreak()'''
add(old,new)
# Close study interval *before* starting a break; record no break time.
old="t.phase='break';t.elapsed=0;t.stamp=Date.now();"
new='''if(!Array.isArray(t.studyIntervals))t.studyIntervals=[];
 const crEnd=Date.now(),crStart=t.activeStudyStart||crEnd-Math.max(0,t.studyElapsed-(t.lastStudyElapsed||0))*1000;
 if(crEnd>crStart)t.studyIntervals.push({start:crStart,end:crEnd});
 t.lastStudyElapsed=t.studyElapsed;t.activeStudyStart=null;
 t.phase='break';t.elapsed=0;t.stamp=crEnd;'''
add(old,new)
# The resumed study segment has its own timestamp, not the elapsed break anchor.
old="t.phase='study';t.elapsed=t.studyElapsed||0;t.stamp=Date.now();"
new="t.phase='study';t.elapsed=t.studyElapsed||0;t.activeStudyStart=Date.now();t.stamp=t.activeStudyStart;"
add(old,new)
# Saving a prior running session on Start uses the exact same idempotent adapter.
old="if((S.timer.running||S.timer.paused)&&elapsed()>0)S.entries.push({id:'prior-'+Date.now(),date:dkey(new Date()),subject:S.timer.activity,title:S.timer.intent||S.timer.activity,min:Math.max(1,Math.round((S.timer.phase==='break'?S.timer.studyElapsed||0:elapsed())/60)),...jointContext()});"
new="if((S.timer.running||S.timer.paused))crCommitTimerSession('Unrated','Saved on starting another session',[]);"
add(old,new)
old="studyElapsed:0});applyJointContext();save();close();updateHome();render();toast('Session started.');break}"
new="studyElapsed:0,sessionId:crypto.randomUUID(),startedAt:Date.now(),activeStudyStart:Date.now(),studyIntervals:[],lastStudyElapsed:0});applyJointContext();save();close();updateHome();render();toast('Session started.');break}"
add(old,new)
pfile.write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n')
print('Timer interval and idempotent-commit patches written; total patches',len(patches))
