from pathlib import Path
import json
root=Path(__file__).resolve().parent
pfile=root/'inline-patches.json';patches=json.loads(pfile.read_text('utf8'))
original=(root/'Lemma_UI_Final.html').read_text('utf8')
anchor=' window.__lemmaSessionStore=Object.freeze({init,get,commit,subscribe});'
assert original.count(anchor)==1
assert not any(anchor in item['old'] for item in patches)
code=(root/'domain/effort-metrics.js').read_text('utf8')
patches.append({'old':anchor,'new':'\n'+code+'\n'+anchor})
# The integration is an adapter: the same read-only selector consumes the
# existing native Calendar entries and the shell's timer snapshot.
mod=root/'modules/53__index-DcUkykC4.js'
s=mod.read_text('utf8')
old='''  const entries = (Array.isArray(state.entries) ? state.entries : []).filter(
    (x) => x.date === today && Number.isFinite(Number(x.min ?? x.minutes)),
  );
  const logged = entries.reduce(
    (n, x) => n + Math.max(0, Number(x.min ?? x.minutes) || 0),
    0,
  );
  const focusInProgress = (timer.running || timer.paused) && timer.phase!==`break`
    ? Math.max(0,(Number(timer.elapsed)||0)+(timer.running?Math.max(0,now-(Number(timer.stamp)||now))/1000:0))/60
    : 0;'''
new='''  const effort = window.__lemmaEffortMetrics?.forDay?.(state.entries,timer,today,now);
  const entries = (Array.isArray(state.entries) ? state.entries : []).filter(
    (x) => x.date === today && Number.isFinite(Number(x.min ?? x.minutes)),
  );
  const logged = effort?.committedMinutes ?? entries.reduce(
    (n, x) => n + Math.max(0, Number(x.min ?? x.minutes) || 0),0);
  const focusInProgress = effort?.inProgressMinutes ?? 0;'''
assert s.count(old)==1,s.count(old)
s=s.replace(old,new)
old='''  const loggedHours = new Set(
    entries
      .filter((x) => /^\\d\\d:\\d\\d$/.test(x.start || ""))
      .map((x) => Number(x.start.slice(0, 2))),
  );'''
new='''  const loggedHours = new Set(effort?.loggedHours ?? entries
    .filter((x) => /^\\d\\d:\\d\\d$/.test(x.start || ""))
    .map((x) => Number(x.start.slice(0, 2))));'''
assert s.count(old)==1,s.count(old)
s=s.replace(old,new)
mod.write_text(s,'utf8')
for item in patches:
 if 'All-time study log' in item['new']:
  old='const total=Math.round(records.reduce((n,e)=>n+(Number(e.min)||0),0));'
  new='const total=Math.round(window.__lemmaEffortMetrics?.allTime?.(records)?.committedMinutes??records.reduce((n,e)=>n+(Number(e.min)||0),0));'
  assert item['new'].count(old)==1
  item['new']=item['new'].replace(old,new)
  break
else:raise Exception('Time Log patch missing')
pfile.write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n','utf8')
print('W01 effort selector integrated into Today ribbon, Today totals, and Time Log all-time total')
