from pathlib import Path
import json
P=Path(__file__).parent
base=Path('/mnt/data/Lemma_UI_Final.html').read_text()
patches=json.loads((P/'inline-patches.json').read_text())
def patch(old,new):
 assert base.count(old)==1,(old[:100],base.count(old))
 patches.append({'old':old,'new':new});print('calendar:',old[:66].replace('\n',' '))
# Date identity is NEVER the selected date and never hardcoded to a static fixture.
patch("${dkey(d)==='2026-11-01'?'now':''}","${dkey(d)===dkey(new Date())?'now':''}")
patch("${dkey(d)==='2026-11-01'?'today':''}","${dkey(d)===dkey(new Date())?'today':''} ${dkey(d)===dkey(date)?'selected':''}")
patch('aria-label="Open ${d.toLocaleDateString(\'en\')}"','aria-label="Open ${d.toLocaleDateString(\'en\')}${dkey(d)===dkey(new Date())?\', today\':\'\'}${dkey(d)===dkey(date)?\', selected\':\'\'}, ${bs.length} blocks"')
# Derive union occupancy and half-open interval conflicts instead of clamping 24 h.
patch('const crTime=m=>String(Math.floor(m/60)%24).padStart(2,\'0\')+\':\'+String(m%60).padStart(2,\'0\');','''const crTime=m=>String(Math.floor(m/60)%24).padStart(2,'0')+':'+String(m%60).padStart(2,'0');
function crDayWorkload(day){
 const seen=new Set(),ranges=blocksForDay(day,true).filter(b=>{
  const key=b.id+':'+b.at+':'+b.min;
  if(seen.has(key))return false;
  seen.add(key);return Number.isFinite(+b.min)&&b.min>0;
 }).map(b=>({b,start:Math.max(0,crClockMin(b.at)),end:Math.min(1440,crClockMin(b.at)+b.min)})).filter(x=>x.end>x.start).sort((a,b)=>a.start-b.start||a.end-b.end);
 let sum=0,occupied=0,lastEnd=0;
 for(const x of ranges){sum+=x.end-x.start;occupied+=Math.max(0,x.end-Math.max(x.start,lastEnd));lastEnd=Math.max(lastEnd,x.end)}
 const conflicts=[];for(let i=0;i<ranges.length;i++)for(let j=i+1;j<ranges.length&&ranges[j].start<ranges[i].end;j++){
  const a=ranges[i],b=ranges[j];if(a.start<b.end&&b.start<a.end)conflicts.push({a:a.b,b:b.b,start:Math.max(a.start,b.start),end:Math.min(a.end,b.end)});
 }
 const affected=new Set(conflicts.flatMap(x=>[x.a.id,x.b.id]));
 return {sum,occupied,conflicts,affected:affected.size};
}''')
# Compact Week has seven-day native button overview + selected day spatial detail.
patch("let view=innerWidth<600?'agenda':'week',date=new Date(),planTab='calendar'", "let view=innerWidth<600?'agenda':'week',date=new Date(),fullWeek=false,planTab='calendar'")
patch(''' const days=Array.from({length:view==='day'?1:7},(_,i)=>new Date(+start+i*DAY));
 const firstMinute=''',''' const compactWeek=view==='week'&&innerWidth<600&&!fullWeek;
 const weekDays=Array.from({length:7},(_,i)=>new Date(start.getFullYear(),start.getMonth(),start.getDate()+i));
 const days=compactWeek?[new Date(date)]:Array.from({length:view==='day'?1:7},(_,i)=>new Date(start.getFullYear(),start.getMonth(),start.getDate()+i));
 const firstMinute=''')
patch(''' return `<div class="cr-grid-scroller" data-view="${view}" tabindex="0"''',''' const weekStrip=compactWeek?`<div class="cr-week-overview" role="group" aria-label="Select a day in this week">${weekDays.map(d=>`<button type="button" data-cx="week-select" data-id="${dkey(d)}" class="${dkey(d)===dkey(date)?'selected':''} ${dkey(d)===dkey(new Date())?'today':''}" aria-pressed="${dkey(d)===dkey(date)}" aria-label="${d.toLocaleDateString('en',{weekday:'long',day:'numeric',month:'short'})}, ${blocksForDay(dkey(d),true).length} blocks"><span>${d.toLocaleDateString('en',{weekday:'short'})}</span><b>${d.getDate()}</b><small>${blocksForDay(dkey(d),true).length}</small></button>`).join('')}<button type="button" class="cr-full-week-action" data-cx="full-week">Full week</button></div>`:'';
 return `${weekStrip}<div class="cr-grid-scroller" data-view="${view}" tabindex="0"''')
# Insert stable action handling before existing calendar view action.
patch("case'cal-view':view=id;render();break;","case'cal-view':view=id;fullWeek=false;render();break;\ncase'week-select':date=new Date(id+'T12:00');render();break;\ncase'full-week':fullWeek=true;render();break;\ncase'calendar-conflicts':{const info=crDayWorkload(dkey(date));modal('Overlapping blocks',`<div class=\"cx-stack\">${info.conflicts.length?info.conflicts.map(c=>`<p class=\"cx-sub\">${esc(c.a.title)} overlaps ${esc(c.b.title)} · ${crTime(c.start)}–${crTime(c.end)}</p>`).join(''):'<p>No overlaps for this day.</p>'}</div>`,btn('Close','close'));break}")
# Keep total durations honest; never mislabel as occupied or hide overlaps.
patch(''' const daily=blocksForDay(dkey(date),true),study=daily.filter(b=>!b.busy).reduce((n,b)=>n+b.min,0);
 const dateLabel=''', ''' const daily=blocksForDay(dkey(date),true),workload=crDayWorkload(dkey(date)),study=daily.filter(b=>!b.busy).reduce((n,b)=>n+b.min,0);
 const dateLabel=''')
patch('''<span>${duration(study)} scheduled · ${view==='month'?'Tap a day':'15-min snap'}</span>''', '''<span>${duration(workload.sum)} of blocks · ${duration(workload.occupied)} occupied${workload.conflicts.length?' · '+workload.affected+' conflicting blocks':''}${workload.conflicts.length?` <button type="button" data-cx="calendar-conflicts" class="cr-conflict-action">Review conflicts</button>`:''}</span>''')
# When no saved preference Week button works with seven-day overview. Shift no other tool.
patch('/* An editorial agenda, using Lemma\'s existing theme tokens. */','''/* Week overview belongs to the native calendar and shares its event model. */
.cr-week-overview{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:2px;margin:8px 0 12px}
.cr-week-overview button{min-width:0;min-height:48px;padding:5px 2px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;background:var(--cx-paper);color:var(--cx-ink);border:1px solid var(--cx-line);border-radius:4px;font-size:12px}
.cr-week-overview button.selected{border:2px solid var(--cx-ink);font-weight:700}
.cr-week-overview button.today b{text-decoration:underline;text-decoration-color:var(--cx-accent);text-decoration-thickness:2px;text-underline-offset:3px}
.cr-week-overview .cr-full-week-action{grid-column:1/-1;min-height:44px;flex-direction:row;font-size:14px}
.cr-conflict-action{min-height:44px;padding:6px 10px;border:1px solid var(--cx-line);border-radius:4px;text-decoration:underline;font-weight:600}
.cr-spatial-toolbar button,.cr-view-switch button{min-height:44px}
/* An editorial agenda, using Lemma's existing theme tokens. */''')
(P/'inline-patches.json').write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n')
print('total',len(patches),'patches')
