from pathlib import Path
import json
root=Path(__file__).resolve().parent
path=root/'inline-patches.json'; patches=json.loads(path.read_text())
entry=[p for p in patches if p['old']=='function finish(){']
assert len(entry)==1
s=entry[0]['new'];assert s.count('function crCommitTimerSession')==1
start=s.index(' const intervals=Array.isArray(t.studyIntervals)')
end=s.index(' const startEpoch=',start)
s=s[:start]+''' const intervals=Array.isArray(t.studyIntervals)?t.studyIntervals.map(x=>({...x})).filter(x=>Number.isFinite(x.start)&&Number.isFinite(x.end)&&x.end>x.start):[];
 const covered=intervals.reduce((sum,x)=>sum+(x.end-x.start)/1000,0);
 const pending=Math.max(0,seconds-covered);
 let approximate=false;
 if(t.phase==='study'&&pending>0.5){
  // A paused clock does not advance during the pause. Use the end of its last
  // running segment, not the later moment at which the user opens Finish.
  const stopAt=t.running?now:Math.min(now,(Number(t.stamp)||now)+Math.max(0,(Number(t.elapsed)||0)-(Number(t.studyElapsed)||0))*1000);
  const anchor=Number(t.activeStudyStart)||Number(t.startedAt)||0;
  const supported=anchor>0&&Math.abs((stopAt-anchor)/1000-pending)<2;
  if(!supported)approximate=true;
  const since=supported?anchor:stopAt-pending*1000;
  if(since<stopAt)intervals.push({start:since,end:stopAt});
 }
 // Old timer snapshots may preserve a duration without usable segment anchors.
 if(!intervals.length){approximate=true;intervals.push({start:now-seconds*1000,end:now});}
''' + s[end:]
s=s.replace('const start=new Date(startEpoch),finish=new Date(now);','const start=new Date(startEpoch),finish=new Date(Math.max(...intervals.map(x=>x.end)));')
s=s.replace('  startInstant:start.toISOString(),endInstant:finish.toISOString(),','  startInstant:start.toISOString(),endInstant:finish.toISOString(),committedAt:new Date(now).toISOString(),')
s=s.replace('  timeApproximate:approximate,...jointContext(t),topics};','  timeApproximate:approximate,...jointContext(t),topics};')
entry[0]['new']=s
path.write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n')
print('Updated focus log interval inference and paused-time handling')
