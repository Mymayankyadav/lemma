// Source-level interaction checks. These do not substitute for real browser/device QA.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const moduleRoot=path.join(root,'modules');
const source=name=>fs.readFileSync(path.join(moduleRoot,name),'utf8');
const index=source('53__index-DcUkykC4.js');
const results=[];
function test(name,fn){fn();results.push({name,status:'passed'});console.log('PASS',name)}
function extract(text,name){const start=text.indexOf(`function ${name}(`);assert(start>=0,name);let end=text.indexOf('\nfunction ',start+10);const exp=text.indexOf('\nexport ',start+10);if(end<0||exp>=0&&exp<end)end=exp;return text.slice(start,end<0?undefined:end)}
const jsx=(type,props,key)=>({type,props:props||{},key});
const runtime={jsx,jsxs:jsx,Fragment:'Fragment'};
function hooks(){let cursor=0;const values=[],effects=[];return {begin(){cursor=0;effects.length=0},values,effects,
 useState(initial){const i=cursor++;if(!(i in values))values[i]=typeof initial==='function'?initial():initial;return[values[i],value=>values[i]=typeof value==='function'?value(values[i]):value]},
 useMemo:fn=>fn(),useCallback:fn=>fn,useRef:initial=>({current:initial}),useId:()=>`test-id`,useEffect:fn=>effects.push(fn)}}
function walk(node,predicate,out=[]){if(!node||typeof node!=='object')return out;if(Array.isArray(node)){for(const child of node)walk(child,predicate,out);return out}if(predicate(node))out.push(node);walk(node.props?.children,predicate,out);return out}
function text(node){if(node==null||node===false)return '';if(Array.isArray(node))return node.map(text).join(' ');if(typeof node!=='object')return String(node);return [node.props?.source||'',text(node.props?.children)].join(' ')}
function one(node,predicate){const found=walk(node,predicate);assert.equal(found.length,1);return found[0]}
function storage(){const values=new Map();return {getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,String(value)),removeItem:key=>values.delete(key)}}
const estimator=source('55__insights-DjL4G0LE.js').match(/function s\(e,t=\[\]\)\{.*?\}\s*\/\/ W01/s)[0].replace(/\/\/ W01$/,'');
const common={console,Date,Math,Number,String,JSON,Set,Map,URLSearchParams,Intl,Event,localStorage:storage(),sessionStorage:storage(),requestAnimationFrame:fn=>{fn();return 1},cancelAnimationFrame(){},setInterval(){},clearInterval(){},setTimeout(){},clearTimeout(){},location:{hash:'#/'}};
const context=vm.createContext({...common,window:{}});
vm.runInContext(estimator+'\nglobalThis.estimate=s;',context);
const estimate=context.estimate;

// All static imports and named exports must still connect across the packed app.
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
const modules=new Map(manifest.imports.map(item=>[item.id,new vm.SourceTextModule(source(item.filename),{identifier:item.id})]));
for(const [id,module] of modules)if(module.status==='unlinked')await module.link(specifier=>{assert(modules.has(specifier),`${id}: ${specifier}`);return modules.get(specifier)});
test('All 78 embedded module import/export contracts link',()=>assert.equal(modules.size,78));

vm.runInContext(extract(index,'selectTodayAction')+'\nglobalThis.choose=selectTodayAction;',context);
const choose=context.choose;
const project={slug:'analysis',title:'Real Analysis',status:'active',current:{code:'CP4',title:'Compactness'},subject:{glyph:'∫'}};
const resume={projectTitle:'Real Analysis',checkpointTitle:'Compactness',step:1,stepsTotal:4,glyph:'∫'};
const home={projects:[project],resume,due:4000,pendingProposals:600};
test('Today prioritizes running and paused sessions over resumable work',()=>{
 assert.equal(choose(home,{running:true},{count:33}).kind,'focus');
 assert.equal(choose(home,{paused:true},{count:33}).kind,'focus');
});
test('Today selects resume, review, checkpoint and empty states in order',()=>{
 assert.equal(choose(home,{}, {count:33}).kind,'resume');
 assert.equal(choose({...home,resume:null},{},{count:33}).kind,'review');
 assert.equal(choose({...home,resume:null,due:0},{},{count:0}).kind,'checkpoint');
 assert.equal(choose({projects:[],due:0},{},{count:0}).kind,'empty');
});
test('Paused/archived/system paths are excluded from the current learning action',()=>{
 assert.equal(choose({projects:[{...project,status:'paused'}],due:0},{},{count:0}).kind,'paths');
 assert.equal(choose({projects:[{...project,status:'archived'},{...project,system:true}],due:0},{},{count:0}).kind,'empty');
});
test('An empty selected batch does not recommend an empty review session',()=>{
 assert.equal(choose({...home,resume:null},{},{count:0}).kind,'checkpoint');
 assert.equal(choose({...home,resume:null},{},{count:null}).kind,'review');
});
function renderToday({data=home,timer={},count=33}={}){
 const hook=hooks(),calls=[],events=[],copied=[];
 const window={__carrelIntegration:{getState:()=>({timer,entries:[]}),open:(...args)=>calls.push(args)},dispatchEvent:event=>events.push(event.type)};
 const ctx=vm.createContext({...common,window,k:hook,A:runtime,_e:'Link',Xr:'MathText',CrCalendarGlyph:'CalendarIcon',Et:'ReviewIcon',vt:'PathsIcon',ut:'Chevron',
  useLemmaBatch:()=>({count,budget:33}),en:()=>({data:{reviews:[]}}),lemmaEstimateMinutes:estimate,ie:()=>`demo`,br:title=>`Resume ${title}`});
 vm.runInContext(extract(index,'selectTodayAction')+'\n'+extract(index,'LemmaTodayStudy')+'\nglobalThis.render=LemmaTodayStudy;',ctx);
 hook.begin();const tree=ctx.render({home:data,onCopy:prompt=>copied.push(prompt)});
 return{tree,calls,events,copied};
}
test('Today renders one primary action and omits cumulative due/proposal totals',()=>{
 const {tree}=renderToday();
 assert.equal(walk(tree,node=>node.props.className==='notebook-primary').length,1);
 assert(!text(tree).includes('4,000'));assert(!text(tree).includes('600'));
 assert(text(tree).includes('Step 2 of 4'));
 assert(walk(tree,node=>node.props.className==='notebook-task-row').length<=2);
});
test('The tutor action copies once and explains the external paste step',()=>{
 const r=renderToday();one(r.tree,node=>node.props.className==='notebook-primary').props.onClick();
 assert.deepEqual(r.copied,['Resume Real Analysis']);assert(text(r.tree).includes('Paste into your tutor'));
});
test('Focus actions open existing focus and only resume when paused',()=>{
 const running=renderToday({timer:{running:true,activity:'Topology'}});
 one(running.tree,n=>n.props.className==='notebook-primary').props.onClick();
 assert.deepEqual(running.events,['lemma:focus-open']);assert.equal(running.calls.length,0);
 const paused=renderToday({timer:{paused:true,activity:'Topology'}});
 one(paused.tree,n=>n.props.className==='notebook-primary').props.onClick();
 assert.deepEqual(paused.calls,[['timer','resume']]);assert.deepEqual(paused.events,['lemma:focus-open']);
});
test('Review and checkpoint state actions preserve their real destinations',()=>{
 const review=renderToday({data:{...home,resume:null}});
 assert.equal(one(review.tree,n=>n.props.className==='notebook-primary').props.to,'/review');
 const cp=renderToday({data:{...home,resume:null,due:0},count:0});
 assert.equal(one(cp.tree,n=>n.props.className==='notebook-primary').props.to,'/p/analysis/cp/CP4');
});
test('Long mathematical titles are retained in full',()=>{
 const long='Compactness and a proof with precise hypotheses '.repeat(12);
 const {tree}=renderToday({data:{...home,resume:{...resume,checkpointTitle:long}}});
 assert(text(tree).includes(long));
});

// Execute the actual setup component with representative adapter results.
const reviewSource=source('12__Page-Bd_8EoE4.js');
const deck={key:'project:analysis',label:'Real Analysis',due:4000,children:[]};
const items=Array.from({length:4000},(_,id)=>({id,projectSlug:'analysis',sessionNumber:null,state:{state:2}}));
const hook=hooks(),reviewCalls=[],reviewEvents=[],ls=storage();
const query=data=>({data,isPending:false,isLoading:false,isError:false,error:null,refetch(){}});
const reviewContext=vm.createContext({...common,localStorage:ls,w:hook,E:runtime,m:()=>runtime,n:'Page',t:'EmptyState',s:'Chevron',ne:'Chevron',a:'IconLink',i:'SubjectMark',u:'Surface',y:'Button',o:'Heading',l:'Skeleton',f:'Search',g:'Clock',_:'Play',C:'Shuffle',ce:'Switch',b:'Checkbox',le:'Chip',LemmaSheet:'Sheet',LemmaReviewSessionOptions:'TimerOptions',LemmaReviewOutlook:'ReviewOutlook',
 window:{dispatchEvent:event=>reviewEvents.push(event.type)},
 oe:()=>route=>reviewCalls.push(route),d:()=>()=>{},re:()=>query([deck]),te:()=>query({}),r:()=>query({mixDecks:true,reviewsPerDay:200}),ee:()=>query(items),ie:()=>query({reviews:[]}),h:()=>query([]),c:()=>({isPending:false,mutate(){}}),
 D:{},lemmaEstimateMinutes:estimate,x:{getState:()=>({initialize:(...args)=>reviewCalls.push(args)})}});
vm.runInContext([extract(reviewSource,'T'),extract(reviewSource,'ue'),extract(reviewSource,'de'),extract(reviewSource,'LemmaReviewDeckRow'),extract(reviewSource,'O')].join('\n')+'\nglobalThis.render=O;',reviewContext);
const reviewRender=()=>{hook.begin();return reviewContext.render()};
let reviewTree=reviewRender();
test('Review leads with today’s 33-card/14-minute session',()=>{
 const summary=one(reviewTree,n=>n.props.className==='notebook-review-summary');
 assert(text(summary).includes('33 cards'));assert(text(summary).includes('14 min'));assert(!text(summary).includes('4,000'));
 assert.equal(one(reviewTree,n=>n.props['aria-label']==='Start review').props.disabled,false);
});
test('Changing the batch uses a dismissible sheet and persists the choice',()=>{
 one(reviewTree,n=>n.type==='button'&&text(n).trim()==='Change').props.onClick();reviewTree=reviewRender();
 let sheet=one(reviewTree,n=>n.type==='Sheet'&&n.props.title==='Today’s review batch');assert.equal(sheet.props.open,true);
 one(sheet,n=>n.type==='button'&&text(n).includes('50 cards')).props.onClick();reviewTree=reviewRender();
 assert.equal(ls.getItem('lemma.review.batch'),'50');
 assert(text(one(reviewTree,n=>n.props.className==='notebook-review-summary')).includes('50 cards'));
 sheet=one(reviewTree,n=>n.type==='Sheet'&&n.props.title==='Today’s review batch');assert.equal(sheet.props.open,false);
 assert(reviewEvents.includes('lemma:review-selection'));
});
test('Deck options, full queue and explicit catch-up assumptions remain reachable',()=>{
 one(reviewTree,n=>n.props.className==='notebook-options-row').props.onClick();reviewTree=reviewRender();
 assert.equal(one(reviewTree,n=>n.type==='Sheet'&&n.props.title==='Decks & options').props.open,true);
 const queue=one(reviewTree,n=>n.props.className==='notebook-queue-details');
 assert(text(queue).includes('4,000 due across all decks'));assert(text(queue).includes('no new due cards'));
 const outlook=one(queue,n=>n.props.className==='notebook-review-outlook');outlook.props.onToggle({currentTarget:{open:true}});reviewTree=reviewRender();assert.equal(walk(reviewTree,n=>n.type==='ReviewOutlook').length,1);
});
test('Starting review initializes the selected batch and enters focused review',()=>{
 one(reviewTree,n=>n.props['aria-label']==='Start review').props.onClick();
 assert.equal(reviewCalls[0][0].length,50);assert.equal(reviewCalls.at(-1),'/review/run');
});

// Geometry is supplied, not rendered: check the reveal behavior without claiming device QA.
const answerSource=source('15__Page-Cajg06h3.js');
const effects=[],focusCalls=[];
const answer={getBoundingClientRect:()=>({top:1000}),focus:options=>focusCalls.push(options),scrollIntoView(){}};
const reader={scrollTop:300,scrollHeight:1800,clientHeight:400,querySelector:()=>answer,getBoundingClientRect:()=>({top:100}),focus(){}};
const answerContext=vm.createContext({...common,F:{useRef:()=>({current:reader}),useState:()=>[0,()=>{}],useEffect:fn=>effects.push(fn)},I:runtime,w:'Card',C:'MathText',T:'Chip',l:{div:'div'},p:'Book'});
vm.runInContext(extract(answerSource,'Se')+'\nglobalThis.render=Se;',answerContext);
test('A revealed long card scrolls only its reader and focuses the answer',()=>{
 const tree=answerContext.render({item:{front:'A long mathematical question. '.repeat(40),back:'Complete answer',type:'basic'},revealed:true,quiet:true});
 effects.pop()();assert.equal(reader.scrollTop,1188);assert.equal(focusCalls.length,1);assert.equal(focusCalls[0].preventScroll,true);
 one(tree,n=>n.props.className==='notebook-revisit-question').props.onClick();assert.equal(reader.scrollTop,0);
});
test('A new, unrevealed card starts at the question',()=>{
 reader.scrollTop=700;answerContext.render({item:{front:'Question',back:'Answer',type:'basic'},revealed:false,quiet:true});effects.pop()();assert.equal(reader.scrollTop,0);
});

// Large totals must retain their actual value, rather than a visual-segment cap.
test('Continuous rails retain exact high-volume counts',()=>{
 const code=source('30__SegmentBar-DKTUmcZ2.js').replace(/^import[^\n]+\n/,'').replace(/export \{[^}]+\};/,'');
 const ctx=vm.createContext({runtime:()=>runtime});vm.runInContext(code+'\nglobalThis.render=ProgressRail;',ctx);
 const tree=ctx.render({total:100,done:63});assert.equal(tree.props['aria-valuemax'],100);assert.equal(tree.props['aria-valuenow'],63);assert.equal(tree.props.children.props.style.width,'63%');
});
test('Project stage picker keeps all stages accessible without a long stack of headings',()=>{
 const stages=Array.from({length:20},(_,index)=>({key:`stage-${index}`,name:`Stage ${index+1}`,start:index*5,end:index*5+4}));
 const hook=hooks(),ctx=vm.createContext({...common,K:hook,Y:runtime,De:()=>stages,U:()=>7,J:()=>({rows:[]}),V:()=>query({}),C:'Heading',Ae:'Stage',lemmaPlainText:value=>value});
 vm.runInContext(extract(source('19__Page-DfokWqaX.js'),'je')+'\nglobalThis.render=je;',ctx);
 const render=()=>{hook.begin();return ctx.render({detail:{project:{slug:'analysis'},checkpoints:[],total:100}})};
 let tree=render();assert.equal(walk(tree,n=>n.type==='Stage').length,1);
 assert.equal(walk(one(tree,n=>n.type==='select'),n=>n.type==='option').length,21);
 one(tree,n=>n.type==='select').props.onChange({target:{value:'19'}});tree=render();
 assert.equal(one(tree,n=>n.type==='Stage').props.stage.key,'stage-19');
 assert.equal(one(tree,n=>n.type==='Stage').props.open,true);assert.equal(one(tree,n=>n.type==='Stage').props.onToggle,undefined);
 assert(text(tree).includes('All 20 stages'));
});
const progressSource=source('22__Page-Dw2lC2HF.js'),progressHook=hooks();
const progressData={minutes:125,sessions:4,reviews:100,recall:.86,recallBuckets:[{date:'2026-11-01',endDate:'2026-11-04',count:100,recall:.86}],reviewBuckets:[{date:'2026-11-01',endDate:'2026-11-04',again:14,hard:10,good:60,easy:16}],checkpointWeeks:[{date:'2026-11-01',endDate:'2026-11-04',demonstrated:2,rechecked:1}],calibration:[],subjects:[{subject:{id:'analysis',name:'Analysis'},minutes:100},{subject:{id:'algebra',name:'Algebra'},minutes:25}],typicalSession:30};
const progressContext=vm.createContext({...common,E:progressHook,O:runtime,n:()=>runtime,p:()=>query({}),a:()=>query({desiredRetention:.9}),h:()=>progressData,
 g:value=>Number(value).toLocaleString(),_:value=>`${value} min`,P:value=>value===null?'—':`${Math.round(value*100)}%`,lemmaMode:()=>`demo`,cPlain:value=>value,
 v:'Segmented',c:'Heading',u:'Surface',k:'RecallChart',w:'RatingChart',N:'ConfidenceChart',T:'CheckpointChart',M:'Concept',j:'Subjects',LemmaNativeRhythm:'Rhythm',NotebookMenu:'NotebookMenu'});
vm.runInContext(extract(progressSource,'D')+'\n'+extract(progressSource,'lemmaDate')+'\n'+extract(progressSource,'lemmaPeriod')+'\n'+extract(progressSource,'F')+'\nglobalThis.render=F;',progressContext);
const renderProgress=()=>{progressHook.begin();return progressContext.render()};let progressTree=renderProgress();
test('Progress Overview exposes four dated summaries and one recall chart',()=>{
 assert.equal(walk(progressTree,n=>n.props.className==='notebook-metric').length,4);
 assert.equal(walk(progressTree,n=>n.type==='RecallChart').length,1);
 assert.equal(walk(progressTree,n=>n.type==='RatingChart').length,0);
 assert(text(progressTree).includes('100 responses in range'));
});
test('Range and subject choices persist when switching Progress views',()=>{
 one(progressTree,n=>n.props['aria-label']==='Time range').props.onChange({target:{value:'90'}});
 one(progressTree,n=>n.props.label==='Progress view').props.onChange('time');progressTree=renderProgress();
 one(progressTree,n=>n.type==='select'&&n.props['aria-label']==='Time subject').props.onChange({target:{value:'algebra'}});progressTree=renderProgress();
 assert.equal(one(progressTree,n=>n.type==='Subjects').props.data.length,1);
 assert.equal(one(progressTree,n=>n.type==='Subjects').props.data[0].subject.id,'algebra');
 one(progressTree,n=>n.props.label==='Progress view').props.onChange('learning');progressTree=renderProgress();
 assert.equal(one(progressTree,n=>n.props['aria-label']==='Time range').props.value,'90');
 assert.equal(walk(progressTree,n=>n.type==='RatingChart').length,1);
 assert.equal(walk(progressTree,n=>n.type==='ConfidenceChart').length,1);
 one(progressTree,n=>n.props.label==='Progress view').props.onChange('time');progressTree=renderProgress();
 assert.equal(one(progressTree,n=>n.type==='select'&&n.props['aria-label']==='Time subject').props.value,'algebra');
});

const calendarSource=fs.readFileSync(path.join(root,'owners/lemma-native-calendar-runtime.js'),'utf8');
const clockDate=new Date(2026,10,4,16,0),FixedDate=class extends Date{constructor(...args){super(...(args.length?args:[clockDate.valueOf()]))}static now(){return clockDate.valueOf()}};
const calendarBlocks=[{id:'old',title:'Earlier theorem',subject:'Analysis',at:'09:00',min:60,actual:true},{id:'next',title:'Quotient topology',subject:'Topology',at:'20:00',min:50}];
const calContext=vm.createContext({...common,Date:FixedDate,date:clockDate,view:'agenda',planTab:'calendar',S:{tasks:[{done:false}],deadlines:[]},
 dkey:d=>d.toISOString().slice(0,10),blocksForDay:()=>calendarBlocks,crClockMin:at=>Number(at.slice(0,2))*60+Number(at.slice(3)),crClockLabel:value=>value,
 endLabel:b=>`${String(Number(b.at.slice(0,2))+1).padStart(2,'0')}:${b.at.slice(3)}`,crStatus:b=>b.actual?'logged':'planned',crStatusText:{logged:'Logged',planned:'Planned'},duration:value=>`${value} min`,esc:value=>String(value),
 crDayWorkload:()=>({occupied:110,sum:110,planned:50,logged:60,busy:0,conflicts:[],dayMinutes:1440}),daysUntil:()=>3,
 btn:(label,action,cls='')=>`<button data-cx="${action}" class="${cls}">${label}</button>`,ib:(name,action,label)=>`<button data-cx="${action}">${label}</button>`,icon:()=>'',crSpatialGrid:()=>'',crEventDetails:()=>'',monthCalendar:()=>''});
vm.runInContext(extract(calendarSource,'agenda')+'\n'+extract(calendarSource,'crPlanner')+'\nglobalThis.agendaHTML=agenda;globalThis.plannerHTML=crPlanner;',calContext);
test('Agenda collapses completed earlier blocks while retaining tap-to-edit',()=>{
 const html=calContext.agendaHTML();assert(html.indexOf('Quotient topology')<html.indexOf('<details'));
 assert(html.indexOf('Earlier theorem')>html.indexOf('<details'));assert(html.includes('data-cx="block-details"'));
});
test('Calendar leads with schedule, one four-view tablist and Planning tools',()=>{
 const html=calContext.plannerHTML();assert.equal((html.match(/role="tablist"/g)||[]).length,1);
 for(const view of ['agenda','day','week','month'])assert(html.includes(`data-id="${view}"`));
 assert(html.indexOf('Study agenda')<html.indexOf('Day details'));assert(html.includes('Planning tools'));assert(!html.includes('Backlog ·'));
});
test('Native calendar selection is not intercepted by delegated button clicks',()=>{
 const start=calendarSource.indexOf("document.addEventListener('click',e=>{const el=e.target.closest('[data-cx]')");assert(start>=0);
 const end=calendarSource.indexOf('},true);',start),handlerCode=calendarSource.slice(start,end+1).replace("document.addEventListener('click',",'');
 const calls=[],ctx=vm.createContext({action:(...args)=>calls.push(args)}),handler=vm.runInContext(`(${handlerCode})`,ctx);
 let prevented=false;
 const event={target:{closest:()=>({matches:selector=>selector.includes('select'),dataset:{cx:'calendar-view-select'}})},preventDefault(){prevented=true},stopPropagation(){}};
 handler(event);assert.equal(prevented,false);assert.equal(calls.length,0);
 event.target.closest=()=>({matches:()=>false,dataset:{cx:'new-block'}});handler(event);assert.equal(prevented,true);assert.equal(calls[0][0],'new-block');
});

const report={checkedAt:new Date().toISOString(),scope:'Source interaction and module contract checks; no browser/device execution',cases:results};
const reportPath=path.resolve(root,'../validation/mobile-redesign/source-interactions.json');fs.mkdirSync(path.dirname(reportPath),{recursive:true});fs.writeFileSync(reportPath,JSON.stringify(report,null,2));
console.log(`\n${results.length} source checks passed. Browser, phone and human usability checks remain unverified.`);
