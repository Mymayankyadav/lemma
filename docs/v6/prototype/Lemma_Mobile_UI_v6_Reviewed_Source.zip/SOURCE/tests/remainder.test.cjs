/* Execute the remaining audit paths; these tests do not measure browser layout. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const h=require('./audit-state.test.cjs');
const {context,window,notebook,store,integration,cal,flush,advance,hooks,walk,runtime,read,extract}=h;
const results=[];
async function test(name,fn){await fn();results.push({name,passed:true});console.log('PASS '+name)}
const plain=value=>JSON.parse(JSON.stringify(value));
function method(source,name){
 const start=source.indexOf('async '+name+'(');assert(start>=0,name);
 const body=source.indexOf('{',start);let depth=0,quote='',escaped=false;
 for(let i=body;i<source.length;i++){
  const c=source[i];if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote='';continue}
  if(c==='"'||c==="'"||c==='`'){quote=c;continue}
  if(c==='{')depth++;else if(c==='}'&&!--depth)return source.slice(start,i+1);
 }
 throw Error('Unclosed API method '+name);
}
async function main(){
 await test('Unavailable, busy and logged blocks cannot replace an active focus session',()=>{
  integration.open('timer','start');advance(3*60000);flush();
  notebook.commit({...notebook.getState(),blocks:[{id:'busy-rem',date:'2026-11-04',at:'21:00',min:30,busy:true}]});flush();
  const before=plain(store.get()),entries=notebook.getState().entries.length;
  for(const blockId of ['missing','busy-rem'])integration.open('timer','start-block',{blockId});
  const logged=notebook.getState().blocks.find(block=>block.actual);assert(logged);integration.open('timer','start-block',{blockId:logged.id});flush();
  assert.deepEqual(plain(store.get()),before);assert.equal(notebook.getState().entries.length,entries);
 });
 await test('Today starts the next block in Focus with its intent, duration and tags, preserving prior effort',()=>{
  const index=read('modules/53__index-DcUkykC4.js'),todayHooks=hooks();
  const day=vm.runInContext('new Date().toISOString().slice(0,10)',context);
  const block={id:'next-rem',date:day,at:'23:45',min:35,title:'Prove the quotient criterion',subject:'Topology',projectId:'topology',checkpointId:'CP2',pomo:'35/7'};
  notebook.commit({...notebook.getState(),blocks:[...notebook.getState().blocks,block]});flush();
  Object.assign(context,{k:todayHooks,_e:'Link',Xr:'MathText',CrCalendarGlyph:'Calendar',Et:'Review',vt:'Paths',ut:'Chevron',useLemmaBatch:()=>({count:0,budget:33}),en:()=>({data:{reviews:[]}}),lemmaEstimateMinutes:()=>14,ie:()=>`demo`,br:()=>`Resume`});
  vm.runInContext(extract(index,'selectTodayAction')+'\n'+extract(index,'LemmaTodayStudy')+'\nglobalThis.remainderToday=LemmaTodayStudy;',context);
  todayHooks.begin();const tree=context.remainderToday({home:{projects:[],due:0,pendingProposals:0},onCopy(){}});todayHooks.commit();
  const button=walk(tree,node=>node.props.className==='lemma-next-block-start')[0];assert(button);assert.equal(button.type,'button');assert.equal(button.props.to,undefined);
  const before=notebook.getState().entries.length;let opens=0;const onOpen=()=>opens++;window.addEventListener('lemma:focus-open',onOpen);
  button.props.onClick();flush();window.removeEventListener('lemma:focus-open',onOpen);
  const timer=store.get();assert.equal(timer.intent,block.title);assert.equal(timer.activity,'Topology');assert.equal(timer.projectId,'topology');assert.equal(timer.checkpointId,'CP2');assert.equal(timer.blockId,block.id);assert.equal(timer.focus,35);assert.equal(timer.short,7);assert.equal(timer.running,true);assert.equal(opens,1);assert.equal(notebook.getState().entries.length,before+1);
 });
 await test('Calendar Start uses the same block owner and respects open-timer blocks',()=>{
  integration.open('timer','discard',{commit:true});flush();
  notebook.commit({...notebook.getState(),blocks:[...notebook.getState().blocks,{id:'open-rem',date:'2026-11-04',at:'23:00',min:200,title:'Read a long proof',subject:'Unlinked subject',pomo:'Off'}]});flush();cal.reload();
  cal.action('block-start',{dataset:{id:'open-rem'}});flush();const timer=store.get();assert.equal(timer.blockId,'open-rem');assert.equal(timer.intent,'Read a long proof');assert.equal(timer.mode,'open');assert.equal(timer.checkpointId,null);assert.equal(timer.projectId,null);
 });
 await test('Day capacity partitions overlapping logged, busy and planned time without double counting',()=>{
  integration.open('timer','discard',{commit:true});flush();
  const entry={id:'partition-rem',date:'2026-11-04',subject:'Topology',title:'Logged proof',start:'09:00',end:'10:00',min:60};
  notebook.commit({...notebook.getState(),entries:[entry],blocks:[{id:'partition-busy',date:entry.date,at:'09:30',min:60,busy:true,title:'Class'},{id:'partition-plan',date:entry.date,at:'10:00',min:60,title:'Study',subject:'Algebra'}]});flush();cal.reload();
  const workload=cal.workload(entry.date);assert.equal(workload.occupied,120);assert.deepEqual(plain(workload.distribution),{logged:60,busy:30,planned:30});assert.equal(Object.values(workload.distribution).reduce((a,b)=>a+b,0),workload.occupied);assert(workload.occupied<=workload.dayMinutes);
 });
 await test('Session outcome summary reads evidence outcomes and preserves every event on its timeline',()=>{
  const ctx=vm.createContext({B:runtime}),source=read('modules/11__Page-BEFT4dQw.js');
  vm.runInContext(extract(source,'lemmaSessionEventKind')+'\n'+extract(source,'LemmaSessionOutcome')+'\nglobalThis.render=LemmaSessionOutcome;',ctx);
  const events=[{id:1,kind:'evidence',outcome:'demonstrated'},{id:2,kind:'evidence',outcome:'partial'},{id:3,kind:'recheck',outcome:'passed'},{id:4,kind:'recheck',outcome:'failed'},{id:5,kind:'misconception'},{id:6,kind:'attempt'}];
  const tree=ctx.render({events}),caption=walk(tree,n=>n.type==='figcaption')[0].props.children;
  assert.equal(caption,'6 recorded events · 1 demonstrated · 1 partial · 1 rechecked · 2 to revisit');assert.equal(walk(tree,n=>n.type==='rect').length,6);assert.equal(walk(tree,n=>n.type==='title').length,6);assert(walk(tree,n=>n.type==='svg')[0].props['aria-label'].includes(caption));
 });
 await test('Deck selection and expansion are separate controls with an explicit due label',()=>{
  const ctx=vm.createContext({E:runtime,b:'Checkbox',i:'SubjectGlyph',ne:'Collapse',s:'Expand'});vm.runInContext(extract(read('modules/12__Page-Bd_8EoE4.js'),'LemmaReviewDeckRow')+'\nglobalThis.render=LemmaReviewDeckRow;',ctx);
  let selected=0,expanded=0;const tree=ctx.render({deck:{label:'Topology',due:67,glyph:'τ'},checked:false,onChange:()=>selected++,expanded:false,onExpand:()=>expanded++});
  const checkbox=walk(tree,n=>n.type==='Checkbox')[0],expand=walk(tree,n=>n.type==='button')[0];assert(checkbox.props.label);assert(walk(checkbox.props.label,n=>n.props.children==='67 due').length);assert.equal(expand.props['aria-label'],'Expand Topology');assert.equal(walk(checkbox.props.label,n=>n.type==='button').length,0);
  expand.props.onClick();assert.equal(expanded,1);assert.equal(selected,0);checkbox.props.onChange(true);assert.equal(selected,1);assert.equal(expanded,1);
 });
 await test('Generic subject markers distinguish numbered subjects and preserve meaningful symbols',()=>{
  const ctx=vm.createContext({});vm.runInContext(extract(read('modules/53__index-DcUkykC4.js'),'lemmaSubjectGlyph')+'\nglobalThis.glyph=lemmaSubjectGlyph;',ctx);
  assert.equal(ctx.glyph({name:'Mathematics 60',glyph:'∑'}),'M60');assert.equal(ctx.glyph({name:'Mathematics 59',glyph:'∑'}),'M59');assert.equal(ctx.glyph({name:'Topology',glyph:'τ'}),'τ');assert.equal(ctx.glyph({name:'Number theory',glyph:'∑'}),'NT');assert.equal(ctx.glyph({name:'Unassigned'}),'?');
 });
 const apiSource=read('modules/49__data-HD2KrcdX.js');let subjectSerial=0;
 const apiContext=vm.createContext({K:plain,X:(s,min,max,label)=>{if(typeof s!=='string'||s.length<min||s.length>max)throw Error(label+' is invalid')},Z:(patch,allowed)=>{for(const key of Object.keys(patch))assert(allowed.includes(key))},q:message=>{throw Error(message)},J:message=>{throw Error(message)},crypto:{randomUUID:()=>`subject-rem-${++subjectSerial}`}});
 vm.runInContext('globalThis.subjectMethods={'+['listSubjects','createSubject','updateSubject','mergeSubjects'].map(name=>method(apiSource,name)).join(',')+'};',apiContext);
 const api={...apiContext.subjectMethods,store:{subjects:[{id:'s1',name:'Topology',glyph:'τ',hue:'slate',position:0},{id:'s2',name:'Algebra',glyph:'α',hue:'slate',position:1}],projects:[{id:'p1',subjectId:'s1'}],concepts:[{id:'c1',subjectId:'s1',slug:'shared'},{id:'c2',subjectId:'s2',slug:'shared'}]},transaction(fn){const before=plain(this.store);try{return fn()}catch(error){this.store=before;throw error}},subject(id){const s=this.store.subjects.find(s=>s.id===id);assert(s);return s},listProjects:async()=>[]};
 const subjectHooks=hooks(),feedback=[];
 const ctx=vm.createContext({F:subjectHooks,W:runtime,t:()=>({data:plain(api.store.subjects),isPending:false}),o:()=>({mutateAsync:({id,patch})=>api.updateSubject(id,patch)}),p:()=>({mutateAsync:({sourceId,targetId})=>api.mergeSubjects(sourceId,targetId)}),ee:()=>message=>feedback.push(message),useCreateSubject:()=>({isPending:false,mutateAsync:input=>api.createSubject(input)}),E:()=>`demo`,D:'Button',m:'Sheet',document:h.document,requestAnimationFrame:fn=>fn()});
 vm.runInContext(extract(read('modules/10__Page--IE2f0uU.js'),'he').split('\nvar J =')[0]+'\nglobalThis.render=he;',ctx);
 const render=()=>{subjectHooks.begin();const tree=ctx.render();subjectHooks.commit();return tree};
 const named=(tree,text)=>walk(tree,n=>n.props.children===text)[0];
 let tree=render();named(tree,'Manage').props.onClick();tree=render();named(tree,'Add subject').props.onClick();tree=render();
 await test('The actual subject form rejects blank/duplicate names, creates a subject and exposes it to task catalog queries',async()=>{
  const submit=()=>walk(tree,n=>n.type==='form')[0].props.onSubmit({preventDefault(){}});
  await submit();tree=render();assert.equal(api.store.subjects.length,2);assert.equal(walk(tree,n=>n.props.id==='lemma-new-subject-name')[0].props['aria-invalid'],true);
  walk(tree,n=>n.props.id==='lemma-new-subject-name')[0].props.onChange({target:{value:'Topology'}});tree=render();await submit();tree=render();assert.equal(api.store.subjects.length,2);assert(walk(tree,n=>n.props.id==='lemma-new-subject-error')[0].props.children.includes('already exists'));
  walk(tree,n=>n.props.id==='lemma-new-subject-name')[0].props.onChange({target:{value:'Number theory'}});tree=render();await submit();tree=render();assert.equal(api.store.subjects.length,3);assert.equal(api.store.subjects[2].glyph,'N');assert.equal(api.store.subjects[2].position,2);assert(feedback.includes('Subject added.'));assert.equal(walk(tree,n=>n.props['aria-label']==='Edit Number theory').length,2);
  notebook.commit({...notebook.getState(),entries:[],tasks:[]});flush();await notebook.configure({api});assert(notebook.subjects().includes('Number theory'));
 });
 await test('Filtered subject reordering uses the canonical order and merge retains linked projects and concepts',async()=>{
  const search=walk(tree,n=>n.type==='input'&&n.props.type==='search')[0];search.props.onChange({target:{value:'Number'}});tree=render();const move=walk(tree,n=>n.props['aria-label']==='Move Number theory up')[0];assert.equal(move.props.disabled,false);move.props.onClick();await new Promise(setImmediate);tree=render();assert.deepEqual((await api.listSubjects()).map(s=>s.name),['Topology','Number theory','Algebra']);
  await api.mergeSubjects('s1','s2');assert(!api.store.subjects.some(s=>s.id==='s1'));assert.equal(api.store.projects[0].subjectId,'s2');assert(api.store.concepts.every(c=>c.subjectId==='s2'));assert.equal(new Set(api.store.concepts.map(c=>c.slug)).size,2);
  await notebook.refreshCatalog();assert(!notebook.subjects().includes('Topology'));assert(notebook.subjects().includes('Algebra'));
 });
 await test('A failed catalog refresh retains the last successful subject list',async()=>{
  const before=notebook.subjects();await notebook.configure({api:{listProjects:async()=>{throw Error('offline')},listSubjects:async()=>{throw Error('offline')}}});assert.deepEqual(notebook.subjects(),before);
 });
 const report={checkedAt:new Date().toISOString(),scope:'Actual remaining-audit code paths executed with DOM/React test doubles; no browser geometry or live database writes.',cases:results};
 fs.writeFileSync(path.join(__dirname,'../../validation/audit/remaining-items.json'),JSON.stringify(report,null,2));console.log('\n'+results.length+' remaining-audit checks passed.');
}
const completion=main();module.exports={completion};completion.catch(error=>{console.error(error);process.exitCode=1});
