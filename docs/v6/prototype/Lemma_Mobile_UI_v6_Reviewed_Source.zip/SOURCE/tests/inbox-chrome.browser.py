"""Rendered regression for Inbox chrome. Run from the source root.

python SOURCE/tests/inbox-chrome.browser.py [optional-source-root]
Requires the existing Python Playwright package and Chromium. This test uses
only detached demo records, blocks external fonts/CDNs, and writes evidence
under validation/inbox-chrome/. It must fail against the original v6 HTML.
"""
import asyncio, functools, json, sys, threading
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from playwright.async_api import async_playwright

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[2] / 'validation/inbox-chrome'
OUT.mkdir(parents=True, exist_ok=True)

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=str(ROOT)))
threading.Thread(target=server.serve_forever, daemon=True).start()

GEOMETRY = '''() => {
 const rect=selector=>{const n=document.querySelector(selector);if(!n||getComputedStyle(n).display==='none')return null;const r=n.getBoundingClientRect();return {top:r.top,bottom:r.bottom,left:r.left,right:r.right,width:r.width,height:r.height,position:getComputedStyle(n).position,parent:n.parentElement.tagName}};
 return {nav:rect('nav[data-ui=main-navigation]'),dock:rect('#cr-mobile-dock'),actions:rect('[data-ui=proposal-actions]'),feedback:rect('#lemma-feedback .lemma-feedback'),width:innerWidth,height:innerHeight,documentWidth:document.documentElement.scrollWidth,buttons:[...document.querySelectorAll('[data-ui=proposal-actions]>button')].map(n=>{const r=n.getBoundingClientRect();return {width:r.width,height:r.height}})};
}'''

def overlaps(a,b):
    return min(a['right'],b['right'])-max(a['left'],b['left'])>1 and min(a['bottom'],b['bottom'])-max(a['top'],b['top'])>1

def check(g, landscape=False):
    a=g['actions']
    assert a and a['position']=='fixed' and a['parent']=='BODY', 'Inbox actions must be a viewport portal'
    assert a['top']>=-1 and a['bottom']<=g['height']+1 and a['left']>=-1 and a['right']<=g['width']+1, ('Actions outside viewport',g)
    assert g['documentWidth']<=g['width']+1, ('Document overflow',g)
    assert all(b['width']>=44 and b['height']>=44 for b in g['buttons']), ('Undersized decision target',g)
    assert len(g['buttons'])==3, 'Reject, Edit and Approve must remain available'
    if not landscape:
        assert g['nav'], 'Primary navigation missing from Inbox'
        assert g['nav']['bottom']<=g['height']+1, ('Navigation below viewport',g)
    for chrome in [g['nav'],g['dock']]:
        if chrome:
            assert not overlaps(a,chrome), ('Decision bar overlaps navigation/timer',g)
            assert abs(a['bottom']-min(x['top'] for x in [g['nav'],g['dock']] if x))<=2, ('Unreserved gap below actions',g)
    if g['feedback']:
        assert g['feedback']['top']>=0 and g['feedback']['bottom']<=a['top']-4, ('Feedback obscures actions',g)

async def load(context):
    page=await context.new_page()
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    await page.goto(f'http://127.0.0.1:{server.server_port}/Lemma_UI_Implemented.html',wait_until='domcontentloaded')
    await page.wait_for_selector('nav[data-ui=main-navigation]',state='attached',timeout=20000)
    await page.evaluate("location.hash='#/proposals'")
    await page.wait_for_function("document.querySelector('main h1')?.textContent.trim()==='Inbox' && document.querySelector('[data-ui=proposal-actions]')",timeout=20000)
    await page.wait_for_timeout(300)
    return page,errors

async def main():
    results=[]
    cases=[(320,640,16,'graph-night'),(360,640,16,'graph-night'),(390,763,16,'graph-night'),(390,844,16,'graph-night'),(390,844,16,'graph'),(390,844,32,'graph-night'),(390,844,32,'graph'),(844,390,16,'graph-night')]
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        for width,height,font,theme in cases:
            context=await browser.new_context(viewport={'width':width,'height':height},is_mobile=True,has_touch=True)
            for pattern in ['**/fonts.googleapis.com/**','**/fonts.gstatic.com/**','**/cdn.jsdelivr.net/**']:
                await context.route(pattern,lambda r:r.abort())
            page,errors=await load(context)
            await page.evaluate("([theme,font])=>{document.documentElement.dataset.theme=theme;document.documentElement.style.fontSize=font+'px'}",[theme,font])
            await page.wait_for_timeout(200)
            landscape=width>height
            initial=await page.evaluate(GEOMETRY)
            check(initial,landscape)
            if not landscape:
                nav=page.locator('nav[data-ui=main-navigation]')
                for name in ['Today','Paths','Review','Calendar','Progress']:
                    assert await nav.get_by_role('link',name=name,exact=True).is_visible(),name
                assert initial['dock'], 'Active focus accessory missing from Inbox'
            await page.evaluate('window.scrollTo(0,document.documentElement.scrollHeight)')
            await page.wait_for_timeout(200)
            scrolled=await page.evaluate(GEOMETRY)
            check(scrolled,landscape)
            await page.evaluate("window.__lemmaFeedback.show('Decision ready. You can still undo it.')")
            await page.wait_for_timeout(100)
            check(await page.evaluate(GEOMETRY),landscape)
            await page.evaluate('window.__lemmaFeedback.dismiss()')
            label=f'{width}x{height}-{font}px-{theme}'
            await page.screenshot(path=str(OUT/f'{label}.png'))
            if (width,height,font,theme)==(390,844,16,'graph-night'):
                await page.get_by_role('button',name='Pause session',exact=True).click()
                await page.get_by_role('button',name='Resume session',exact=True).wait_for()
                check(await page.evaluate(GEOMETRY))
                await page.get_by_role('button',name='Edit card',exact=True).click()
                await page.locator('dialog[open]').wait_for()
                await page.keyboard.press('Escape')
                await page.wait_for_timeout(200)
                check(await page.evaluate(GEOMETRY))
                await page.set_viewport_size({'width':390,'height':640})
                await page.wait_for_timeout(200)
                check(await page.evaluate(GEOMETRY))
                await page.set_viewport_size({'width':390,'height':844})
                await page.evaluate("() => {const store=window.__lemmaSessionStore;const timer=store.get();store.commit({...timer,running:false,paused:false},'inbox-browser-regression',timer.rev)}")
                await page.wait_for_function("!document.querySelector('#cr-mobile-dock')")
                await page.wait_for_timeout(200)
                inactive=await page.evaluate(GEOMETRY)
                check(inactive)
                assert inactive['dock'] is None, 'Inactive timer must not reserve an empty accessory'
                await page.locator('nav[data-ui=main-navigation]').get_by_role('link',name='Paths',exact=True).click()
                await page.wait_for_function("location.hash==='#/projects' && !document.querySelector('[data-ui=proposal-actions]')")
                await page.go_back()
                await page.wait_for_selector('[data-ui=proposal-actions]')
                await page.wait_for_timeout(200)
                check(await page.evaluate(GEOMETRY))
            assert not errors,errors
            results.append({'case':label,'status':'passed','initial':initial,'scrolled':scrolled})
            print('PASS',label,flush=True)
            await context.close()
        await browser.close()
    (OUT/'results.json').write_text(json.dumps({'cases':results,'externalFonts':'blocked; fallback fonts','physicalDeviceQA':'not performed'},indent=2))
    print(f'Passed {len(results)} rendered Inbox cases plus pause/edit/return/resize/inactive-timer checks.',flush=True)

try:
    asyncio.run(main())
finally:
    server.shutdown()
