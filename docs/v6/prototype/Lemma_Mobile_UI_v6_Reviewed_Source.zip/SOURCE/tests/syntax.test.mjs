import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const errors=[];let files=0,inline=0;
for(const folder of ['modules','owners','domain'])for(const name of fs.readdirSync(path.join(root,folder)).filter(n=>n.endsWith('.js'))){
 const filename=path.join(root,folder,name),source=fs.readFileSync(filename,'utf8');files++;
 try{if(folder==='modules')new vm.SourceTextModule(source,{identifier:filename});else new vm.Script(source,{filename})}catch(error){errors.push({file:folder+'/'+name,error:error.message})}
}
const html=fs.readFileSync(path.join(root,'../Lemma_UI_Implemented.html'),'utf8');
for(const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)){
 const type=match[1].match(/type=["']([^"']+)["']/)?.[1]||'';
 if(type&&!['module','text/javascript','application/javascript'].includes(type))continue;
 const name=match[1].match(/id=["']([^"']+)["']/)?.[1]||`inline-${inline+1}`;inline++;
 try{if(type==='module')new vm.SourceTextModule(match[2],{identifier:name});else new vm.Script(match[2],{filename:name})}catch(error){errors.push({file:name,error:error.message})}
}
const report={scope:'Syntax only: every embedded module, editable owner/domain script and executable HTML script',files,executableInlineScripts:inline,errors};
fs.writeFileSync(path.join(root,'../validation/mobile-redesign/syntax.json'),JSON.stringify(report,null,2));
assert.equal(errors.length,0,JSON.stringify(errors));console.log(`PASS ${files} JavaScript source files and ${inline} executable HTML scripts parsed.`);
