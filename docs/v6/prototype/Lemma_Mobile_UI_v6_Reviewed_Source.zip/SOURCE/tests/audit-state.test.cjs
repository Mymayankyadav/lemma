/* Execute the shipped state owners in a DOM test double. No browser or layout claims. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
const results=[];function test(name,fn){fn();results.push({name,passed:true});console.log('PASS '+name)}
let clock=+new Date(2026,10,4,18,0),serial=0;const advance=ms=>clock+=ms;
class FixedDate extends Date{constructor(...args){super(...(args.length?args:[clock]))}static now(){return clock}}
const microtasks=[],timers=new Map(),events=[];
class El extends EventTarget{
 constructor(tag='div'){super();this.tagName=tag.toUpperCase();this.children=[];this.parentElement=null;this.dataset={};this.style={setProperty(){},getPropertyValue(){return ''}};this.attributes={};this.className='';this.value='';this.textContent='';this.isConnected=true;this.classList={add(){},remove(){},toggle(){return false},contains(){return false}}}
 setAttribute(k,v){this.attributes[k]=String(v)}getAttribute(k){return this.attributes[k]??null}removeAttribute(k){delete this.attributes[k]}hasAttribute(k){return k in this.attributes}toggleAttribute(k,on){if(on)this.setAttribute(k,'');else this.removeAttribute(k)}
 append(...nodes){for(const n of nodes){if(n.parentElement)n.parentElement.children=n.parentElement.children.filter(c=>c!==n);this.children.push(n);n.parentElement=this}}replaceChildren(...nodes){for(const c of this.children)c.parentElement=null;this.children=[];this.append(...nodes)}remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(c=>c!==this);this.parentElement=null}
 contains(node){return this===node||this.children.some(c=>c.contains(node))}focus(){this.focused=true}scrollIntoView(){this.scrolled=true}matches(){return false}querySelector(){return null}querySelectorAll(){return []}
}
const body=new El('body'),html=new El('html'),fields=new Map(),config=new El('script');config.textContent='{"variant":"audit"}';
const all=(node,out=[])=>{out.push(node);for(const c of node.children)all(c,out);return out};
const document=Object.assign(new EventTarget(),{body,documentElement:html,readyState:'complete',activeElement:null,createElement:tag=>new El(tag),getElementById:id=>all(body).find(n=>n.id===id)||fields.get('#'+id)||null,querySelector:selector=>selector==='#carrel-addition-config'?config:selector==='#lemma-feedback [data-interacting=true]'?all(body).find(n=>n.dataset.interacting==='true')||null:fields.get(selector)||null,querySelectorAll:()=>[]});
const window=new EventTarget();const baseDispatch=window.dispatchEvent.bind(window);window.dispatchEvent=event=>{events.push(event.type);return baseDispatch(event)};window.window=window;window.innerWidth=390;window.scrollY=0;
const local=new Map(),session=new Map(),storage=map=>({getItem:key=>map.get(key)??null,setItem:(key,v)=>map.set(key,String(v)),removeItem:key=>map.delete(key)});
const context=vm.createContext({window,document,localStorage:storage(local),sessionStorage:storage(session),Date:FixedDate,Event,CustomEvent,EventTarget,URLSearchParams,Intl,console,queueMicrotask:fn=>microtasks.push(fn),setTimeout:(fn,ms)=>{const id=++serial;timers.set(id,{fn,at:clock+ms});return id},clearTimeout:id=>timers.delete(id),setInterval:()=>++serial,clearInterval(){},requestAnimationFrame:fn=>{fn();return 1},cancelAnimationFrame(){},MutationObserver:class{observe(){}disconnect(){}},ResizeObserver:class{observe(){}disconnect(){}},IntersectionObserver:class{observe(){}disconnect(){}},getComputedStyle:()=>({fontSize:'16px',getPropertyValue:()=>''}),location:{hash:'#/'},history:{state:null},PopStateEvent:Event,innerWidth:390,innerHeight:844,crypto:{randomUUID:()=>`audit-${++serial}`},HTMLElement:class{},customElements:{define(){}}});
function flush(){for(let i=0;microtasks.length;i++){assert(i<250,'notification feedback loop');microtasks.shift()()}}
const build=fs.readFileSync(path.join(root,'../Lemma_UI_Implemented.html'),'utf8');
const sessionScript=build.match(/<script id="lemma-session-store">([\s\S]*?)<\/script>/)?.[1];assert(sessionScript,'repack before running audit tests');vm.runInContext(sessionScript,context);
const notebook=window.__lemmaNotebook,metrics=window.__lemmaEffortMetrics,store=window.__lemmaSessionStore;
const clean=notebook.getState();Object.assign(clean,{entries:[],blocks:[],tasks:[],topics:[],deadlines:[],parked:[],timer:{running:false,paused:false,phase:'study',activity:'Topology',elapsed:0,stamp:clock,mode:'pomo',focus:50,short:10,long:20,every:4,cycle:1},settings:{...clean.settings,daily:240,gap:10,planStart:'09:00',planEnd:'23:00'}});notebook.commit(clean);store.init(clean.timer);flush();
vm.runInContext(read('owners/carrel-added-behaviour.js'),context);const integration=window.__carrelIntegration;
test('Canonical reads are immutable and stale notebook revisions cannot overwrite changes',()=>{
 const old=notebook.getState(),next=notebook.getState();next.tasks.push({id:'original',title:'Original task',subject:'Topology',min:25,done:false});notebook.commit(next);old.tasks=[];notebook.commit(old);assert.equal(notebook.getState().tasks.length,1);assert.notEqual(notebook.getState(),notebook.getState());flush();
});
test('Focus start, pause and break retain only study time',()=>{
 integration.open('timer','start');advance(17*60000);integration.open('timer','pause');flush();assert.equal(store.get().elapsed,17*60);assert.equal(store.get().paused,true);integration.open('timer','break');advance(9*60000);flush();assert.equal(metrics.active(store.get()),17);
});
test('Finish requests reflection before any commit, then logs edited minutes, rating and note once',()=>{
 integration.open('timer','finish');assert.equal(notebook.getState().entries.length,0);assert(events.includes('lemma:finish-request'));
 integration.open('timer','finish',{commit:true,minutes:19,rating:'Deep',note:'Quotient-map criterion proved.'});flush();
 const state=notebook.getState();assert.equal(state.entries.length,1);assert.equal(state.entries[0].min,19);assert.equal(state.entries[0].focus,'Deep');assert.equal(state.entries[0].note,'Quotient-map criterion proved.');assert.equal(store.get().running,false);assert.equal(store.get().paused,false);assert.equal(metrics.forDay(state.entries,state.timer,'2026-11-04').committedMinutes,19);assert.equal(notebook.selectTime(1,clock).minutes,19);
 integration.open('timer','finish',{commit:true,minutes:19});flush();assert.equal(notebook.getState().entries.length,1);
});
test('Calendar logged blocks derive from the same saved intervals',()=>{
 const state=notebook.getState();assert.equal(state.blocks.filter(b=>b.actual).length,1);assert.equal(state.blocks.find(b=>b.actual).min,19);assert.equal(state.blocks.find(b=>b.actual).entryId,state.entries[0].id);
});
test('Discard clears the active session without adding saved effort',()=>{
 integration.open('timer','start');advance(3*60000);integration.open('timer','discard',{commit:true});flush();assert.equal(notebook.getState().entries.length,1);assert.equal(store.get().running,false);assert.equal(metrics.active(store.get()),0);
});
test('Overlapping and duplicate records cannot inflate daily or range time',()=>{
 const a={id:'overlap-a',date:'2026-11-04',subject:'Topology',start:'09:00',end:'10:00',min:60},b={...a,id:'overlap-b',subject:'Algebra',start:'09:30',end:'10:30'};
 const total=metrics.forDay([a,a,b],null,'2026-11-04');assert.equal(total.committedMinutes,90);assert.equal(total.overlapMinutes,30);assert.equal(total.needsReview,true);assert.equal(metrics.forRange([a,a,b],1,clock).committedMinutes,90);
 const state=notebook.getState();notebook.commit({...state,entries:[a,b]});const selected=notebook.selectTime(1,clock);assert.equal(selected.subjects.reduce((n,s)=>n+s.minutes,0),selected.minutes);flush();
});
test('Impossible saved durations are flagged and never rendered as thousands of hours',()=>{
 const bad={id:'bad',date:'2026-11-04',min:1e8};const result=metrics.forRange([bad],30,clock);assert.equal(result.committedMinutes,0);assert.equal(result.invalidRecords,1);assert.equal(result.needsReview,true);
});
test('Cross-midnight intervals are assigned to their actual calendar days',()=>{
 const row={id:'night',intervals:[{start:new Date(2026,10,3,23,40).toISOString(),end:new Date(2026,10,4,0,20).toISOString()}]};assert.equal(metrics.forDay([row],null,'2026-11-03').committedMinutes,20);assert.equal(metrics.forDay([row],null,'2026-11-04').committedMinutes,20);
});
// Run the actual scoped Calendar owner, bypassing only its rendering/lifecycle.
let calendar=read('owners/lemma-native-calendar-runtime.js').replace('__LEMMA_CALENDAR_CSS__',"''");
calendar=calendar.replace("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();",`window.__auditCalendar={action,getState:()=>S,reload:()=>{S=nativeWin.__lemmaNotebook.getState()},setDate:key=>{date=new Date(key+'T12:00')},workload:crDayWorkload,preview:crPlanningPreview,suggestions:crSuggestedTasks,freeSlots:crFreeSlots,backward:crBackwardPlan,ritual,shutdown,taskEditor,entryEditor,backlog,grid:crSpatialBlocks,rendered:0,revealed:[]};render=()=>{window.__auditCalendar.rendered++};close=()=>{};modal=(title,body,footer)=>{window.__auditCalendar.sheet={title,body,footer}};crRevealItem=(id,kind='task')=>window.__auditCalendar.revealed.push({kind,id});`);
calendar=calendar.replace(' class LemmaNativeCalendar extends HTMLElement {',' globalThis.auditRunCalendar=runCalendar;\n class LemmaNativeCalendar extends HTMLElement {');
vm.runInContext(calendar,context);context.auditRunCalendar({document,window,parent:{postMessage(){}},setTimeout:context.setTimeout,clearTimeout:context.clearTimeout,setInterval:()=>1,clearInterval(){}});const cal=window.__auditCalendar;
const field=(id,value,attrs={})=>{const e=new El('input');e.id=id;e.value=String(value);Object.assign(e,attrs);fields.set('#'+id,e);return e};
function form(selector,dataset){const e=new El('div');e.dataset=dataset;fields.set(selector,e);return e}
function run(action,id){cal.action(action,{dataset:{id}});flush()}
test('Calendar and Progress use the same logged-today selector',()=>{
 cal.reload();assert.equal(cal.workload('2026-11-04').logged,notebook.selectTime(1,clock).minutes);
});
test('New task rejects blank titles and nonfinite estimates with focus and field errors',()=>{
 form('[data-task-id]',{taskId:''});const title=field('cx-task-title',''),estimate=field('cx-task-min','Infinity');field('cx-task-checkpoint','');field('cx-task-title-error','');field('cx-task-min-error','');field('cx-task-checkpoint-error','');field('cx-task-subject','Topology');field('cx-task-project','');field('cx-task-due','');field('cx-task-priority','Normal');
 const before=notebook.getState().tasks.length;run('task-save');assert.equal(notebook.getState().tasks.length,before);assert.equal(title.getAttribute('aria-invalid'),'true');assert.equal(estimate.getAttribute('aria-invalid'),'true');assert.equal(title.focused,true);
});
let createdTask;
test('Saving a task inserts it first, reveals it and leaves a viewport-level Undo action',()=>{
 field('cx-task-title','Prove the quotient lemma');field('cx-task-min','25');run('task-save');createdTask=notebook.getState().tasks[0];assert.equal(createdTask.title,'Prove the quotient lemma');assert(cal.revealed.some(e=>e.id===createdTask.id));assert.equal(document.getElementById('lemma-feedback').parentElement,body);assert(all(body).some(e=>e.textContent==='Undo Calendar changes'));
});
test('Planner Undo preserves a focus record saved after the planner action',()=>{
 integration.open('timer','start');advance(4*60000);integration.open('timer','finish',{commit:true,minutes:4,rating:'Okay',note:''});flush();const logged=notebook.getState().entries.length;cal.reload();run('undo');assert(!notebook.getState().tasks.some(t=>t.id===createdTask.id));assert.equal(notebook.getState().entries.length,logged);assert.equal(store.get().running,false);
});
test('Planning is suggestion-first, unchecked, bounded and fits actual free time',()=>{
 const state=notebook.getState();notebook.commit({...state,entries:[],blocks:[{id:'busy',title:'Fixed',subject:'Study',date:'2026-11-04',at:'19:00',min:60,busy:true}],tasks:Array.from({length:283},(_,i)=>({id:'task-'+i,title:'Task '+i,subject:'Topology',min:25,priority:2,done:false})),ritualPicks:[]});flush();cal.reload();cal.setDate('2026-11-04');cal.ritual();assert.equal((cal.sheet.body.match(/name="cx-ritual-pick"/g)||[]).length,5);assert(!cal.sheet.body.includes('checked'));const preview=cal.preview();assert(preview.placed.length<=20);assert(preview.used<=240);assert.equal(preview.placed.length+preview.left,283);
 const intervals=preview.placed.map(b=>({start:Number(b.at.slice(0,2))*60+Number(b.at.slice(3)),end:Number(b.at.slice(0,2))*60+Number(b.at.slice(3))+b.min})).sort((a,b)=>a.start-b.start);for(let i=1;i<intervals.length;i++)assert(intervals[i].start>=intervals[i-1].end+10);for(const p of intervals)assert(p.end<=19*60||p.start>=20*60);
 cal.shutdown();assert(!/type="checkbox"[^>]*checked/.test(cal.sheet.body));assert(cal.sheet.body.length<25000);
});
test('Dense day-grid overlap clusters retain every block in named, bounded stack controls',()=>{
 const state=notebook.getState();const blocks=Array.from({length:15},(_,i)=>({id:'dense-'+i,title:'Dense '+i,date:'2026-11-04',at:i<8?'18:00':'20:00',min:50,subject:'Topology'}));notebook.commit({...state,blocks});flush();cal.reload();const html=cal.grid('2026-11-04');assert.equal((html.match(/class="lemma-event-stack"/g)||[]).length,2);for(const b of blocks)assert(html.includes(b.id));assert(!html.includes('class="cr-spatial-event'));
});
test('Editing metadata preserves recorded intervals; editing times replaces them',()=>{
 const row={id:'editable',date:'2026-11-04',subject:'Topology',title:'Proof',min:40,start:'09:00',end:'10:00',intervals:[{start:'2026-11-04T09:00:00Z',end:'2026-11-04T09:20:00Z'},{start:'2026-11-04T09:40:00Z',end:'2026-11-04T10:00:00Z'}]};notebook.commit({...notebook.getState(),entries:[row]});flush();cal.reload();form('[data-entry-id]',{entryId:row.id});field('cx-entry-title','Revised proof');field('cx-entry-date',row.date);field('cx-entry-start',row.start);field('cx-entry-end',row.end);field('cx-entry-subject','Topology');field('cx-entry-focus','Deep');field('cx-entry-note','One gap');field('cx-form-error','');run('entry-save');let saved=notebook.getState().entries[0];assert.equal(saved.min,40);assert.deepEqual(JSON.parse(JSON.stringify(saved.intervals)),row.intervals);field('cx-entry-start','0930');field('cx-entry-end','1030');run('entry-save');saved=notebook.getState().entries[0];assert.equal(saved.min,60);assert.equal(saved.intervals.length,1);assert.equal(saved.editedTimeRange,true);
});
test('Splitting a saved record partitions its intervals without duplicating study time',()=>{
 field('cx-split-min','20');field('cx-split-subject','Algebra');run('split-save','editable');const entries=notebook.getState().entries;assert.equal(entries.length,2);assert.equal(metrics.allTime(entries).committedMinutes,60);assert.equal(entries.reduce((n,e)=>n+e.min,0),60);assert.equal(metrics.allTime(entries).overlapMinutes,0);
});
test('Feedback keeps Undo while announcing a later save and does not auto-dismiss action messages',()=>{
 window.__lemmaFeedback.dismiss();let undone=0;window.__lemmaFeedback.show('Task removed',{action:{label:'Undo task',onClick:()=>undone++}});window.__lemmaFeedback.show('19 min logged to Topology.');const layer=document.getElementById('lemma-feedback');assert.equal(layer.parentElement,body);assert(all(layer).some(e=>e.textContent==='19 min logged to Topology.'));const undo=all(layer).find(e=>e.textContent==='Undo task');assert(undo);assert.equal([...timers.values()].filter(t=>t.fn.name==='dismiss').length,0);undo.dispatchEvent(new Event('click'));assert.equal(undone,1);
});
// Execute the real ledger, including timers and focus extension, with a mutation spy.
const proposal=read('modules/23__Page-RJ1UO7Rb.js'),ledgerCode=proposal.slice(proposal.indexOf('const lemmaDecisionLedger ='),proposal.indexOf('\nfunction F()',proposal.indexOf('const lemmaDecisionLedger =')));vm.runInContext(ledgerCode+'\nglobalThis.auditLedger=lemmaDecisionLedger;',context);const ledger=context.auditLedger;
test('Inbox stages independent decisions for at least 30 seconds and batch Undo cancels all pending sends',()=>{
 const calls=[];ledger.bind((entry,id)=>calls.push(id),()=>{});vm.runInContext("auditLedger.reconcile(new Set(['p1','p2']))",context);const one=ledger.stage({ids:['p1'],action:'approve',label:'Approve'});advance(10000);const two=ledger.stage({ids:['p2'],action:'reject',label:'Reject'});assert(one.deadline-one.createdAt>=30000);assert(two.deadline-two.createdAt>=30000);assert.equal(ledger.undoAll().length,2);assert.equal(ledger.snapshot().length,0);assert.equal(calls.length,0);
});
function extract(source,name){const start=source.indexOf('function '+name+'(');assert(start>=0,name);const end=source.indexOf('\nfunction ',start+10);return source.slice(start,end<0?undefined:end)}
const jsx=(type,props)=>({type,props:props||{}}),runtime={jsx,jsxs:jsx,Fragment:'Fragment'};
function walk(node,match,out=[]){if(!node||typeof node!=='object')return out;if(Array.isArray(node)){for(const child of node)walk(child,match,out);return out}if(match(node))out.push(node);walk(node.props?.children,match,out);return out}
function hooks(){let cursor=0;const slots=[],pending=[];return {begin(){cursor=0;pending.length=0},commit(){for(const fn of pending)fn()},useState(initial){const index=cursor++;if(!slots[index])slots[index]={value:typeof initial==='function'?initial():initial};return[slots[index].value,value=>slots[index].value=typeof value==='function'?value(slots[index].value):value]},useRef(initial){const index=cursor++;return slots[index]||(slots[index]={current:initial})},useEffect(fn,deps){const index=cursor++,prior=slots[index];if(!prior||!deps||deps.some((v,i)=>v!==prior.deps[i])){pending.push(()=>{prior?.cleanup?.();slots[index]={deps,cleanup:fn()}})}},useMemo:fn=>fn(),useCallback:fn=>fn,useId:()=>`audit-id`}}
const indexSource=read('modules/53__index-DcUkykC4.js'),focusHooks=hooks();Object.assign(context,{k:focusHooks,A:runtime,Le:()=>({createPortal:node=>node})});vm.runInContext(extract(indexSource,'LemmaFocusDialog')+'\nglobalThis.auditRenderFocus=LemmaFocusDialog;',context);
const renderFocus=()=>{focusHooks.begin();const tree=context.auditRenderFocus();focusHooks.commit();return tree};
test('The actual Focus dialog renders the reflection, validates duration, and saves through the shared owner',()=>{
 renderFocus();integration.open('timer','start');advance(7*60000);flush();integration.open('timer','finish');flush();let tree=renderFocus();assert.equal(tree.type,'dialog');assert.equal(walk(tree,n=>n.props.className==='lemma-finish-form').length,1);
 const input=walk(tree,n=>n.props.id==='lemma-finish-minutes')[0];assert.equal(input.props.value,7);input.props.onChange({target:{value:'Infinity'}});tree=renderFocus();walk(tree,n=>n.props.children==='Save study time')[0].props.onClick();tree=renderFocus();assert.equal(walk(tree,n=>n.props.id==='lemma-finish-minutes')[0].props['aria-invalid'],true);
 walk(tree,n=>n.props.id==='lemma-finish-minutes')[0].props.onChange({target:{value:'8'}});tree=renderFocus();const before=notebook.getState().entries.length;walk(tree,n=>n.props.children==='Save study time')[0].props.onClick();flush();assert.equal(notebook.getState().entries.length,before+1);assert.equal(store.get().paused,false);assert.equal(store.get().running,false);assert.equal(renderFocus(),null);
});
test('Today rerenders after Finish & log with no stale In focus state and the same day total',()=>{
 const todayHooks=hooks();Object.assign(context,{k:todayHooks,_e:'Link',Xr:'MathText',CrCalendarGlyph:'Calendar',Et:'Review',vt:'Paths',ut:'Chevron',useLemmaBatch:()=>({count:0,budget:33}),en:()=>({data:{reviews:[]}}),lemmaEstimateMinutes:()=>14,ie:()=>`demo`,br:()=>`Resume`});vm.runInContext(extract(indexSource,'selectTodayAction')+'\n'+extract(indexSource,'LemmaTodayStudy')+'\nglobalThis.auditRenderToday=LemmaTodayStudy;',context);
 const home={projects:[],due:0,pendingProposals:0},render=()=>{todayHooks.begin();const tree=context.auditRenderToday({home,onCopy(){}});todayHooks.commit();return tree};integration.open('timer','start');flush();let tree=render();assert.equal(walk(tree,n=>n.props['data-primary-state']==='focus').length,1);advance(2*60000);integration.open('timer','finish',{commit:true,minutes:2});flush();tree=render();assert.equal(walk(tree,n=>n.props['data-primary-state']==='focus').length,0);const total=metrics.forDay(notebook.getState().entries,null,'2026-11-04').committedMinutes;assert(walk(tree,n=>typeof n.props.children==='string'&&n.props.children===(total>=60?`${Math.floor(total/60)} h ${Math.round(total%60)} min logged today`:`${Math.round(total)} min logged today`)).length);
});
test('Settings autosave validates actual values and exposes clock/week preferences through the same owner',()=>{
 assert.equal(integration.updateCalendarSettings({daily:300,clock:'24h',week:'Monday'}),true);flush();assert.equal(integration.getState().settings.daily,300);assert.equal(integration.getCalendarSettings().daily,300);assert.equal(integration.updateCalendarSettings({daily:Infinity}),false);assert.equal(integration.getState().settings.daily,300);
});
test('Unplaced durations obey each day capacity even within a longer date range',()=>{
 const entries=Array.from({length:50},(_,index)=>({id:'unplaced-'+index,date:'2026-11-04',min:120}));const result=metrics.forRange(entries,30,clock);assert.equal(result.committedMinutes,(clock-metrics.dayBounds('2026-11-04').from)/60000);assert.equal(result.needsReview,true);
});
// Run the real paused-round store without evaluating the application entry module.
let reviewStore=read('modules/71__store-3lADaAh6.js').replace(/import\{[^;]+;/g,'').replace(/export\{[^;]+;/g,'');const reviewContext=vm.createContext({e:x=>x,t:()=>({}),n:()=>({queue:{},item:null}),r:()=>({learning:[],reviews:[],fresh:[],settings:{learnAheadMinutes:0}}),i:x=>x,Date:FixedDate,sessionStorage:storage(session)});vm.runInContext(reviewStore+'\nglobalThis.reviewStore=m;',reviewContext);const paused=reviewContext.reviewStore;
test('Review cannot mark an interrupted round complete, and paused state restores on refresh',()=>{
 paused.setState({current:{cardId:'remaining'},queue:{learning:[],reviews:[],fresh:[]},answers:[{rating:3,card:{cardId:'answered'}}],pausedRound:true});paused.getState().markCompleted();assert.equal(paused.getState().completedRound,false);const restored=JSON.parse(session.get('lemma.review.pausedRound'));assert.equal(restored.current.cardId,'remaining');assert.equal(restored.answers.length,1);assert.equal(restored.pausedRound,true);paused.setState({current:null});paused.getState().markCompleted();assert.equal(paused.getState().completedRound,true);
});
test('An Inbox undo deadline extends while feedback has focus',()=>{
 window.__lemmaFeedback.dismiss();window.__lemmaFeedback.show('Pending decisions',{action:{label:'Undo decisions',onClick:()=>ledger.undoAll()}});const row=ledger.stage({ids:['focused-proposal'],action:'approve',label:'Approve'});const timer=[...timers.values()].find(t=>t.at===row.deadline);assert(timer);document.getElementById('lemma-feedback').children[0].dispatchEvent(new Event('focusin'));advance(30001);timer.fn();assert(ledger.snapshot()[0].deadline>=clock+30000);ledger.undoAll();window.__lemmaFeedback.dismiss();
});
test('Saving an immediately finished session honors an edited one-minute duration',()=>{
 const before=notebook.getState().entries.length;integration.open('timer','start');integration.open('timer','finish',{commit:true,minutes:1});flush();assert.equal(notebook.getState().entries.length,before+1);assert.equal(notebook.getState().entries.at(-1).min,1);
});
test('The actual Cards page exposes 20 rows, progressive loading and one filter sheet',()=>{
 const cardHooks=hooks(),cards=Array.from({length:50},(_,i)=>({noteNo:i+1,front:'Question '+i,projectSlug:'topology',checkpointCode:'CP2',glyph:'τ',status:'active',openComments:0})),query={data:{pages:[{rows:cards}]},hasNextPage:false,isPending:false,isError:false};
 const ctx=vm.createContext({E:cardHooks,k:runtime,g:()=>({data:[{id:'topology',slug:'topology',title:'Topology',subject:{glyph:'τ'}}]}),v:()=>({mutateAsync(){}}),ee:()=>()=>{},r:()=>()=>{},T:()=>query,P:()=>`Due`,O:()=>true,m:()=>false,A:x=>x,te:'ProjectLabel',x:'Chip',b:'Button',u:'Page',f:'IconButton',h:'Plus',y:'Search',i:'Link',_:'Sheet',p:'Skeleton',ne:'Editor',S:'Math',M:92,N:6,location:{hash:'#/cards'},URLSearchParams,window,setTimeout:()=>0,clearTimeout(){},ResizeObserver:class{observe(){}disconnect(){}}});
 const source=read('modules/18__Page-DbdYWJ80.js');vm.runInContext(source.slice(source.indexOf('function F()'),source.lastIndexOf('\nexport '))+'\nglobalThis.render=F;',ctx);const render=()=>{cardHooks.begin();const tree=ctx.render();cardHooks.commit();return tree};let tree=render();assert.equal(walk(tree,n=>n.props['data-card-row']).length,20);assert.equal(walk(tree,n=>n.props['data-card-virtual-list']).length,0);assert.equal(walk(tree,n=>n.type==='Sheet'&&n.props.title==='Filter cards').length,1);walk(tree,n=>n.props.children==='Load 20 more')[0].props.onClick();tree=render();assert.equal(walk(tree,n=>n.props['data-card-row']).length,40);window.dispatchEvent(new Event('lemma:new-card'));tree=render();assert.equal(walk(tree,n=>n.type==='Sheet'&&n.props.title==='New card')[0].props.open,true);
});
const report={checkedAt:new Date().toISOString(),scope:'Actual shipped state owners executed in a VM with DOM test doubles. Browser rendering, geometry and physical devices are not verified.',cases:results};
fs.mkdirSync(path.join(root,'../validation/audit'),{recursive:true});fs.writeFileSync(path.join(root,'../validation/audit/state-transitions.json'),JSON.stringify(report,null,2));console.log('\n'+results.length+' state checks passed.');

module.exports={context,window,document,fields,notebook,metrics,store,integration,cal,field,form,run,flush,advance,hooks,walk,runtime,read,extract,El};
