"""Check CSS syntax and selected design-token contrast pairs, without a browser.

Requires tinycss2 (pip install tinycss2). This is not a rendered-page WCAG audit.
"""
from pathlib import Path
import json
import re
import tinycss2

ROOT = Path(__file__).resolve().parents[1]
report = {'scope': 'CSS parsing and design-token pair contrast; not rendered-page accessibility', 'css': [], 'contrast': []}

def check_rules(rules, errors):
    for rule in rules:
        if rule.type == 'error':
            errors.append(str(rule))
        elif rule.type == 'at-rule' and rule.lower_at_keyword in ('media', 'supports', 'layer', 'container') and rule.content:
            check_rules(tinycss2.parse_rule_list(rule.content), errors)
        elif rule.type == 'qualified-rule':
            for declaration in tinycss2.parse_declaration_list(rule.content):
                if declaration.type == 'error':
                    errors.append(str(declaration))

for source in [ROOT/'owners/design-system.css', ROOT/'styles/calendar.css']:
    errors = []
    check_rules(tinycss2.parse_stylesheet(source.read_text()), errors)
    report['css'].append({'file': str(source.relative_to(ROOT)), 'errors': errors})
    assert not errors, (source.name, errors)

css = (ROOT/'owners/design-system.css').read_text().split('/* Lemma mobile redesign · 2026-11-04.')[1]
def tokens(theme):
    values = {}
    for body in re.findall(r'html\[data-theme='+re.escape(theme)+r'\]\s*\{([^}]+)\}', css):
        values.update(re.findall(r'(--[\w-]+)\s*:\s*([^;]+)', body))
    return values

def color(token, values):
    value = values[token].strip()
    while value.startswith('var('):
        value = values[value[4:-1]].strip()
    assert re.fullmatch(r'#[0-9a-fA-F]{6}', value), (token, value)
    return [int(value[i:i+2],16)/255 for i in (1,3,5)]

def luminance(rgb):
    linear = [value/12.92 if value<=.04045 else ((value+.055)/1.055)**2.4 for value in rgb]
    return sum(value*weight for value,weight in zip(linear,[.2126,.7152,.0722]))

for theme in ['graph','graph-night']:
    values = tokens(theme)
    pairs = [(text,surface,4.5) for text in ['--ink','--ink-2','--ink-3','--ink-soft'] for surface in ['--bg','--paper','--paper-2']]
    pairs += [('--on-accent','--accent',4.5),('--accent','--paper',4.5)]
    pairs += [(tone,'--paper',4.5) for tone in ['--danger','--warn','--grade-good','--easy']]
    pairs += [('--control-edge','--paper',3),('--control-edge','--paper-2',3)]
    pairs += [(tone,'--paper',3) for tone in ['--chart-again','--chart-hard','--chart-good','--chart-easy']]
    for foreground, background, minimum in pairs:
        a,b=sorted([luminance(color(foreground,values)),luminance(color(background,values))])
        ratio=(b+.05)/(a+.05)
        report['contrast'].append({'theme':theme,'foreground':foreground,'background':background,'ratio':round(ratio,2),'minimum':minimum})
        assert ratio>=minimum, (theme,foreground,background,ratio)

target=ROOT.parent/'validation/mobile-redesign/styles.json'
target.write_text(json.dumps(report,indent=2))
print(f'PASS: 2 CSS stylesheets parsed; {len(report["contrast"])} selected token contrast pairs passed.')
