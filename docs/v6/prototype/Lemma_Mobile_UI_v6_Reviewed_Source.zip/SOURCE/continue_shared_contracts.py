"""Continue standalone audit remediation: shared review estimator and verified tuning eligibility.
Only edits unpacked copied module files in this work directory.
"""
from pathlib import Path
D=Path(__file__).resolve().parent/'modules'
def change(file,old,new):
 p=D/file;s=p.read_text();n=s.count(old)
 if n==0 and new in s:
  print('already applied',file,old[:50]);return
 if n!=1 and not (n==2 and 'Math.ceil((Number(localStorage.getItem' in old):raise AssertionError(f'{file}: expected 1 anchor, got {n}: {old[:110]}')
 p.write_text(s.replace(old,new,n));print('updated',file,old[:65])

# W01 one queue estimator; all consumers use one algorithm. Keep existing policy
# for real durations, and the existing conservative 25 s fallback when unavailable.
p='55__insights-DjL4G0LE.js'
change(p,'function c(e,t){', '''// W01: source-backed optimizer eligibility matches the worker's rule:
// usable *subsequent* card reviews separated by at least one local study day.
// Raw review totals are not optimizer-eligible training examples.
function eligibleReviews(records,settings={}){
  if(!Array.isArray(records))return {status:`unavailable`,eligible:null,total:null,excluded:null};
  const tz=settings.timeZone||Intl.DateTimeFormat().resolvedOptions().timeZone||`UTC`;
  const rollover=Number.isInteger(settings.rolloverHour)?settings.rolloverHour:4;
  let formatter;
  try{formatter=new Intl.DateTimeFormat(`en-GB`,{timeZone:tz,year:`numeric`,month:`2-digit`,day:`2-digit`,hour:`2-digit`,hourCycle:`h23`})}
  catch{return {status:`unavailable`,eligible:null,total:null,excluded:null}}
  function studyDay(value){
    const d=new Date(value);
    if(!Number.isFinite(d.getTime()))return null;
    const f=Object.fromEntries(formatter.formatToParts(d).map(x=>[x.type,x.value]));
    const day=Math.floor(Date.UTC(+f.year,+f.month-1,+f.day)/86400000);
    return day-(+f.hour<rollover?1:0);
  }
  const byCard=new Map();let valid=0;
  for(const record of records){
    if(!record||!record.cardId||!Number.isInteger(Number(record.rating))||+record.rating<1||+record.rating>4)continue;
    const day=studyDay(record.reviewedAt);if(day==null)continue;
    valid++;
    const arr=byCard.get(String(record.cardId))||[];
    arr.push({day,timestamp:Date.parse(record.reviewedAt)});
    byCard.set(String(record.cardId),arr);
  }
  let eligible=0;
  for(const card of byCard.values()){
    card.sort((a,b)=>a.timestamp-b.timestamp);
    for(let i=1;i<card.length;i++)if(card[i].day>card[i-1].day)eligible++;
  }
  return {status:`ready`,eligible,total:records.length,excluded:records.length-eligible,
    sameDayOrFirst:valid-eligible,invalid:records.length-valid,threshold:400,
    complete:true,timeZone:tz,rolloverHour:rollover};
}
function c(e,t){''')
change(p,'export{s as n,o as r,l as t};','export{s as n,o as r,l as t,eligibleReviews as eligibleForTuning};')

p='12__Page-Bd_8EoE4.js'
change(p,'import { t as x } from "@lemma/store-3lADaAh6.js";', 'import { t as x } from "@lemma/store-3lADaAh6.js";\nimport { n as lemmaEstimateMinutes } from "@lemma/insights-DjL4G0LE.js";')
change(p,'''  const [prefs, setPrefs] = (0, w.useState)(get);''','''  const [prefs, setPrefs] = (0, w.useState)(get);
  const reviewHistory = ie(30);''')
change(p,'Math.ceil((Number(localStorage.getItem("lemma.review.batch"))||33)*0.45)','lemmaEstimateMinutes(Number(localStorage.getItem("lemma.review.batch"))||33,reviewHistory.data?.reviews??[])')
# second identical anchor remains
change(p,'Math.ceil((Number(localStorage.getItem("lemma.review.batch"))||33)*0.45)','lemmaEstimateMinutes(Number(localStorage.getItem("lemma.review.batch"))||33,reviewHistory.data?.reviews??[])')
change(p,'    he = Math.ceil(J * 0.45),','    he = lemmaEstimateMinutes(J,fe.data?.reviews??[]),')
change(p,'[22,33,55,50,100,200].map(n=>(0,E.jsx)("option",{value:n,children:[22,33,55].includes(n)?`${Math.ceil(n*.45)} min · about ${n} cards`:`${n} cards · about ${Math.ceil(n*.45)} min`},n))','[22,33,55,50,100,200].map(n=>(0,E.jsx)("option",{value:n,children:`${n} cards · about ${lemmaEstimateMinutes(n,fe.data?.reviews??[])} min`},n))')

p='53__index-DcUkykC4.js'
change(p,'import { t as Pe } from "@lemma/Tex-kn8bVMsW.js";', 'import { t as Pe } from "@lemma/Tex-kn8bVMsW.js";\nimport { n as lemmaEstimateMinutes } from "@lemma/insights-DjL4G0LE.js";')
change(p,'const batch=Math.min(Number(localStorage.getItem("lemma.review.batch"))||33,Math.max(0,Number(e)||0)); const minutes=Math.ceil(batch*0.45);','const batch=Math.min(Number(localStorage.getItem("lemma.review.batch"))||33,Math.max(0,Number(e)||0)); const minutes=lemmaEstimateMinutes(batch);')

# W17: use exactly full getReviewLog fetch and count worker-eligible transitions;
# handle loading and error states without presenting 0 as a failed read.
p='10__Page--IE2f0uU.js'
change(p,'import { t as O } from "@lemma/Chip-AHlDYqiR.js";', 'import { t as O } from "@lemma/Chip-AHlDYqiR.js";\nimport { eligibleForTuning } from "@lemma/insights-DjL4G0LE.js";')
change(p,'''  let X = e.data,
    ye =''','''  const eligibility=(0,F.useMemo)(()=>p.isPending||p.isError
    ?{status:p.isError?`error`:`loading`,eligible:null,total:null,threshold:400}
    :eligibleForTuning(p.data,e.data||{}),
    [p.isPending,p.isError,p.data,e.data?.timeZone,e.data?.rolloverHour]);
  let X = e.data,
    ye =''')
change(p,'''      if (!X || !p.data || p.data.length < 400) return;''','''      if(!X||eligibility.status!==`ready`||eligibility.eligible<400)return;''')
change(p,'''                disabled: !p.data || p.data.length < 400,''','''                disabled: eligibility.status!==`ready`||eligibility.eligible<400,''')
change(p,'''              (p.data?.length ?? 0) < 400 &&
                (0, W.jsxs)(`p`, {
                  className: `mt-2 text-label text-ink-3`,
                  children: [
                    `Needs 400 reviews (you have `,
                    p.data?.length ?? 0,
                    `)`,
                  ],
                }),''','''              (0,W.jsxs)(`div`,{
                className:`mt-2 flex flex-col gap-2 text-label text-ink-2`,
                role:`status`,
                "aria-live":`polite`,
                children:[
                  eligibility.status===`loading`?`Checking review history…`:
                  eligibility.status===`error`?`Review history unavailable · Retry`:
                  eligibility.status!==`ready`?`Review eligibility cannot be verified`:
                    `${eligibility.eligible.toLocaleString()} eligible review intervals · ${eligibility.total.toLocaleString()} review records · requires 400 eligible`,
                  eligibility.status===`error`&&(0,W.jsx)(`button`,{
                    type:`button`,onClick:()=>void p.refetch(),
                    className:`self-start min-h-11 rounded-ctl border border-edge px-3 text-ink`,children:`Retry review history`,
                  }),
                  eligibility.status===`ready`&&(0,W.jsxs)(`details`,{
                    children:[(0,W.jsx)(`summary`,{className:`min-h-11 cursor-pointer font-medium`,children:`How eligibility is counted`}),
                      (0,W.jsx)(`p`,{className:`pb-2 text-ink-2`,children:
                        `${eligibility.sameDayOrFirst.toLocaleString()} first or same-study-day reviews and ${eligibility.invalid.toLocaleString()} invalid records are excluded. Eligible intervals are repeated reviews on separate study days in ${eligibility.timeZone}, with the saved ${eligibility.rolloverHour}:00 study-day rollover. History is fetched across all pages.`})],
                  })
                ],
              }),''')
Path=Path(__file__).resolve().parent
print('shared contracts continuation complete')
