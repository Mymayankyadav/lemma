> Historical record for the supplied intermediate build. Current implementation and acceptance status: `../IMPLEMENTATION_STATUS.md`. Current output: `../Lemma_UI_Implemented.html`.

# Lemma UI audit remediation — implementation and verification record

**Date:** 3 November 2026  
**Scope:** Detached, standalone demo HTML and editable unpacked application modules, **not a repository change**.  
**Status:** **Substantial, partial implementation** of the owner's W00–W19 plan. **Not full acceptance.**

## Deliverables and integrity

- Original immutable HTML: `Lemma_UI_Final.html`, SHA-256 `1afddf9c611ad3835e9fec043ca05f577149f34668a4529a7fbe58f6d9fc904b`.
- Updated standalone artifact: `Lemma_UI_Remediated.html`, SHA-256 `5c70f880f493a4a6ac02ce1e1efb2d0093aa83a7a6f898b62db5e16ceb7a1af5`.
- Editable build: `manifest.json`, 78 original-identifier `modules/`, `repack.py`, `inline-patches.json`, source-owner modification scripts and `evidence/` browser test scripts/screenshots. The repacker uses fixed gzip timestamps and preserves module identifiers.
- The generated HTML runs in **demo mockup mode**. Browser tests exercise local demo fixtures and do **not** validate Supabase synchronization or real-user account semantics.
- No GitHub repository, branch, pull request, Supabase project, or deployment was modified. No existing feature was intentionally removed. Native Calendar retains Agenda/Day/Week/Month; Review, Focus, Paths, Atlas, Inbox, Settings and the other tabs retain their entry points.

## Workstream progress

| Plan section | Changes delivered so far | Remaining / acceptance boundary |
| --- | --- | --- |
| **W00** Build infrastructure | Decode/repack all 78 modules; deterministic standalone output and import-manifest verification; owner edits applied in component modules rather than a new global CSS audit layer. | Original source-repository build was not used (repo changes forbidden); production build and test pipeline not verified. Fresh baseline unpack→pack→verify and current remediated byte-for-byte integrity both pass. |
| **W01** Metrics and shared state | Review distinguishes `due` from `remaining due`; improved locally formatted counts; Today clarifies `logged` vs `in progress`; calendar occupied-vs-summed durations separated; Insights range copy corrected. | **Open P0:** full account-scoped/provenance selectors, queued review selection and real user time-zone preference remain outstanding. A read-only selector now shares local saved and active study effort between Today and Time Log; identity-safe timer interval attribution passes focused fixtures. |
| **W02** Shell | Five bottom destinations remain in original order on browse/details. Utility **Menu** gives Atlas/Inbox/Settings access on non-Today browse routes. Calendar receives shared session dock. `ResizeObserver`-based shell reservation; corrected review badge location. | Full focus/inert/modal-focus return and text-scaled safe-area test suite incomplete. |
| **W03** Design roles | Targeted legibility, control borders, muted text, checkbox targets, route layout, tab states. No 19th global override layer. | Global CSS token de-duplication, complete Day/Night contrast and screen-reader audit still open. |
| **W04** Today | Logged and running effort labels corrected, sections and Copy retained, shell content remains accessible. | Continuous-track presentation, full planned-span marks, and all compact card targets remain open; the existing 24-hour ribbon now marks all hours touched by saved interval fragments. |
| **W05** Forecast | Seven true calendar-date bins (today plus six days), complete exact counts, top-four deck strip plus computed Other, sorted expandable all-deck list, 40px flat-state chart, explicit missing/error states and retained visual forecast. | Seven-day stressed fixture and 60-deck sum verified; differing time zones, stale/partial server responses and screen-reader interpretation still need coverage. |
| **W06** Review hub | First 8 of 60 decks shown with incremental paging, 44×44 native checkbox labels, no 20,000 px nested list; `remaining due` not mislabeled overdue; optional timer controls moved to an explicit disclosure. | Full keyboard and every deck filter/state combination not checked. |
| **W07** Review run | Answer reveal no longer jumps reading position; full long proof content and explicit More below/jump affordance remain. Confidence controls preserved. | Whole state-machine/focus/touch acceptance matrix incomplete. |
| **W08** Focus | `Back to notebook`, `Finish & log` action copy and clearer session continuity. | Both shell and native Calendar now use one saved `focus:` session identity, with break-separated intervals and duplicate-save protection in focused fixtures. Stale revision commits do not persist speculative shell entries. Backend exactly-once guarantees and broader cross-tab lifecycle remain open. |
| **W09** Paths | Subject groups retained even with one project, compact continuous rows, independent anchored action menu with Pin/Set active/Pause/Finish/Archive, explicit Close, clear already-active label, Previous/Next page and page-range counts. Repaired menu emerging off-screen under motion transforms. | Phone-specific bottom-sheet and focus trap not implemented. Height/keyboard matrix needs deeper checks. |
| **W10** Project | Explicit `Checkpoint pace`, separate `Goal forecast`, goal labels, `checkpoints/week`, current step details, three `Path / Sessions / Sources` tabs; source/session counts kept distinct. | 7-marker Route window and 15-stage/100-checkpoint navigation, deep-link tutor handoff and full focus attribution incomplete. |
| **W11** Sources + Sessions | Source search/type/status filters and accordion rows keep view/transcribe/export actions; initial 20 source rows and **Show 20 more**; storage size correctly marked unavailable; full-loaded session search rather than current-page-only, preserves existing history and details. | 100-source high-zoom/screen-reader and real server paginated history not fully checked. |
| **W12** New Project | Empty name, required field explanation, neutral placeholder, all create controls retained. | Entire bottom-sheet keyboard/IME matrix pending. |
| **W13** Calendar | Dynamic current-day marker, all four modes retained, narrow Week seven-day selector and Full week action; interval-union occupied time, total block duration and overlap conflict labels/list; shared dock preserved. | Local 23/25-hour DST day lengths, midnight intervals, and half-open conflict pairs now pass targeted Node tests in Kolkata and New York. Complete event-editor accessibility, all time zones, repeated-hour user selection and cross-shell clock-preference propagation remain open. Native Calendar Agenda/Day labels now apply its existing 12/24-hour selection. |
| **W14** Insights | Seven-day **7 daily** bins, 30-day **five six-day** bins, 90-day **13 weekly** bins with accurate labels and matching data tables. Checkpoint event message uses the actual selected range, not a fixed 28 days. `Other` contributes a genuine subject-time bar on the same scale. No verified concept-linked repeats are not falsely reported as “no repeats.” Illustrative Study rhythm is opt-in via **View example**, with hour positions aligned to clock time. | Full date-scope/provenance integration, accessible chart alternatives, consistent axes and data quality tests on live records incomplete. |
| **W15** Atlas | Graph, outline, filters and explicit Explore map retained, browse-scroll gesture preserved, capped nested scrollers removed; page horizontal overflow guarded without clipping the interactive map workspace. | Phone overview now has bounded labeled node cells and continuation clusters, and the inspector is in normal flow. Full 2,500-node proof, keyboard navigation, and graph/outline state reconciliation are still open. |
| **W16** Inbox | Full group-ID/count and true batch preview, native edit/live math preview, Save draft/Cancel/Approve edits. **Individual rejection/approval and batch approval** share a six-second browser-persisted deferred **Undo** queue. Pending/sending/confirmed/uncertain status ledger survives component unmount; staged IDs are withheld from batch selection; pending states survive reload and are undoable; ambiguous results not automatically retried. | **Partial P0:** no backend idempotency guarantees, partial-batch reconciliation and failed-item retry matrix incomplete. Local draft-version conflict now presents the current proposal and the local draft and disables approval until the learner explicitly chooses to keep or replace it. A full-height mobile queue sheet with Escape/focus restoration is implemented and browser-tested. |
| **W17** Settings | Connector replacement retains original confirmation; sign-out confirmation Cancel; Appearance instructions and New Project form validation. | Memory remains the canonical recall target; Review planning now links directly to the same slider, and the slider has an accessible value. Complete review-log retrieval is used for worker-aligned eligible-interval counting; error/loading/threshold states and an eligibility explanation added. Larger settings and accessibility matrix incomplete. |
| **W18** Responsive and accessibility | Prior browse/route test: 360/390/844/1280; new Inbox matrix also exercised 320/360/390/768/844/1280, Day and Night, plus 200% root text at 390, without horizontal document overflow or page JavaScript errors. | New Inbox matrix covers Night and one 200% text case. Broad 200%-all-routes, reduced-motion, screen readers, WebKit, Android IME, and full accessibility matrix still incomplete; a later full rerun stalled. The selected Calendar Week 320/390/768 and 200%-text states are now separately verified. |
| **W19** CSS cleanup | Source/module ownership respected; stylesheet modifications implemented by specific original-declaration replacements, **not an extra nineteenth override layer**. Previously misleading audit-complete metadata replaced with honest working-build metadata. | Full conflict audit, consolidated role/token owners and dead-CSS removal remain open. |


## Continuation: 3 November 2026 — focused contract, forecast and Inbox repairs

This pass edits the *same* standalone source tree. No repository or account access occurred.

1. **W01 — consistent review effort estimator:** Today, Review queue summaries, review timer, and calendar reservation use the shared 30-day review-derived estimator with one 25-second/card fallback. Today now consumes the **same cached 30-day review records** as Review when the records are available (avoids differing displayed estimates for an account with actual review-duration samples). Review due counts and the actual chosen budget remain separate; no scheduler policy was changed.
2. **W01/W17 — genuine tuning eligibility:** All available review-log pages are fetched through the existing adapter. Eligibility counts only usable later card reviews on a *different local study day*, respecting the saved rollover and IANA time zone. It reports loading/failed/unavailable instead of silently replacing those with 0 and discloses excluded records. Generated aggregate Insights totals are not used as individual tuning records. Unit fixtures cover a 04:00 Asia/Kolkata boundary and a repeated New York fall-back DST hour. These tests do **not** prove all live-account edge cases.
3. **W05 — complete forecast:** Seven supplied date bins stay visible, with exact Nov 3–9 calendar labels, no chart-value caps, visual seven-day bars, sorted due-by-deck strip and calculated Other, and a disclosure listing all decks. Missing data is never filled with invented zeros. The stress fixture shows 4,000 due today and 60 due decks, including 56 grouped into Other (3,732 due cards).
4. **W16 — accessible mobile Inbox queue:** An explicit Browse queue button opens the existing queue in a top-layer full-height sheet on narrow screens, with scroll containment, Escape, focus trap/restoration and preserved group actions; the desktop side-by-side queue is unchanged. Draft editing now guards against saved local drafts that diverge from the latest pending proposal; Approve edits is blocked until the user compares and chooses which text to continue with. Cancel warns on unsaved changes. This remains browser-side protection, **not production optimistic-concurrency control**.
5. **W17 — one recall-target editor:** The Review & calendar settings accordion shows the current recall value and a reachable **Edit in Memory** button, which scrolls to/focuses the canonical Memory slider; no second setter or conflicting preference was introduced. The slider exposes the formatted percentage.
6. **W00/W19 — reproducible output:** The strengthened offline packer validates the immutable original hash, all 78 imports, inline anchors, and exact remediated output bytes. A fresh baseline unpack/pack/verify was tested. The inaccurate old metadata claiming all audit findings were solved has been corrected.

### New focused verification

| Test | Result |
| --- | --- |
| `node --check` on each of the 78 edited/unmodified ESM modules | **Pass** |
| `python repack.py verify` against edited source tree | **Pass**, identical SHA-256 to the packaged HTML |
| Fresh pristine copy `unpack → pack → verify` | **Pass**; 78 original imports retained |
| `node evidence/check_eligibility.js` | **Pass**, Kolkata rollover and New York DST repeated-hour fixtures; empty/unavailable states |
| `python evidence/verify_contracts_new.py` | **Pass earlier in this pass**; Today/Review/Settings load, estimates agree in the provided fixture; no page JS errors |
| `python evidence/verify_forecast_expanded.py` | **Pass**, exact seven-date forecast, full counts/deck totals, no page JS errors |
| `python evidence/verify_inbox_sheet.py` | **Pass**, full-height queue at mobile size, Escape, opener focus restoration, row selection, no page JS errors |
| `python evidence/verify_draft_conflict.py` | **Pass**, stale draft blocks Approve edits until explicit user selection; no page JS errors |
| `python evidence/verify_memory_link.py` | **Pass**, unique in-accordion link focuses Memory section, labeled slider, no horizontal overflow or JS errors |
| `python evidence/verify_access_matrix.py` | **Passed an earlier run in this pass**; subsequent combined suite timed out at the viewport matrix after the three prior tests passed. Do not count the timed-out rerun as an independent pass. |

**Coverage boundary:** This remains a packaged, extreme-data *demo* fixture. Real server mutations, backend concurrency and reconciliation, native-device screen readers, full theme/zoom matrix, and production runtime behaviour have not been verified.

## Browser and source verification

| Check | Result |
| --- | --- |
| All ESM source modules | **78/78** pass `node --check` |
| `python repack.py verify` | **Pass**; original import IDs resolve; output matches current edited modules and patches byte-for-byte |
| Review 390×844 | **Pass**: first 8 decks, 44 px checkbox targets, 1,430px page in latest test, full reading/answer with scroll position preserved; no JS errors |
| Inbox group and editor | **Pass**: 4 visible / 10 pending in group; preview includes 10, editor Save draft/Cancel/Approve edits visible; no JS errors |
| Inbox individual Undo + route change | **Pass**: reject staged, Undo restored queue; separate staged action completed after navigating to Atlas; no JS errors |
| Inbox reload case | **Pass**: locally staged unexpired action remained visible and Undo available after simulated document reload in isolated demo context |
| Settings/New Project | **Pass**: sign-out cancellation, connector confirm entry, required-name field; no JS errors |
| Project/Sources/Sessions | **Pass**: 100-source and 1,000-conversation demo fixtures load, search entry and paging visible; no JS errors |
| Insights 7 / 30 / 90 | **Pass**: 7 / 5 / 13 review bins in tables; correct selected-range checkpoint copy; opt-in example chart and genuine Other bar; no JS errors |
| Paths action menu | **Pass** at 360 / 390 / 1280 widths; all operations visible, menu closes, no layout displacement or JS errors |
| Main route utility menu | **Pass** at 360 / 390 / 844 / 1280 widths across Paths/Project/Atlas/Settings/Calendar/Inbox; all routes remain within viewport and no JS errors |
| Calendar arithmetic | Earlier focused overlap scenario **pass**: 225 min summed, 160 min occupied, 2 overlapping pairs / 3 affected blocks; narrow Week layout rendered |

### Verification limitations

- Browser checks use Chromium with external fonts suppressed and a packaged demo fixture. They do not establish production API behavior, semantic keyboard completeness, actual assistive technology operation, or production load behavior.
- The legacy Inbox test uses `Object.keys(localStorage)` to look for `lemma.proposal.draft:` keys, but the demo’s localStorage fallback is an in-memory adapter whose actual keys are not enumerable through that method; that assertion is **not a valid persistence proof**. Draft state should be verified by reopen/refresh with the adapter's own getter.
- No source repo CI, branch protection, live migrations, real data, background notification state, or Supabase reads/writes were tested or modified.
- Screenshots and `evidence/` scripts are supporting inspection records, not complete V01–V16 acceptance.

## Outstanding critical gates, in practical priority order

1. **W01:** one authoritative clock, **scoped metric/selected-queue and provenance** contract shared by Today, Project, Review, Calendar and Insights, with real DST and idempotent focus interval coverage. (Shared review-time estimate and tuning eligibility are now implemented.)
2. **W16:** production-safe per-ID reconciliation and controlled retries for partial/unknown responses. The mobile full-height queue sheet, local draft-change guard, and deferred Undo are implemented in the standalone source.
3. **W13/W10:** complete responsive Calendar editor and Date/Week event status matrix; 100-checkpoint Route, 15 stages, steppers, keyboard equivalents and focus links.
4. **W14/W15/W17:** full real-data Insights aggregation/data quality, dense Atlas clustering/accessible outline, and end-to-end recall-target/tuner testing (the single Memory editor and worker-aligned eligibility count are now wired).
5. **W18/W19:** full six-viewport × two-theme × enlarged-text acceptance, screen-reader tests and CSS/source ownership consolidation.

**No owner permission to remove a feature was needed or inferred.** The current artifact is an improved, interactive **standalone mockup**, not a completed production remediation. Full W00–W19 acceptance must not be claimed from this build.

## Rebuild instructions

In an extracted source bundle, run `python repack.py pack` and `python repack.py verify`; the editable modules are in `modules/`. The source bundle also contains modification scripts and Playwright checks under `evidence/` (which may require adapting absolute `/mnt/data` paths on a different machine). Repacking requires no GitHub checkout or network/backend account.


## Continuation: 3 November 2026 — DST, Atlas exploration, focus intervals and time-log accuracy

This pass remains exclusively in detached `lemma-ui-remediation/` source files. **No repository, backend, deployment, schedule, or actual user data changed.** The immutable original SHA-256 remains `1afddf9c611ad3835e9fec043ca05f577149f34668a4529a7fbe58f6d9fc904b`.

1. **W13 — Calendar time arithmetic:** Daily boundaries now use local civil dates and their actual elapsed duration, not a fixed 1,440-minute assumption. Events spanning midnight are split across selected days; summation and occupied-time union share real instants, with half-open conflict comparisons. Status patterns and labels distinguish planned, busy and logged events in Calendar and the legend. Dynamic Month day markers and event dots use actual state; Agenda, Day, Week, Month, editor and tool access survive.
2. **W15 — Atlas dense-phone exploration:** At narrow browse widths a bounded overview uses readable labeled concept cells; selecting a concept expands its visible family and a continuation cluster pages through additional siblings. The graph retains its full-screen interactive layout, relation filters, search, outline and the 102-node stress overview. A conflicting sticky-inspector layout rule was retired at its source so details appear below the browse map rather than obscuring it. Mobile page width is bounded. This is not exhaustive proof for 2,500 concepts and 8,000 relationships.
3. **W01/W08 — Focus log interval integrity:** New sessions get stable session IDs and timestamp anchors. Study segments are recorded around breaks; saved focus sessions have `startInstant`, `endInstant`, segment-level `intervals`, `committedAt`, and project/checkpoint metadata where available. A repeated save uses a stable log ID and does not append a second local entry. Paused sessions do not count waiting time in their interval end. Older sessions without reliable anchors are preserved but labeled `timeApproximate`. This is **local demo idempotency**, not an exactly-once backend guarantee.
4. **W01 — Time Log editing:** A title/note/subject edit retains existing focus segments and timing identity. Explicitly changing an entry's date/start/end replaces its previous segment details with one user-adjusted interval; the editor warns about this, and marks the resulting time as manually adjusted/approximate.
5. **W01 — Truthful Time Log:** Removed the fixed November 1 date and the misleading “Today's notebook” label above an all-time sum. The view now states **All-time study log** and the exact saved-record scope, separates committed from active effort in explanatory copy, shows entry dates and inferred-time provenance, and paginates the entire stress fixture 30 records at a time without removing edit/split/export controls.

### New verification in this continuation

| Check | Observed result |
| --- | --- |
| `TZ=America/New_York node evidence/test_calendar_elapsed.js` | **Pass**: 23-hour spring day, 25-hour fall day, midnight carry, two conflicts involving three blocks |
| `TZ=Asia/Kolkata node evidence/test_calendar_elapsed.js` | **Pass**: normal 24-hour local days, midnight carry, same conflict scenario |
| `node evidence/test_timer_intervals.js` | **Pass**: 30-minute session; two focus segments excluding a break; paused segment excluding waiting; inferred legacy date/time |
| `python evidence/verify_timer_save.py` | **Pass**: save a running session via native Calendar; exactly one local `focus:` log after two save attempts; no JS errors |
| `python evidence/verify_timer_edit.py` | **Pass**: metadata-only edit preserves time segments; changing displayed clock times intentionally replaces segments and records provenance; no JS errors |
| `python evidence/verify_calendar_atlas_next.py` | **Pass**: all four Calendar views, Atlas compact overview, branch expansion, continuation group and full-screen map; no JS errors at 390 × 844 |
| `python evidence/verify_time_log_paging.py` | **Pass**: 1,203 demo records, 30 displayed initially, then 60 after Show more; no JS errors at 390 × 844 |
| `python evidence/verify_contracts_new.py` | **Pass**: Today, Review and Settings, including consistent 33-card review-time estimate; no JS errors |
| `node --check` all 78 JS modules; `node --check evidence/calendar_runtime.js` | **Pass** |
| `python repack.py pack`, then `python repack.py verify` | **Pass**: deterministic output from 78 original import IDs and patched owner code; SHA-256 `24219cea082be047a44da890c0313d6fa1dcd0e8fe4b57c644d4af48eb47d34e` |

### Important remaining gates

The implementation is still **partial**. Prioritize full account-scoped/provenance-correct study-time metrics across routes; robust revision/conflict reconciliation across tabs and backend, **actual time-zone preference** and 12-/24-hour accessibility, the complete Calendar phone event/drag matrix, Atlas stress/search/keyboard proof, production-safe Inbox partial-result recovery, and W18/W19 screen-reader, enlarged-font, Night, and source CSS ownership coverage. The test results above prove only the named fixture paths, not full W00–W19 acceptance.


## Continuation: 3 November 2026 — read-only study-effort contract and shell/Calendar reconciliation

All edits remain in the **standalone user-supplied HTML working copy** and its offline source ZIP; no GitHub, Supabase, schedules, deployments or live user data were changed.

1. **W01 — one local effort selector:** Added `domain/effort-metrics.js` as the canonical read-only selector, embedded inside the existing `#lemma-session-store` script by the deterministic repacker. It takes existing saved entries and session-store timer state; no new timer store or backend was created. The selector deduplicates entries by saved ID, merges overlapping segments within one saved record, splits real intervals at local-midnight boundaries and returns exact committed vs uncommitted minutes, hour coverage, approximate-record count, time-zone provenance and captured time. Saved intervals take precedence over legacy duration-only rows; undated legacy rows are not invented into a selected day.
2. **W01/W04 — Today hour totals:** Today now uses the selector instead of summing only records whose `date` matches today. Sessions crossing midnight count only the part on the selected day. The existing ribbon marks every hour touched by those intervals, including an interval such as 10:58–11:02. Planned-span rendering is still incomplete.
3. **W01 — Time Log identity and totals:** The saved-record list deduplicates repeated IDs, and its all-time total uses the same saved-interval selector rather than independently summing potentially rounded `min` fields. Existing pagination, editing and exports were retained.
4. **W01/W08 — consistent shell and Calendar save identities:** Shell `recordEffort` now emits the same stable `focus:<session-id>` record format as native Calendar, including real start/end instants, study segments, project/checkpoint IDs and an explicit approximate-time flag for older timers without anchors. Pause and breaks close the active study segment; Resume opens another; Finish/New Focus resets the session identity. Timer `min` reflects the study intervals when available, not a contradictory focus-duration cap.
5. **W01 — rejected revision safety:** If the shared store refuses an update due to a stale timer revision, the shell now rolls back any newly staged local entry and warns the learner. This is **browser-side conflict protection** and does not establish production exactly-once writes or cross-tab atomicity.
6. **W00 — canonical source path:** The `source_file` patch contract in `repack.py` embeds the editable `domain/effort-metrics.js` deterministically instead of maintaining a second JSON copy. The immutable original hash and 78 import identifiers remain unchanged.

### Verification for this continuation

| Check | Result |
| --- | --- |
| `TZ=Asia/Kolkata node evidence/test_effort_metrics.js` | **Pass**: midnight split, hour crossing, record identity, legacy, overlapping fragments, pause/break handling |
| `TZ=America/New_York node evidence/test_effort_metrics.js` | **Pass** on same saved-interval fixtures with a different device zone |
| `python evidence/verify_effort_selector_browser.py` | **Pass**: four saved minutes, hours 10/11 shown on Today; saved-state Calendar transition retains same stream; no page JS errors |
| `python evidence/verify_shell_focus_identity.py` | **Pass** on latest build: one shell save, two real intervals, repeat Finish creates no duplicate, Calendar retains same ID; no page JS errors |
| `TZ=Asia/Kolkata node evidence/test_calendar_elapsed.js` and `TZ=America/New_York node evidence/test_calendar_elapsed.js` | **Pass**: existing local-day DST/conflict cases unaffected |
| `node evidence/test_timer_intervals.js` | **Pass**: existing timer segment fixtures unaffected |
| `node --check` for all 78 ESM modules | **Pass** |
| `python repack.py pack && python repack.py verify` | **Pass**; deterministic SHA-256 `8e2d3239757a35d6bda6070ad9b857a977ff8a8b534f9378091cf5c95a7ac4e0` |
| `python evidence/verify_mobile_core_matrix_v2.py` | **Partial diagnostic only**: sampled states reported zero horizontal overflow and no page errors, but several routes had not finished loading; not a complete W18 acceptance pass |
| Larger combined browser rerun | **Timed out after the first focused browser check**; no full-suite pass claimed |

### Remaining gates (not waived)

**W01:** user-selected IANA time zone and 12/24-hour preference across the *entire* app (Calendar Agenda/Day now obey the setting); completed account-scope/provenance contract across Project/Insights and the scheduler. **W13/W15:** Calendar form/gesture accessibility and dense graph navigation; 2,500-concept Atlas proof. **W16:** backend idempotency/partial-result reconciliation. **W18/W19:** complete screen-reader, enlarged-text, Night, forced-colors, contrast and CSS owner audits. Existing demo-mode UI results cannot establish backend or Android production safety.


## Continuation: 3 November 2026 — civil-date planning and Calendar clock preference

This incremental change is entirely within the offline working copy. No GitHub, Supabase, live account data, or scheduled agents were accessed or changed. The immutable original HTML and all 78 module import identifiers are unchanged.

1. **W01/W13 — date-safe quick capture and shutdown:** The native Calendar quick-capture parser now resolves `today` and `tomorrow` from the device's current local civil date, instead of fixed November 1–2 strings. Closing the day now carries selected work to the next local date. The Shutdown card calculates *logged today* from the shared saved-effort selector and reads *daily intention* from the saved daily budget rather than showing an unrelated all-time sum and hardcoded 4h target. A new deadline defaults to 14 local calendar days from creation, not a hardcoded November date.
2. **W13 — backward planning safeguards:** Planning uses the actual number of intervening **local calendar dates** (avoiding DST duration assumptions). At or after 18:01, the first generated 18:00 evening block is tomorrow, not a date/time already past. Dates at/after the deadline are excluded. If no usable planning days exist, the dialog explains why and offers no approval button; the save handler rechecks the date. Generated block identity uses `bw:<deadline-id>:<local-date>` so repeating the action does not create a second block for that same deadline/date. Existing blocks remain intact; this local fixture does not automatically resolve conflicts with other calendar events.
3. **W13 — functioning 12/24-hour display preference:** The existing Day preferences editor already persisted `clock`; it now controls visible and accessible Agenda and Day/Week spatial time labels, hour ruler, now cursor, and conflict details. Stored `HH:mm` fields, original event instants, native time inputs, and drag mathematics remain unchanged. In 12h mode, a block is presented as `6:04 AM–6:29 AM`; selecting 24h returns to `06:04–06:29`. This is **not** an implementation of arbitrary user-selected IANA time zones or fully shared clock preference outside the native Calendar.
4. **W13/W18 — readable seven-day Week overview:** On narrow screens the overview is a two-row grid with seven day controls of at least 44px, each showing a visible `N blocks` count and full accessible label, plus the existing Full week option. The native layout decides whether seven timeline columns fit the available viewport budget. The original 4-view Calendar, event editing, drag/resize and Tools remain available.
5. **W19 — local owner changes:** Clock and civil-date helpers are included in `#lemma-native-calendar-runtime` via the existing deterministic inline-patch system. The Week CSS is changed within its existing native-calendar owner declaration rather than appending another global audit override.

### Verified during this continuation

| Check | Result |
| --- | --- |
| `python evidence/verify_calendar_locale_and_planning.py` | **Pass**: Asia/Kolkata UI shows 12h Agenda and Day labels, toggles to 24h, creates a +14-day deadline, and generates only future evening blocks at the tested after-18:00 time; saved clock survives route remount; no page JS errors. A full browser reload was **not** verified by this test. |
| `python evidence/verify_calendar_reflow.py` | **Pass**: Week at 320×640, 390×844, 390×844 at 200% root text, 768×1024, and 390×844 Night. Seven day targets on narrow screens are ≥44px, no page-level horizontal overflow or page errors. |
| `python evidence/verify_capture_and_closure.py` | **Pass**: Shutdown dialog labels both logged today and daily intention in the mounted Calendar view; no page errors. The separate Quick Capture internal-route test could not mount via its direct hash URL, so its browser-path verification remains **open**. |
| `TZ=America/New_York node evidence/test_calendar_elapsed.js` and `TZ=Asia/Kolkata node evidence/test_calendar_elapsed.js` | **Pass**: 23h/25h DST day boundaries, ordinary 24h days and original overlap fixtures. |
| `TZ=Asia/Kolkata node evidence/test_effort_metrics.js`, `TZ=America/New_York node evidence/test_effort_metrics.js`, `node evidence/test_timer_intervals.js` | **Pass**: saved-effort and timer regression logic. |
| `node --check` all 78 editable JavaScript modules; `node --check evidence/calendar_runtime.js` | **Pass**. |
| `python repack.py pack && python repack.py verify` | **Pass**: byte-identical deterministic offline build, SHA-256 `8bbc6994cb94afa788d0d71f381a9f7741ad66cb092d1a0b53754e40f624e479`. |

**Still not accepted:** W01 full account/provenance consistency, a user-selected display time zone and DST repeated-hour editing, W13 full keyboard/touch event-controls matrix, W15 2,500-node Atlas stress/accessibility checks, W16 backend partial/unknown-result reconciliation, W18 entire browser/screen-reader/theme matrix, and W19 full token/CSS consolidation. This remains an offline demo HTML and does not prove production data semantics.


## Continuation — Atlas keyboard access and portable HTML delivery (3 November 2026)

- **W15/W18:** In the existing Atlas component owner, visible nodes now support Up/Down/Left/Right, Home, and End to move keyboard focus among the currently rendered nodes; Enter/Space continue to inspect/expand. The compact phone cells now show an explicit focus outline; node selection remains a separate action. The map keeps its real relationships, compact clusters, searchable outline, original full-screen graph, and the existing pan/zoom gestures. The map zoom controls have clearly labeled − / Fit / + actions. A native **Map key and keyboard help** disclosure labels the four status marks and explains structural/prerequisite/related edges. This is an additive accessibility improvement, not a completed 2,500-concept stress audit.
- **W19 source ownership:** The key's styles are inserted through a localized replacement of the original Atlas CSS-owner rule. No nineteenth audit override layer was introduced.
- **W00 testing portability:** The Calendar elapsed/DST and timer interval Node regression scripts now resolve fixture paths relative to their own extracted folder, not a hard-coded environment path. Other historic browser/evidence scripts may still contain container-specific paths and remain documented as such.
- **Delivery workaround:** The raw `.html` is also distributed as `Lemma_UI_HTML_Only.zip` (with an extraction guide), plus a byte-identical `.html.txt` fallback in case a client refuses raw HTML downloads. The developer source ZIP remains separate.

### Tests executed in this continuation

- `python repack.py pack && python repack.py verify`: **pass**, reproducible standalone HTML with all 78 import IDs and SHA-256 `5c70f880f493a4a6ac02ce1e1efb2d0093aa83a7a6f898b62db5e16ceb7a1af5`.
- `node --check modules/*.js`: **pass**, all 78 modules.
- `python evidence/verify_atlas_keyboard_mapkey.py`: **pass** at 390 px mobile and 1280 px desktop for arrow focus, Home/End, compact focus frame, Enter selection, full-screen + Escape, map legend, outline; reflow checks at 320 px Day, 390 px at 200% text, 390 px Night, and 844 px Night, all with zero document overflow and no page JavaScript errors.
- `python evidence/verify_calendar_reflow.py`: **pass** for phone Week view in 320/390 px Day, 390 px Night and 200% text, without overflow/errors.
- `python evidence/verify_calendar_locale_and_planning.py`: **pass** for clock preference, future planning, deadline date default, route remount and no page JavaScript errors.
- `TZ=Asia/Kolkata node evidence/test_effort_metrics.js` and `TZ=America/New_York ...`: **pass**.
- `TZ=Asia/Kolkata node evidence/test_calendar_elapsed.js` and `TZ=America/New_York ...`: **pass**.
- `node evidence/test_timer_intervals.js`: **pass**.

**Unresolved:** full cross-app IANA zone choice, every Calendar gesture/keyboard alternative, stress Atlas 2,500 concepts/8,000 edges, backend partial-result reconciliation for Inbox, and complete W18 browser/screen-reader/forced-colors and W19 CSS ownership coverage. No new production claim is implied.
