from pathlib import Path
p=Path('/mnt/data/lemma-ui-remediation/modules/23__Page-RJ1UO7Rb.js')
s=p.read_text()
def sub(a,b):
 global s
 n=s.count(a)
 if n!=1:raise Exception(f'{n} occurrences for {a[:100]!r}')
 s=s.replace(a,b)
sub('a = JSON.stringify([n.projectSlug, i, r]),','a = JSON.stringify([n.projectSlug, i, r, n.kind]),')
sub('''        label: `${i} / ${r}`,
        project: n.projectSlug,''','''        label: `${i} / ${r} · ${n.kind === `card_edit` ? `Card edits` : n.kind === `card` ? `New cards` : `Plan`}`,
        project: n.projectSlug,''')
sub('''                                            e.proposals.length,
                                            ` `,
                                            e.proposals.length === 1
                                              ? `card`
                                              : `cards`,''','''                                            e.proposals.length,
                                            ` shown · `,
                                            (de.find(t=>t.key===e.key)??e).proposals.length,
                                            ` pending in this group`,''')
sub('''                                          `Review batch from `,
                                          P(e.project),
                                          ` · `,
                                          e.label,
                                          ` · `,
                                          (de.find(t=>t.key===e.key)??e).proposals.filter(p=>p.kind===`card`).length,
                                          ` cards`,''','''                                          `Inspect & approve `,
                                          (de.find(t=>t.key===e.key)??e).proposals.filter(p=>p.kind===`card`).length,
                                          ` cards`,''')
sub('''            children: l?.proposals
              .filter((e) => e.kind === `card`)
              .slice(0, 10)
              .map((e) =>''','''            children: l?.proposals
              .filter((e) => e.kind === `card`)
              .map((e) =>''')
sub('''          (l?.proposals.filter((e) => e.kind === `card`).length ?? 0) > 10 &&
            (0, N.jsxs)(`p`, {
              className: `mb-3 text-label text-ink-3`,
              children: [
                `Showing 10 of `,
                l?.proposals.filter((e) => e.kind === `card`).length,
                ` cards in this batch.`,
              ],
            }),''','''          (0,N.jsx)(`p`,{
            className:`mb-3 text-label text-ink-3`,
            children:`All ${l?.proposals.filter(e=>e.kind===`card`).length??0} selected cards are listed above. No other group is included.`,
          }),''')
sub('''                children: `Queue approvals`,''','''                children: `Approve ${l?.proposals.filter(e=>e.kind===`card`).length??0} cards (6 s Undo)`,''')
# Existing draft editor remains; ensure no approval from Save draft.
sub('''                          onClick: () => {
                            Q?.card && (U(Q.card.front), G(Q.card.back), V(!0));
                          },''','''                          onClick: () => {
                            if(!Q?.card)return;
                            let saved=null;
                            try{saved=JSON.parse(localStorage.getItem(`lemma.proposal.draft:${Q.projectSlug}:${Q.id}`)||`null`)}catch{}
                            if(saved && (saved.baseFront!==Q.card.front || saved.baseBack!==Q.card.back)){
                              a(`This proposal changed since your local draft was saved. Review both versions before approval.`,{tone:`danger`});
                            }
                            U(saved?.front??Q.card.front);G(saved?.back??Q.card.back);V(!0);
                          },''')
sub('''      (0, N.jsx)(S, {
        open: ce,
        onClose: () => V(!1),
        title: `Edit card`,''','''      (0, N.jsx)(S, {
        open: ce,
        onClose: () => V(!1),
        title: `Edit card`,''')
sub('''            (0, N.jsx)(C, {
              disabled: J || !H.trim(),
              onClick: () => Q && void $(Q, !0, { front: H, back: W }),
              children: `Approve`,
            }),''','''            (0,N.jsxs)(`div`,{className:`grid grid-cols-3 gap-2`,children:[
              (0,N.jsx)(C,{variant:`ghost`,onClick:()=>V(!1),children:`Cancel`}),
              (0,N.jsx)(C,{variant:`ghost`,disabled:J||!Q?.card||!H.trim(),onClick:()=>{
                if(!Q?.card)return;
                try{localStorage.setItem(`lemma.proposal.draft:${Q.projectSlug}:${Q.id}`,JSON.stringify({front:H,back:W,baseFront:Q.card.front,baseBack:Q.card.back,savedAt:new Date().toISOString()}));a(`Draft saved on this device`);V(!1)}catch{a(`Could not save the local draft`,{tone:`danger`})}
              },children:`Save draft`}),
              (0,N.jsx)(C,{disabled:J||!H.trim(),onClick:()=>Q&&void $(Q,!0,{front:H,back:W}),children:`Approve edits`}),
            ]}),''')
# Successful remote approved edits remove saved local draft, failure preserves.
sub('''          : await n.mutateAsync(r.id),
          (()=>{const index=X.findIndex(p=>p.id===r.id);''','''          : await n.mutateAsync(r.id),
          o && localStorage.removeItem(`lemma.proposal.draft:${r.projectSlug}:${r.id}`),
          (()=>{const index=X.findIndex(p=>p.id===r.id);''')
p.write_text(s)
print('proposals patch applied')
