"""W14: selected-day bins and checkpoint range for all three Insights periods.
Preserve adapter/export contract and scheduler timezone/day-index authority.
"""
from pathlib import Path
p=Path(__file__).parent/'modules/55__insights-DjL4G0LE.js'
s=p.read_text()
a=s.index('function c(e,t){');b=s.index('function l(o,s,l={})',a)
new='''function c(e,t){
 const bucketSize=t===7?1:t===30?6:7;
 // This adapter's aggregate comes from getInsightData(t); trust its filtered
 // topline and use its daily rows, not an independently invented 28-day range.
 const days=Array.isArray(e.reviewDays)?e.reviewDays.slice(-t):[];
 const checkpointDays=Array.isArray(e.checkpointDays)?e.checkpointDays.slice(-t):[];
 const makeBuckets=(rows,size)=>Array.from({length:Math.ceil(rows.length/size)},(_,index)=>{
   const items=rows.slice(index*size,(index+1)*size),sum=field=>items.reduce((total,item)=>total+(Number(item[field])||0),0),count=sum(`count`);
   return {date:items[0]?.date??``,endDate:items.at(-1)?.date??``,count,
     recall:count?sum(`right`)/count:null,again:sum(`again`),hard:sum(`hard`),good:sum(`good`),easy:sum(`easy`)};
 });
 const calibration=[`sure`,`unsure`,`guess`].map(confidence=>{
   const item=e.calibration.find(row=>row.confidence===confidence),total=item?.total??0,right=item?.right??0;
   return {confidence,total,right,rate:total?right/total:null};
 });
 const checkpointWeeks=Array.from({length:Math.ceil(checkpointDays.length/bucketSize)},(_,idx)=>{
   const rows=checkpointDays.slice(idx*bucketSize,(idx+1)*bucketSize);
   return {label:`Period ${idx+1}`,date:rows[0]?.date??``,endDate:rows.at(-1)?.date??``,
     demonstrated:rows.reduce((n,row)=>n+(Number(row.demonstrated)||0),0),
     rechecked:rows.reduce((n,row)=>n+(Number(row.rechecked)||0),0)};
 });
 return {days:t,minutes:e.minutes,sessions:e.sessions,reviews:e.reviews,
   recall:e.reviews?e.right/e.reviews:null,recallBuckets:makeBuckets(days,bucketSize),
   reviewBuckets:makeBuckets(days,bucketSize),calibration,calibrationMessage:a(calibration),
   subjects:[...e.subjectMinutes].sort((a,b)=>b.minutes-a.minutes),checkpointWeeks,
   typicalSession:e.typicalSession,mostRevisited:e.mostRevisited};
}
'''
s=s[:a]+new+s[b:]
a=s.index('function l(o,s,l={})');b=s.index('export{s as n,o as r,l as t};',a)
new='''function l(source,days,opts={}){
 if(source.aggregate)return c(source.aggregate,days);
 const at=opts.now??Date.now(),clock=t(opts.rolloverHour??4,opts.timeZone??`UTC`),today=clock.dayIndex(at);
 const first=today-days+1;
 const date=index=>new Date(index*86400000).toISOString().slice(0,10);
 const within=timestamp=>{const instant=Date.parse(timestamp);return Number.isFinite(instant)&&instant<=at&&clock.dayIndex(instant)>=first&&clock.dayIndex(instant)<=today};
 const reviews=source.reviews.filter(e=>within(e.reviewedAt));
 const sessions=source.sessions.filter(e=>within(e.startedAt));
 const bucketSize=days===7?1:days===30?6:7;
 const intervals=Array.from({length:Math.ceil(days/bucketSize)},(_,idx)=>{
   const start=first+idx*bucketSize,end=Math.min(today+1,start+bucketSize);
   return {start,end,date:date(start),endDate:date(end-1),label:`Period ${idx+1}`};
 });
 const reviewBuckets=intervals.map(({start,end,date,endDate})=>{
   const items=reviews.filter(x=>{const d=clock.dayIndex(Date.parse(x.reviewedAt));return d>=start&&d<end});
   return {date,endDate,count:items.length,recall:r(items),again:items.filter(x=>x.rating===1).length,
     hard:items.filter(x=>x.rating===2).length,good:items.filter(x=>x.rating===3).length,
     easy:items.filter(x=>x.rating===4).length};
 });
 const projectById=new Map(source.projects.map(p=>[p.id,p])),subjectMinutes=new Map();
 for(const session of sessions){
   const subject=projectById.get(session.projectId)?.subject;
   if(!subject)continue;
   const prior=subjectMinutes.get(subject.id)??{subject,minutes:0};
   prior.minutes+=Number(session.minutes)||0;
   subjectMinutes.set(subject.id,prior);
 }
 const checkpointWeeks=intervals.map(({start,end,date,endDate,label})=>{
   const items=source.checkpointEvents.filter(ev=>{
     const instant=Date.parse(ev.at),index=clock.dayIndex(instant);
     return Number.isFinite(instant)&&instant<=at&&index>=start&&index<end;
   });
   return {date,endDate,label,demonstrated:items.filter(e=>e.kind===`demonstrated`).length,
     rechecked:items.filter(e=>e.kind===`recheck_ok`||e.kind===`recheck_fail`).length};
 });
 const calibration=n(reviews);
 return {days,minutes:sessions.reduce((sum,e)=>sum+(Number(e.minutes)||0),0),
   sessions:sessions.length,reviews:reviews.length,recall:r(reviews),
   recallBuckets:reviewBuckets,reviewBuckets,calibration,calibrationMessage:a(calibration),
   subjects:[...subjectMinutes.values()].sort((a,b)=>b.minutes-a.minutes),
   checkpointWeeks,typicalSession:i(sessions.map(e=>e.minutes)),
   mostRevisited:[...source.misconceptions].sort((a,b)=>b.times-a.times||a.label.localeCompare(b.label))[0]??null};
}
'''
s=s[:a]+new+s[b:]
p.write_text(s)
print('W14 aggregator rewritten; exports preserved')
