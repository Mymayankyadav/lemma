"""Source-owner replacements of obsolete Atlas layout declarations, detached HTML only."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent;pfile=root/'inline-patches.json'
patches=json.loads(pfile.read_text()); original=(root/'Lemma_UI_Final.html').read_text()
items=[
('.lg-connection-filter{display:flex!important;flex-wrap:wrap!important;overflow:visible!important}',
 '.lg-connection-filter{overflow:visible}'),
('.lg-connection-filter button{white-space:nowrap}', '.lg-connection-filter button{white-space:normal}'),
('.lg-inspector{position:sticky!important;bottom:12px!important;z-index:20!important;max-height:55dvh;overflow:auto;box-shadow:0 4px 24px #0002;padding:18px!important;background:var(--paper)!important;scroll-margin:20px}',
 '.lg-inspector{position:static;max-height:none;overflow:visible;padding:18px;background:var(--paper);scroll-margin:20px}'),
('.lg-inspector{bottom:8px!important;max-height:50dvh}', ''),
('.lg-inspector{bottom:150px!important}', ''),
]
for old,new in items:
 assert original.count(old)==1,(old[:80],original.count(old))
 patches.append({'old':old,'new':new})
pfile.write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n')
print('Replaced obsolete Atlas forced layout declarations in canonical detached patch manifest')
