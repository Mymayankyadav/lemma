from pathlib import Path
import json,re
root=Path(__file__).resolve().parent; orig=(root/'Lemma_UI_Final.html').read_text(); path=root/'inline-patches.json';p=json.loads(path.read_text())
old=re.search(r'function log\(\)\{return .*?\}\nfunction menuItem',orig,re.S).group(0)
assert orig.count(old)==1
new='''let crLogShown=30;
function log(){
 const records=[...S.entries].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||String(b.start||'').localeCompare(String(a.start||''))||String(a.id||'').localeCompare(String(b.id||'')));
 const visible=records.slice(0,crLogShown);
 const total=Math.round(records.reduce((n,e)=>n+(Number(e.min)||0),0));
 const today=new Date(),heading=today.toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long'});
 return pageHead('An honest record','The time you gave.',heading+' · edit, split or add a session.',ib('plus','new-entry','Add manual entry'))+
 `<section class="cx-paper"><div class="cx-row"><h2>All-time study log</h2><span class="cx-tag" aria-label="${records.length} records, ${total} minutes logged">${duration(total)} logged</span></div>
 <p class="cx-caption" role="status">Showing ${visible.length.toLocaleString()} of ${records.length.toLocaleString()} saved records · all time. Running focus time is not included until saved.</p>
 ${visible.map(e=>`<div class="cx-log-row"><span class="cx-caption">${esc(e.date||'Unassigned date')}<br>${esc(e.start||'—')}</span><div><h3>${esc(e.title)}</h3><p class="cx-caption">${esc(e.subject)} · ${esc(e.focus)} · ends ${esc(e.end||'—')}${e.checkpointId?' · '+esc(e.checkpointId):''}</p>${e.timeApproximate?`<p class="cx-caption" aria-label="Time is approximate">${e.editedTimeRange?'Time adjusted by hand':'Time inferred from a prior timer snapshot'}</p>`:''}${e.note?`<p class="cx-sub" style="margin-top:5px">${esc(e.note)}</p>`:''}</div><div style="text-align:right"><b style="font-weight:500">${duration(e.min||0)}</b><div>${ib('edit','edit-entry','Edit '+e.title,`data-id="${esc(e.id)}"`)}</div></div></div>`).join('')||'<p class="cx-empty">Your next session starts a new page.</p>'}
 ${visible.length<records.length?`<button type="button" data-cx="log-more" class="cx-btn" style="width:100%;min-height:44px">Show ${Math.min(30,records.length-visible.length)} more records</button>`:''}
 </section><div class="cx-row">${btn(icon('export')+' Export CSV','export-csv','text')}${btn('JSON backup','export-json','text')}</div>`;
}
function menuItem'''
p.append({'old':old,'new':new})
anchor="case'new-entry':entryEditor();break;"
assert orig.count(anchor)==1
p.append({'old':anchor,'new':"case'log-more':crLogShown+=30;render();break;\n"+anchor})
path.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
print('Time Log now gives true all-time scope, dated entries, inferred-time provenance and 30-at-a-time pagination.')
