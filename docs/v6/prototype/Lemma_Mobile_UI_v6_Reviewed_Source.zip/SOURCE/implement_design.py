"""One-time migration of source owners; do not replay on an edited tree."""
from pathlib import Path
import re,json
root=Path(__file__).parent;owners=root/'owners'
def edit(name,fn):
 p=root/'modules'/name;s=p.read_text();p.write_text(fn(s))
def css_chunks(s):
 # Preserve strings/comments and nested functional selectors while finding blocks.
 i=0;start=0;quote=None;comment=False;depth=0
 while i<len(s):
  c=s[i]
  if comment:
   if s[i:i+2]=='*/':comment=False;i+=2;continue
  elif quote:
   if c=='\\':i+=2;continue
   if c==quote:quote=None
  elif s[i:i+2]=='/*':comment=True;i+=2;continue
  elif c in '\"\'':quote=c
  elif c=='{':
   if depth==0:head=s[start:i];body=i+1
   depth+=1
  elif c=='}':
   depth-=1
   if depth==0:yield head,s[body:i];start=i+1
  i+=1
 if s[start:].strip():yield s[start:],None

def migrate(css,drop):
 out=[]
 for head,body in css_chunks(css):
  head=re.sub(r'/\*.*?\*/','',head,flags=re.S).strip()
  if body is None:out.append(head);continue
  if head.startswith('@'):
   if any(head.startswith(x) for x in ['@media','@supports','@layer','@container']):body=migrate(body,drop)
  elif drop(head):continue
  body=body.replace('!important','')
  body=re.sub(r'font-size:\s*(\d+(?:\.\d+)?)px',lambda m:'font-size:12px' if float(m[1])<12 else m[0],body)
  out.append(head+'{'+body+'}')
 return '\n'.join(out)
# Root controls and layout now have explicit stylesheet ownership.
p=owners/'design-system.css';css=p.read_text()
css=migrate(css,lambda h:any(x in h for x in ['Main navigation','cr-mobile-dock','lemma-time-dock','lemma-review-','data-review-card-scroll']))
css+='''
/* Shared tokens, controls and shell. Specialist math/vendor roles stay above. */
html{--ctl:44px;--tab:56px;scroll-padding-bottom:calc(var(--lemma-bottom-chrome,100px) + 12px)}
body{font-size:1rem;line-height:1.5}
h2,h3{font-style:normal}button,input,select,textarea,summary{font-family:var(--font-ui);font-size:inherit}
.ui-button{min-height:48px;border-radius:6px;box-shadow:0 1px 0 var(--hair)}
.ui-button.ghost{background:var(--paper);border:1px solid var(--edge);box-shadow:none;color:var(--ink)}
.ui-segmented{background:var(--paper-2);border-radius:6px;padding:4px;gap:4px}
.ui-segmented button{min-height:44px;position:relative;border-radius:4px}
.ui-segmented button[aria-pressed=true]{background:var(--ink);color:var(--paper)}
.ui-segmented button>span:first-child:not(:last-child){background:transparent}
[data-ui=review-checkbox]{position:relative;display:inline-flex;align-items:center;justify-content:center;min-width:44px;min-height:44px;flex-shrink:0}
[data-ui=review-checkbox]>input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;margin:0;z-index:1}
[data-ui=review-checkbox]>span[aria-hidden]{width:22px;height:22px;background:var(--paper);border:1px solid var(--edge);border-radius:3px;color:var(--paper)}
[data-ui=review-checkbox][data-state=checked]>span[aria-hidden],[data-ui=review-checkbox][data-state=mixed]>span[aria-hidden]{background:var(--ink);border-color:var(--ink)}
[data-ui=review-checkbox]:focus-within{outline:2px solid var(--link);outline-offset:2px;border-radius:4px}
nav[data-ui=main-navigation]{position:fixed;inset:auto 0 0;height:calc(56px + env(safe-area-inset-bottom));display:flex;justify-content:space-around;background:var(--paper);z-index:50;padding-bottom:env(safe-area-inset-bottom);border-top:1px solid var(--hair)}
nav[data-ui=main-navigation] a{position:relative;min-height:56px;min-width:44px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:2px;color:var(--ink-2);font-size:.75rem;padding:4px}
nav[data-ui=main-navigation] a>span:last-child{font-size:.75rem;line-height:1rem}
nav[data-ui=main-navigation] a[aria-current=page]{color:var(--ink);background:var(--paper-2);border-top:2px solid var(--ink)}
#cr-mobile-dock{display:flex;position:fixed;left:0;right:0;bottom:calc(56px + env(safe-area-inset-bottom));z-index:49;min-height:44px;padding:0 8px;gap:8px;background:var(--paper);border-top:1px solid var(--hair);border-radius:0;box-shadow:none;color:var(--ink)}
#cr-mobile-dock .lemma-dock-context{display:flex;align-items:center;gap:8px;flex:1;min-width:0;min-height:44px;text-align:left}
#cr-mobile-dock .cr-label,#cr-mobile-dock .cr-meta{font-size:.75rem;white-space:normal}
#cr-mobile-dock time{font-size:1rem;color:var(--ink);font-variant-numeric:tabular-nums}
#cr-mobile-dock button{min-height:44px;font-size:.875rem;color:var(--ink);background:transparent}
body:has(.lemma-review-stage) #cr-mobile-dock,body:has(.lemma-review-stage) nav[data-ui=main-navigation]{display:none}
#main-content{padding-bottom:calc(var(--lemma-bottom-chrome,100px) + 16px)}
[data-ui=utility-menu-row]{position:absolute;right:16px;top:16px;z-index:60;min-height:44px;margin:0}
[data-ui=utility-menu] summary{min-height:44px;min-width:44px;background:var(--paper)}
#main-content h1{padding-right:64px}
body:has(lemma-native-calendar),body:has(lemma-native-calendar) #main-content{height:auto;min-height:100dvh;overflow:visible}
body:has(lemma-native-calendar) #main-content{padding-top:16px;max-width:1400px}
#cr-calendar-frame,#cr-calendar-native-host,lemma-native-calendar,.cr-calendar-native{height:auto;min-height:0;overflow:visible;display:block}
.cr-calendar-tools,.cr-calendar-add{font-size:.875rem;min-height:44px}
.cr-calendar-header-actions{margin-right:64px}
.lemma-chart-data-scroll{width:100%;min-width:0;overflow:visible}
.lemma-chart-data-scroll svg{width:100%;max-width:100%;height:auto}
[data-ui=continue-row]{display:grid;grid-template-columns:32px minmax(0,1fr);gap:8px;padding:12px;background:var(--paper)}
[data-ui=continue-row] .truncate{white-space:normal;overflow:visible;text-overflow:clip}
[data-ui=continue-row]>button{grid-column:2;justify-self:start}
[data-ui=path-actions]{min-height:44px;min-width:44px}
[data-ui=path-row]{padding-block:8px;min-height:64px}
/* Review task owns one reading surface, independent of the browse shell. */
body:has(.lemma-review-stage) #main-content{padding:8px 16px;height:100dvh;min-height:0;max-width:none;overflow:hidden}
[data-ui=review-task]{height:100%;display:flex;flex-direction:column;gap:8px;min-height:0}
.lemma-review-header{height:48px;min-height:48px;display:flex;align-items:center;justify-content:space-between}
.lemma-review-top-progress{display:none}
.lemma-review-stage{flex:1;min-height:0;display:flex;padding:0 0 4px}
.lemma-review-card-motion{flex:1;min-height:0;display:flex}
[data-ui=review-paper]{flex:1;min-height:0;display:flex;flex-direction:column;height:auto;border:1px solid var(--edge);background:var(--paper);padding:8px 12px;border-radius:6px;overflow:hidden}
[data-ui=review-paper]>div:first-child{flex-shrink:0}
[data-ui=review-paper]>div:nth-child(2){flex:1;min-height:0;display:flex;flex-direction:column}
[data-review-card-scroll]{flex:1;min-height:0;height:auto;overflow:auto;padding:0 4px 8px}
[data-ui=review-more-below]{min-height:28px;height:28px;padding:0;background:var(--paper);border:0;font-size:.75rem}
[data-ui=review-remaining]{display:none}
[data-ui=review-grades]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;flex-shrink:0;background:var(--paper)}
[data-ui=review-grades] button{min-height:54px;font-size:.875rem}
@media(max-height:480px){.lemma-review-header{height:44px;min-height:44px}[data-ui=review-more-below]{height:20px;min-height:20px}[data-ui=review-paper]{padding:4px 8px}}
@media(max-width:360px){nav[data-ui=main-navigation] a{padding-inline:2px}}
@media(min-width:1000px){#main-content{max-width:900px}#cr-mobile-dock{padding-inline:max(16px,calc((100vw - 900px)/2))}}
'''
p.write_text(css)
# Native calendar: remove old spatial owners instead of another override layer.
p=owners/'lemma-native-calendar-runtime.js';s=p.read_text();i=s.index('const calendarCSS=')+len('const calendarCSS=');old,n=json.JSONDecoder().raw_decode(s[i:]);end=i+n
old=migrate(old,lambda h:any(x in h for x in ['cr-planner','cr-spatial','cr-grid','cr-time-grid','cr-week-overview','cr-month-scroller','cr-view-switch','cr-calendar-shortcuts','lemma-agenda','cx-calendar-page','cx-month','cr-full-week-action']))
old+='''
/* Native Calendar owns its workspace and forwards task actions unchanged. */
:host{display:block;overflow:visible;height:auto;color:var(--ink)}
.cx-calendar-page,.cx-calendar-page .cx-page{height:auto;min-height:0;overflow:visible;padding:0;background:transparent}
.cr-planner{display:flex;flex-direction:column;gap:12px;height:auto;min-height:0}
.cr-spatial-toolbar{display:flex;flex-direction:column;gap:8px;padding:0}
.cr-spatial-date{display:flex;align-items:center;justify-content:space-between;gap:8px}
.cr-spatial-date button{min-height:44px;min-width:44px;font-size:.875rem}
.cr-view-switch{display:flex;gap:4px;background:var(--paper-2);border:0;border-radius:6px;padding:4px;width:100%}
.cr-view-switch button{flex:1;min-width:0;min-height:44px;font-size:.875rem;border:0;border-radius:4px;background:transparent;color:var(--ink-2)}
.cr-view-switch button[aria-pressed=true]{background:var(--ink);color:var(--paper)}
.cr-week-overview{display:grid;grid-template-columns:repeat(7,minmax(44px,1fr));gap:2px;margin:0}
.cr-week-overview button{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:60px;min-width:44px;padding:2px;font-size:.75rem;background:var(--paper);border:1px solid var(--hair);border-radius:4px;color:var(--ink)}
.cr-week-overview button.selected{border:2px solid var(--ink);background:var(--paper-2)}
.cr-week-overview button.today b{text-decoration:underline;text-decoration-color:var(--accent);text-underline-offset:3px}
.cr-full-week-action{grid-column:1/-1;min-height:44px}
.cr-grid-scroller{position:relative;flex:none;min-height:240px;height:clamp(240px,50dvh,640px);overflow:auto;border:1px solid var(--edge);border-radius:6px;background:var(--paper);touch-action:pan-x pan-y}
.cr-time-grid{display:grid;position:relative;grid-template-columns:43px minmax(0,1fr);grid-template-rows:32px var(--calendar-height);min-width:100%;background:var(--paper)}
.cr-time-grid.is-week{grid-template-columns:43px repeat(7,minmax(100px,1fr));min-width:800px}
.cr-grid-date,.cr-grid-corner{position:sticky;top:0;z-index:8;background:var(--paper);border-bottom:1px solid var(--hair);display:flex;align-items:center;justify-content:center;gap:4px;font-size:.75rem}
.cr-grid-hours{position:relative;grid-column:1;grid-row:2}.cr-grid-hours>span{position:absolute;right:4px;font-size:.75rem}
.cr-grid-day{position:relative;grid-row:2;background:repeating-linear-gradient(to bottom,transparent 0,transparent 83px,var(--hair) 83px,var(--hair) 84px)}
.cr-spatial-event{position:absolute;top:calc(var(--start)*1.4px);height:calc(var(--minutes)*1.4px);left:calc(var(--lane)*100%/var(--lanes));width:calc(100%/var(--lanes));min-width:0;min-height:0;overflow:hidden;text-align:left;border:1px solid var(--edge);border-radius:4px;background:var(--paper-2);padding:3px;color:var(--ink)}
.cr-spatial-event strong{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.875rem}
.cr-spatial-event .cr-event-top,.cr-event-sub{font-size:.75rem;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cr-spatial-event.cr-short .cr-event-sub,.cr-spatial-event.cr-short .cr-event-grip,.cr-spatial-event.cr-short .cr-resize-handle{display:none}
.lemma-agenda{display:flex;flex-direction:column;gap:8px;overflow:visible;height:auto}
.lemma-agenda-item{display:flex;flex-direction:column;gap:3px;min-height:72px;padding:10px 12px;background:var(--paper);color:var(--ink);border:1px solid var(--hair);border-radius:6px;text-align:left}
.lemma-agenda-item strong{font-size:1rem;line-height:1.4}.lemma-agenda-item span,.lemma-agenda-item small{font-size:.8125rem;color:var(--ink-2)}
.lemma-agenda-item[data-status=logged]{border-left:3px solid var(--early)}.lemma-agenda-item[data-status=planned]{border-left:3px dashed var(--link)}.lemma-agenda-item[data-status=busy]{border-left:3px double var(--ink-3)}
.cr-month-scroller{overflow:visible;height:auto;flex:none}
.cx-month{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));height:auto;overflow:visible;border:1px solid var(--hair);border-radius:6px;background:var(--paper)}
.cx-month-head{font-size:.75rem;padding:4px;text-align:center}
.cx-month-day{min-height:64px;min-width:0;padding:4px;display:flex;flex-direction:column;align-items:center;background:var(--paper);color:var(--ink);border:1px solid var(--hair);font-size:.75rem;overflow:visible}
.cx-month-day b{display:flex;justify-content:center;align-items:center;width:24px;height:24px;border-radius:50%;font-size:.75rem;flex-shrink:0}
.cx-month-day.now b{background:var(--accent);color:var(--on-accent)}
.cr-grid-caption{font-size:.8125rem;line-height:1.5;color:var(--ink-2);background:var(--paper);border:1px solid var(--hair);border-radius:6px;padding:8px}
.cr-grid-caption summary{min-height:44px;display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;color:var(--ink)}
.cr-calendar-shortcuts{display:flex;flex-wrap:wrap;gap:8px}
.cr-calendar-shortcuts button{min-height:44px;background:var(--paper);border:1px solid var(--edge);color:var(--ink);border-radius:6px;padding:6px 10px;font-size:.875rem}
.cr-spatial-footer{display:flex;justify-content:flex-end;min-height:44px}
.cr-spatial-footer button{min-height:44px;font-size:.875rem}
.cx-form input[type=checkbox]{width:20px;height:20px;min-height:20px;flex:none;accent-color:var(--ink)}
.cx-form label:has(input[type=checkbox]){min-height:44px}
@media(max-width:350px){.cr-week-overview{grid-template-columns:repeat(4,minmax(44px,1fr))}}
@media(min-width:1000px){.cr-grid-scroller{height:clamp(400px,64dvh,800px)}}
'''
s=s[:i]+json.dumps(old)+s[end:]
s=s.replace("${view==='day'?'is-day':'is-week'}","${days.length===1?'is-day':'is-week'}")
s=s.replace('${blocksForDay(dkey(d),true).length} blocks</small>','${blocksForDay(dkey(d),true).length}</small>')
s=s.replace('>${dateLabel}</button>','>${dateLabel} · Today</button>')
s=s.replace("<button type=\"button\" data-cx=\"new-block\">Add block</button><button type=\"button\" data-cx=\"spatial-tools\">Tools</button>",'')
start=s.index('<div class="cr-spatial-footer"><button');finish=s.index('</div></div>`',start)
s=s[:start]+'''<div class="cr-spatial-footer"><button class="cr-footer-plan" data-cx="autoplan">${icon('leaf')} Auto-plan</button>'''+s[finish:]
# Keep accurate detailed aggregates behind a concise summary.
s=s.replace('<div class="cr-grid-caption"><span>','<details class="cr-grid-caption"><summary>${duration(workload.occupied)} occupied${workload.affected?` · ${workload.affected} conflicting blocks`:``}<span>Day details</span></summary><span>')
s=s.replace('</span></div>`}\n <div class="cr-calendar-shortcuts"','</span></details>`}\n <div class="cr-calendar-shortcuts"')
s=s.replace('${blocksForDay(day,true).length} blocks','${blocksForDay(day,true).length}')
s=s.replace("case'full-week':fullWeek=true;render();break;","case'full-week':fullWeek=!fullWeek;render();break;")
s=s.replace("const weekStrip=compactWeek?", "const weekStrip=(view==='week'&&fullWeek)?`<button class=\"cr-full-week-action\" data-cx=\"full-week\">Back to selected day</button>`:compactWeek?")
p.write_text(s)
# Explicit renderer hooks; component behavior and native state are preserved.
edit('53__index-DcUkykC4.js',lambda s:s.replace('"aria-label": `Main navigation`,','"aria-label": `Main navigation`,"data-ui":`main-navigation`,').replace('"aria-label": `Copy resume prompt`,','"aria-label": `Copy resume prompt`,').replace('className:`relative z-40 mb-1 flex min-h-11 justify-end`','className:`utility-menu-position`'))
# Today continue row hook is attached to its existing renderer root.
p=root/'modules/53__index-DcUkykC4.js';s=p.read_text();i=s.index('"aria-label": `Copy resume prompt`');a=s.rfind('return (0, A.',0,i);b=s.index('className:',a);s=s[:b]+'"data-ui":`continue-row`,\n      '+s[b:];p.write_text(s)
# Give review paper/task/grading explicit layout hooks.
p=root/'modules/15__Page-Cajg06h3.js';s=p.read_text();i=s.index('stack: !0');s=s[:i]+s[i:].replace('stack: !0,','stack: !0,"data-ui":`review-paper`,',1)
s=s.replace('` after this`','` after this`')
i=s.index('` after this`');a=s.rfind('(0, I.jsxs)(`',0,i);b=s.index('{',a);s=s[:b+1]+'"data-ui":`review-remaining`,'+s[b+1:]
s=s.replace('"aria-label": `Grade answer`,','"aria-label": `Grade answer`,"data-ui":`review-grades`,')
# Main run wrapper: find first ancestor JSX flex column above header.
i=s.index('className: `lemma-review-stage`');a=s.rfind('className:',0,s.rfind('lemma-review-header',0,i));
# Data task marker is placed on main rendered task section via the existing run class.
for term in re.findall(r'className: `([^`]*review[^`]*)`',s):pass
s=s.replace('className: `lemma-review-header`','className: `lemma-review-header`')
p.write_text(s)
print('Owner migration complete')
