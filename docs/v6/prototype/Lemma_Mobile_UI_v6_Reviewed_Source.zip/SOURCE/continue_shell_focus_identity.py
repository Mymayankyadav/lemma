"""Owner-specific shell timer fixes in the detached bundled HTML; one shot."""
from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
orig=(root/'Lemma_UI_Final.html').read_text('utf8')
pfile=root/'inline-patches.json'; patches=json.loads(pfile.read_text('utf8'))
def add(old,new):
 assert orig.count(old)==1,(old[:130],orig.count(old))
 assert not any(old in q['old'] for q in patches),'duplicate patch'
 patches.append({'old':old,'new':new})
old=re.search(r'function recordEffort\(t,seconds,now=Date\.now\(\)\)\{.*?\n\}\nfunction changeTimer\(',orig,re.S).group(0)
new='''function crCloseShellStudySpan(t,at=Date.now()){
 if(t.phase!=='study'||!t.running)return;
 if(!Array.isArray(t.studyIntervals))t.studyIntervals=[];
 const start=Number(t.activeStudyStart)||Number(t.stamp)||0;
 if(start&&at>start&&!t.studyIntervals.some(x=>x.start===start&&x.end===at))
  t.studyIntervals.push({start,end:at});
 t.activeStudyStart=null;
}
function recordEffort(t,seconds,now=Date.now()){
 if(!Number.isFinite(seconds)||seconds<=0)return false;
 if(t.mode==='pomo')seconds=Math.min(seconds,Math.max(1,Number(t.focus)||50)*60);
 const identity=t.sessionId||('legacy-'+String(t.startedAt||t.stamp||t.rev||'unknown')+'-'+String(t.activity||''));
 const id='focus:'+identity;
 // Calendar and shell write the same local record identity. Repeated Finish
 // and cross-entry-point saves must not append a second item.
 if(S.entries.some(x=>x.id===id))return false;
 if(t.phase==='study'&&t.running)crCloseShellStudySpan(t,now);
 const segments=(Array.isArray(t.studyIntervals)?t.studyIntervals:[])
  .filter(x=>Number.isFinite(Number(x.start))&&Number.isFinite(Number(x.end))&&+x.end>+x.start)
  .map(x=>({start:+x.start,end:+x.end}));
 const approximate=!segments.length;
 if(approximate){
  // Prior/demo timers have no anchor. Retain their elapsed effort honestly.
  const end=t.phase==='break'?now-Math.max(0,Number(t.elapsed)||0)*1000:now;
  segments.push({start:end-seconds*1000,end});
 }
 const startMs=Math.min(...segments.map(x=>x.start)),endMs=Math.max(...segments.map(x=>x.end));
 const start=new Date(startMs),end=new Date(endMs),time=d=>String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
 S.entries.push({id,sessionId:identity,date:dateKey(start),subject:t.activity||'Study',
  title:t.intent||t.activity||'Study session',min:Math.max(1,Math.round(seconds/60)),
  start:time(start),end:time(end),startInstant:start.toISOString(),endInstant:end.toISOString(),
  intervals:segments.map(x=>({start:new Date(x.start).toISOString(),end:new Date(x.end).toISOString()})),
  committedAt:new Date(now).toISOString(),timeApproximate:approximate,
  focus:'Unrated',note:'',projectId:t.projectId||U?.links?.[t.activity]||null,
  checkpointId:t.checkpointId||null,kind:t.kind||'proof'});
 return true;
}
function changeTimer('''
add(old,new)
old=''' const t=S.timer,now=Date.now(),e=elapsed(),baseRev=Number(t.rev)||0;
 if(action==='focus')'''
new=''' const t=S.timer,now=Date.now(),e=elapsed(),baseRev=Number(t.rev)||0;
 if(!t.sessionId)t.sessionId='legacy-'+String(t.startedAt||t.stamp||t.rev||'unknown')+'-'+String(t.activity||'');
 if(action==='focus')'''
add(old,new)
old="''" # no-op
old="''" if False else "if(!(t.running||t.paused)){jointToast('There is no active session to save.');return;}recordEffort(t,studySec,now);"
new="if(!(t.running||t.paused)){jointToast('There is no active session to save.');return;}recordEffort(t,studySec,now);"
# recordEffort itself closes the active interval before save; clear intervals on finish.
add("Object.assign(t,{elapsed:0,stamp:now,running:false,paused:false,phase:'study',studyElapsed:0});", "Object.assign(t,{elapsed:0,stamp:now,running:false,paused:false,phase:'study',studyElapsed:0,studyIntervals:[],activeStudyStart:null,sessionId:null,startedAt:null});")
add("Object.assign(t,{elapsed:e,stamp:now,running:false,paused:true});", "crCloseShellStudySpan(t,now);Object.assign(t,{elapsed:e,stamp:now,running:false,paused:true});")
add("Object.assign(t,{stamp:now,running:true,paused:false});", "Object.assign(t,{stamp:now,activeStudyStart:now,running:true,paused:false});")
add("if(nextFocus)recordEffort(t,Number(t.studyElapsed)||0,now);", "if(nextFocus)recordEffort(t,Number(t.studyElapsed)||0,now);")
add("Object.assign(t,{phase:'study',elapsed:nextFocus?0:(Number(t.studyElapsed)||0),studyElapsed:0,stamp:now,running:true,paused:false,cycle:(Number(t.cycle)||1)+(nextFocus?1:0)});", "Object.assign(t,{phase:'study',elapsed:nextFocus?0:(Number(t.studyElapsed)||0),studyElapsed:0,stamp:now,activeStudyStart:now,studyIntervals:nextFocus?[]:(t.studyIntervals||[]),sessionId:nextFocus?crypto.randomUUID():t.sessionId,startedAt:nextFocus?now:t.startedAt,running:true,paused:false,cycle:(Number(t.cycle)||1)+(nextFocus?1:0)});")
add("Object.assign(t,{studyElapsed:t.mode==='pomo'?Math.min(e,t.focus*60):e,breakLength:(Number(t.cycle)||1)%(Number(t.every)||4)===0?(Number(t.long)||20):(Number(t.short)||10),phase:'break',elapsed:0,stamp:now,running:true,paused:false});", "crCloseShellStudySpan(t,now);Object.assign(t,{studyElapsed:t.mode==='pomo'?Math.min(e,t.focus*60):e,breakLength:(Number(t.cycle)||1)%(Number(t.every)||4)===0?(Number(t.long)||20):(Number(t.short)||10),phase:'break',elapsed:0,stamp:now,activeStudyStart:null,running:true,paused:false});")
add("Object.assign(t,{elapsed:0,studyElapsed:0,stamp:now,running:true,paused:false,phase:'study'});", "Object.assign(t,{elapsed:0,studyElapsed:0,stamp:now,activeStudyStart:now,studyIntervals:[],sessionId:crypto.randomUUID(),startedAt:now,running:true,paused:false,phase:'study'});")
pfile.write_text(json.dumps(patches,ensure_ascii=False,indent=2)+'\n','utf8')
print('Shell and native Calendar now share focus ID and saved interval schema; total patches',len(patches))
