"""Continuation: W10 project state clarity and W11 source/session usability.
Edits only the unpacked owner module; no GitHub or live backend operations.
"""
from pathlib import Path
p=Path(__file__).parent/'modules/19__Page-DfokWqaX.js'
s=p.read_text()
def replace(old,new):
 global s
 ct=s.count(old)
 if ct!=1:raise RuntimeError(f'{ct} matches for {old[:130]!r}')
 s=s.replace(old,new,1)

# W10: differentiate schedule progress and goal forecast; never fabricate reconciliation.
replace('"Checkpoint schedule · " + u','"Checkpoint pace · " + u')
replace('c.pace.toFixed(2) + `/wk`','c.pace.toFixed(2) + ` checkpoints/week`')
replace('children: [r.targetLabel ?? `Target`, `:`],','children: [`Goal · `,r.targetLabel ?? `Target`, `:`],')
replace('children: [r.code, ` · IN PROGRESS`],','children: [r.code, ` · In progress`],')
replace('className: `mt-3 font-math text-answer italic leading-relaxed text-ink-soft`,','className: `mt-3 font-math text-body leading-relaxed text-ink`,')
# preserve the existing session counter, while not conflating tutor sessions with time entries.
replace('{ value: `sessions`, label: `Tutor sessions`, count: x.sessions.length },','{ value: `sessions`, label: `Sessions`, count: x.sessions.length },')

# Source grouping: one expandable, 20-row paginated viewport; list and filter operate on full data.
replace('children: L(e.kind) ? `Fold` : `Open`,','children: L(e.kind) ? `Collapse` : `Expand`,')
replace('.slice((T[e.kind] ?? 0) * 10, (T[e.kind] ?? 0) * 10 + 10)','.slice(0, ((T[e.kind] ?? 0) + 1) * 20)')
replace('className: `block truncate text-body-l`,','className: `block min-w-0 break-words text-body-l`,')
replace('''                          (0, Y.jsx)(Fe, { source: e, stat: c.get(e.id) }),''','''                          (0,Y.jsxs)(`details`,{
                            className:`lemma-source-details rounded-ctl border-t border-edge`,
                            children:[
                              (0,Y.jsx)(`summary`,{
                                className:`flex min-h-11 cursor-pointer items-center gap-2 py-2 text-label font-semibold text-ink-2`,
                                children:`Source details · View pages, transcription and exports`,
                              }),
                              (0,Y.jsx)(`div`,{className:`pb-2`,children:(0,Y.jsx)(Fe,{source:e,stat:c.get(e.id)})})
                            ]
                          }),''')
# Source storage unknown is not 0. Progress graphic only for at least 1 known PDF file.
replace('''                V ? `Storage usage unavailable` : $(B),
                V ? `` : ` of 1 GB`,''','''                V === R.length && V > 0 ? `Storage size unavailable` : V ? `Known PDF storage ` + $(B) : $(B) + ` of 1 GB`,''')
replace('''      (0, Y.jsx)(`div`, {
            role: `progressbar`,''','''      (z.length > 0 || R.length === 0) && (0, Y.jsx)(`div`, {
            role: `progressbar`,''')
# One consistent source pagination: incremental 20, not Previous and misleading More 10.
start='''              L(e.kind) &&
                e.rows.length > 10 &&
                (0, Y.jsxs)(`div`, {'''
end='''            ],
          },
          e.kind,
        ),'''
pos=s.index(start); epos=s.index(end,pos)
old=s[pos:epos]
new='''              L(e.kind) && e.rows.length > 0 &&
                (0,Y.jsxs)(`div`,{
                  className:`flex min-h-11 flex-wrap items-center justify-between gap-2 px-3 py-2 text-label text-ink-2`,
                  children:[
                    (0,Y.jsx)(`span`,{role:`status`,children:`Showing ${Math.min(e.rows.length,((T[e.kind]??0)+1)*20)} of ${e.rows.length} sources`}),
                    ((T[e.kind]??0)+1)*20<e.rows.length &&
                      (0,Y.jsx)(`button`,{
                        type:`button`,
                        "data-source-page":!0,
                        className:`min-h-11 rounded-ctl border border-edge px-3 text-label font-semibold text-ink`,
                        onClick:()=>D(old=>({...old,[e.kind]:(old[e.kind]??0)+1})),
                        children:`Show ${Math.min(20,e.rows.length-((T[e.kind]??0)+1)*20)} more`,
                      }),
                  ],
                }),
'''
s=s[:pos]+new+s[epos:]
# Search all loaded tutor sessions (not merely current 20-item page).
replace('''function Ue({ slug: e, sessions: n }) {
  let [r, i] = (0, K.useState)(0);''','''function Ue({ slug: e, sessions: n }) {
  let [r, i] = (0, K.useState)(0),
      [search,setSearch]=(0,K.useState)(``),
      [checkpoint,setCheckpoint]=(0,K.useState)(`all`);
  const checkpoints=[...new Set(n.map(s=>s.checkpointCode??s.checkpoint??s.cpCode).filter(Boolean))].sort();''')
replace('''  let a = [...n].sort(
      (e, t) =>
        Date.parse(t.startedAt) - Date.parse(e.startedAt) ||
        t.number - e.number,
    ),''','''  let a = [...n].filter(s=>{
    const cp=s.checkpointCode??s.checkpoint??s.cpCode??null;
    if(checkpoint!==`all` && cp!==checkpoint)return false;
    const term=search.trim().toLocaleLowerCase();
    return !term || [s.goal,s.summary,s.client,s.number,s.startedAt,cp]
      .filter(v=>v!==null&&v!==undefined).some(v=>String(v).toLocaleLowerCase().includes(term));
  }).sort(
      (e, t) =>
        Date.parse(t.startedAt) - Date.parse(e.startedAt) ||
        t.number - e.number,
    ),''')
replace('''    children: [
      (0, Y.jsxs)(`p`, {
        className: `text-label text-ink-3`,
        children: [`Sessions `, s + 1, `–`, s + c.length, ` of `, n.length],
      }),''','''    children: [
      (0,Y.jsxs)(`div`,{className:`flex flex-wrap gap-3`,children:[
        (0,Y.jsxs)(`label`,{className:`min-w-0 flex-1 text-label font-semibold text-ink-2`,children:[`Find a tutor conversation`,
          (0,Y.jsx)(`input`,{type:`search`,value:search,placeholder:`Title, number, tutor or date`,onChange:event=>{setSearch(event.target.value);i(0)},className:`mt-1 min-h-11 w-full rounded-ctl border border-edge-3 bg-[var(--paper)] px-3 text-body text-ink`})]}),
        checkpoints.length>0 && (0,Y.jsxs)(`label`,{className:`text-label font-semibold text-ink-2`,children:[`Checkpoint`,
          (0,Y.jsxs)(`select`,{value:checkpoint,onChange:event=>{setCheckpoint(event.target.value);i(0)},className:`mt-1 block min-h-11 rounded-ctl border border-edge-3 bg-[var(--paper)] px-2 text-body text-ink`,children:[
            (0,Y.jsx)(`option`,{value:`all`,children:`All checkpoints`}),
            ...checkpoints.map(cp=>(0,Y.jsx)(`option`,{value:cp,children:cp},cp))
          ]})]})
      ]}),
      (0, Y.jsx)(`p`, {
        role:`status`,className: `text-label text-ink-3`,
        children: a.length ? `Showing ${s+1}–${s+c.length} of ${a.length} tutor conversations` + (a.length!==n.length?` · ${n.length} total`:``) : `No tutor conversations match these filters`,
      }),''')
replace('''children: (0, Y.jsx)(t, { source: n.goal }),''','''children: (0, Y.jsx)(t, { source: /^Study session \\d+ for .+$/i.test(n.goal??``) ? `Tutor session ${n.number}` : n.goal }),''')
replace('''                        children:
                          n.minutes === null ? n.display : le(n.minutes),''','''                        children:
                          n.minutes == null ? `` : le(n.minutes),''')
replace('''          s + 20 < a.length &&
            (0, Y.jsxs)(`button`, {''','''          s + 20 < a.length &&
            (0, Y.jsxs)(`button`, {''')
# Distinguish Sessions from timed focus in accessible route.
replace('''    "aria-label": `Sessions`,
    className: `flex flex-col gap-4`,''','''    "aria-label": `Tutor conversations`,
    className: `flex flex-col gap-4`,''')
p.write_text(s)
print('W10/W11 modifications applied',len(s))
