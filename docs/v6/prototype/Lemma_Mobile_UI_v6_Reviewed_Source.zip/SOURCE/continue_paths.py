"""W09 Paths: subject headings, non-displacing project action menu and clearer paging.
Retains all existing project operations and management mutations.
"""
from pathlib import Path
p=Path(__file__).parent/'modules/53__index-DcUkykC4.js';s=p.read_text()
def rep(a,b):
 global s
 n=s.count(a)
 if n!=1:raise ValueError(f'{n} matches for {a[:110]!r}')
 s=s.replace(a,b,1)
# No heavyweight layout shift when a project menu opens; the row stays in flow.
rep('''      className: `px-3 py-3 hover:bg-[var(--paper-2)]`,
      "data-project-row": e.slug,''','''      className: `relative px-3 py-2 hover:bg-[var(--paper-2)]`,
      "data-project-row": e.slug,''')
rep('''            className: `mt-2 grid grid-cols-2 gap-2 border-t border-edge pt-2`,''','''            className: `fixed inset-x-3 z-50 grid max-h-[min(65dvh,440px)] grid-cols-2 gap-2 overflow-y-auto rounded-ctl border border-edge-3 bg-[var(--paper)] p-3 shadow-xl sm:absolute sm:inset-x-auto sm:right-2 sm:top-11 sm:w-[min(22rem,calc(100vw-2rem))]`,
            style:{bottom:`calc(var(--lemma-bottom-chrome,56px) + 12px)`},''')
rep('''            children: [
              u
                .filter((t) => !(t.label === `Pin` && e.pinned))''','''            children: [
              (0,A.jsxs)(`div`,{className:`col-span-2 flex min-h-11 items-center gap-2 border-b border-edge pb-2`,children:[
                (0,A.jsx)(`strong`,{className:`min-w-0 flex-1 break-words text-body text-ink`,children:`Manage `+e.title}),
                (0,A.jsx)(`button`,{type:`button`,className:`min-h-11 rounded-ctl border border-edge px-3 text-label font-semibold text-ink`,onClick:()=>o(false),children:`Close`}),
              ]}),
              u
                .filter((t) => !(t.label === `Pin` && e.pinned))''')
rep('''                      children: t.label,
                    },
                    t.label,
                  ),
                ),
              (0, A.jsx)(`button`, {
                type: `button`,
                role: `menuitem`,
                onClick: () => o(!1),
                className: `min-h-11 rounded-ctl border border-edge px-2 text-left text-label`,
                children: `Close`,
              }),''','''                      children: t.patch.status===e.status?`${t.label} · already ${e.status}`:t.label,
                    },
                    t.label,
                  ),
                ),''')
# Show subjects even when only one project lives under them.
rep('''      r > 1 &&
        (0, A.jsxs)(`button`, {''','''      (0, A.jsxs)(`button`, {''')
rep('''          className: `flex min-h-11 w-full items-center gap-2 border-b border-edge text-left`,''','''          className: `flex min-h-12 w-full items-center gap-2 border-b border-edge px-3 text-left`,''')
rep('''      (r === 1 || !i) &&
        (0, A.jsx)(`div`, {''','''      !i &&
        (0, A.jsx)(`div`, {''')
rep('''    className: `overflow-hidden rounded-slab border border-edge bg-[var(--paper)]`,''','''    className: `overflow-visible rounded-slab border border-edge bg-[var(--paper)]`,''')
start='''                        ? (0, A.jsx)(
                            `section`,
                            {
                              "aria-label": `Single-project paths`,'''
pos=s.index(start)
end=s.index('''                        : (0, A.jsx)(
                            Ki,''',pos)
new='''                        ? (0,A.jsx)(`div`,{
                            "aria-label":`Single-project subject groups`,
                            className:`flex flex-col gap-3`,
                            children:e.groups.map(group=>(0,A.jsx)(Ki,{
                              name:group.name,glyph:group.glyph,items:group.items,total:group.total,
                              collapsed:c.includes(group.id),onToggle:()=>ae(group.id),pinnedCount:h,
                            },group.id)),
                          },`single-${t}`)
'''
s=s[:pos]+new+s[end:]
# Page control is replacement, not append; counts are scoped to nonpinned set.
rep('''children: `Show previous projects`,''','''children: `Previous page`,''')
rep('''                              `Page `,
                              u + 1,
                              ` of `,
                              Math.ceil(ee / b),''','''                              `Page `,u+1,` of `,Math.ceil(ee/b),
                              ` · `,Math.min(ee,u*b+1),`–`,Math.min(ee,(u+1)*b),` of `,ee,` unpinned`,
                              _.length?` · ${_.length} pinned shown each page`:`` ,''')
rep('''                                `Show next `,
                                Math.min(b, ee - x),
                                ` projects`,''','''                                `Next page`,''')
# Atlas's visible overview is clipped, keeping intentional map pan in its workspace.
rep('''? `relative min-h-dvh w-full pb-[calc(var(--tab)+env(safe-area-inset-bottom)+24px)]`''','''? `relative min-h-dvh w-full overflow-x-clip pb-[calc(var(--tab)+env(safe-area-inset-bottom)+24px)]`''')
p.write_text(s)
print('W09 paths and Atlas outer overflow refinements applied')
