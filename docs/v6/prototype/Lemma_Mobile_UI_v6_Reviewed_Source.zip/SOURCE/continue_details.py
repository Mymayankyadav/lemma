from pathlib import Path
p=Path(__file__).resolve().parent/'modules/23__Page-RJ1UO7Rb.js';s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a[:120]);s=s.replace(a,b,1)
rep('''        e.reason &&
          (0, N.jsxs)(`p`, {
            className: `mt-6 flex items-start gap-2 text-label italic text-ink-3`,
            children: [
              (0, N.jsx)(f, { size: 15, className: `text-amber` }),
              e.reason,
            ],
          }),''','''        e.reason &&
          (0,N.jsxs)(`details`,{className:`mt-6 rounded-ctl border border-edge bg-[var(--paper)] px-3 text-label text-ink-2`,children:[
            (0,N.jsxs)(`summary`,{className:`flex min-h-11 cursor-pointer items-center gap-2 font-semibold text-ink`,children:[
              (0,N.jsx)(f,{size:15,className:`text-amber`,"aria-hidden":true}),`Why this card?`]}),
            (0,N.jsx)(`p`,{className:`pb-3 leading-relaxed`,children:e.reason})
          ]}),''')
rep('''  (0,k.useEffect)(()=>lemmaDecisionLedger.subscribe(setLedger),[]);
  (0,k.useEffect)(()=>{''','''  (0,k.useEffect)(()=>lemmaDecisionLedger.subscribe(setLedger),[]);
  (0,k.useEffect)(()=>{
    const desktop=()=>{if(window.innerWidth>=800)setQueueOpen(false)};
    window.addEventListener(`resize`,desktop);
    return()=>window.removeEventListener(`resize`,desktop);
  },[]);
  (0,k.useEffect)(()=>{''')
rep('''            className: `mb-4 max-h-56 min-w-0 overflow-y-auto text-ink-2`,''','''            className: `mb-4 min-w-0 text-ink-2`,''')
p.write_text(s)
print('W16 reasons and full batch preview updated')
