"""W16: durable deferred per-proposal queue in the packaged demo's page owner.
Uses only the existing proposal mutation adapters and browser localStorage.
Does not claim exactly-once backend delivery; ambiguity remains visible.
"""
from pathlib import Path
p=Path(__file__).parent/'modules/23__Page-RJ1UO7Rb.js'
s=p.read_text()
def rep(a,b):
 global s
 n=s.count(a)
 if n!=1:raise RuntimeError(f'{n} anchors {a[:140]!r}')
 s=s.replace(a,b,1)

service='''// W16: a page-independent six-second decision ledger. Persist only operations,
// never assume an ambiguous network response means a successful save.
const lemmaDecisionLedger = (() => {
  const key=`lemma.ui.proposalDecisions.v2`;
  const activeStates=new Set([`pending`,`sending`,`uncertain`]);
  let entries=[];
  try{
    const saved=JSON.parse(localStorage.getItem(key)||`[]`);
    if(Array.isArray(saved)) entries=saved.filter(r=>r && typeof r.id===`string` && Array.isArray(r.ids) && r.ids.length && typeof r.state===`string`).slice(-60);
  }catch{}
  // Any operation interrupted while sending must be reconciled, not retried.
  for(const item of entries){
    if(item.state===`sending` || (item.state===`pending` && item.deadline<=Date.now())) item.state=`uncertain`;
  }
  let version=0, runner=null, refresh=null, ready=false;
  const listeners=new Set(), timers=new Map();
  const snapshot=()=>entries.map(e=>({...e,ids:[...e.ids],results:e.results?{...e.results}:undefined}));
  function publish(){
    try{localStorage.setItem(key,JSON.stringify(entries.slice(-60)))}catch{}
    version++;for(const fn of listeners)fn(snapshot());
  }
  function reserved(){return new Set(entries.filter(e=>activeStates.has(e.state)||e.state===`confirmed`).flatMap(e=>e.ids))}
  function subscribe(fn){listeners.add(fn);fn(snapshot());return()=>listeners.delete(fn)}
  function stage(input){
    const ids=[...new Set(input.ids)].filter(x=>typeof x===`string` && !reserved().has(x));
    if(!ids.length)return null;
    const now=Date.now();
    const record={id:`decision-${now}-${Math.random().toString(36).slice(2,9)}`,
      ids,projectSlug:input.projectSlug,action:input.action,label:input.label,
      edit:input.edit??null,previous:input.previous??null,createdAt:now,
      deadline:now+6000,state:`pending`,results:{}};
    entries.push(record);publish();schedule(record);return record;
  }
  function undo(id){
    const item=entries.find(e=>e.id===id);
    if(!item||item.state!==`pending`)return null;
    clearTimeout(timers.get(id));timers.delete(id);
    entries=entries.filter(e=>e.id!==id);publish();return item;
  }
  async function send(id){
    const item=entries.find(e=>e.id===id);
    if(!item||item.state!==`pending`||!runner||!ready)return;
    if(item.deadline>Date.now()){schedule(item);return}
    item.state=`sending`;publish();
    for(const proposalId of item.ids){
      try{
        await runner(item,proposalId);
        item.results[proposalId]=`confirmed`;
        if(item.edit&&item.projectSlug)
          try{localStorage.removeItem(`lemma.proposal.draft:${item.projectSlug}:${proposalId}`)}catch{}
      }catch{
        // The server may have committed before a lost response. No blind retry.
        item.results[proposalId]=`uncertain`;
      }
      publish();
    }
    item.state=Object.values(item.results).every(v=>v===`confirmed`)?`confirmed`:`uncertain`;
    publish();
    if(typeof refresh===`function`)try{await refresh()}catch{}
  }
  function schedule(item){
    if(!runner||!ready||item.state!==`pending`)return;
    clearTimeout(timers.get(item.id));
    timers.set(item.id,setTimeout(()=>{timers.delete(item.id);void send(item.id)},Math.max(0,item.deadline-Date.now())));
  }
  function bind(sendMutation,refetch){runner=sendMutation;refresh=refetch;}
  function reconcile(pendingIds){
    if(!(pendingIds instanceof Set))return;
    ready=true;
    for(const item of entries){
      if(item.state===`pending`){
        // On reload, only still-pending server IDs can be dispatched.
        if(item.ids.some(id=>!pendingIds.has(id))){item.state=`uncertain`;}
        else if(item.deadline<=Date.now()){item.state=`uncertain`;}
        else schedule(item);
      } else if(item.state===`uncertain` && item.ids.every(id=>!pendingIds.has(id))){
        item.state=`confirmed`;
      }
    }
    publish();
  }
  function dispose(id){
    const item=entries.find(e=>e.id===id);
    if(!item||item.state===`pending`||item.state===`sending`)return false;
    entries=entries.filter(e=>e.id!==id);publish();return true;
  }
  return {snapshot,subscribe,stage,undo,bind,reconcile,dispose,reserved};
})();
'''
rep('function F() {',service+'\nfunction F() {')
rep('''    [E, O] = (0, k.useState)(null),''','''    [ledger, setLedger] = (0, k.useState)(()=>lemmaDecisionLedger.snapshot()),''')
rep('''    J = t.isPending || n.isPending || !!E;''','''    J = t.isPending || n.isPending;''')
start='''  let Y = e.data ?? [],'''
# Bind only when user has loaded pending data; no auto-resend of expired restored decisions.
rep(start,'''  (0,k.useEffect)(()=>lemmaDecisionLedger.subscribe(setLedger),[]);
  (0,k.useEffect)(()=>{
    lemmaDecisionLedger.bind(async(item,id)=>{
      if(item.action===`approve`) await t.mutateAsync(item.edit ? {id,edit:item.edit} : {id});
      else await n.mutateAsync(id);
    },()=>e.refetch());
  },[t.mutateAsync,n.mutateAsync,e.refetch]);
  (0,k.useEffect)(()=>{
    if(!e.isLoading && !e.isError && Array.isArray(e.data))
      lemmaDecisionLedger.reconcile(new Set(e.data.map(p=>p.id)));
  },[e.isLoading,e.isError,e.data]);
  let Y = e.data ?? [],''')
rep('''    X = Y.filter((e) => e.kind === `card` || e.kind === `card_edit`),
    Z = Y.filter((e) => e.kind === `plan` || e.kind === `plan_change`),''','''    serverCardCount=Y.filter(e=>e.kind===`card`||e.kind===`card_edit`).length,
    serverPlanCount=Y.filter(e=>e.kind===`plan`||e.kind===`plan_change`).length,
    reservedIds=lemmaDecisionLedger.reserved(),
    X = Y.filter((e) => (e.kind === `card` || e.kind === `card_edit`) && !reservedIds.has(e.id)),
    Z = Y.filter((e) => (e.kind === `plan` || e.kind === `plan_change`) && !reservedIds.has(e.id)),''')
start=s.index('  (0, k.useEffect)(() => {\n    if (!E) return;')
end=s.index('  return (0, N.jsxs)(m, {',start)
replacement='''  // Individual and batch decisions use the same reversible queue.
  const $ = (proposal,approve,edit) => {
    if(!proposal || J)return;
    const idx=X.findIndex(p=>p.id===proposal.id);
    const action=lemmaDecisionLedger.stage({ids:[proposal.id],projectSlug:proposal.projectSlug,
      action:approve?`approve`:`reject`,edit:edit??null,
      label:(approve?`Approve `:`Reject `)+(proposal.kind===`card`?`card`:`proposal`)+` · `+P(proposal.projectSlug),
      previous:proposal.id});
    if(!action){a(`A decision for this item already awaits saving or status verification`,{tone:`danger`});return}
    const next=X[idx+1]??X[idx-1];
    F(next?.id??null);L(Math.floor(Math.max(0,idx+1<X.length?idx+1:idx-1)/20));
    V(false);ue(v=>v+1);a(`Decision staged · Undo within six seconds`);
  };
  const stageBatch=group=>{
    if(!group || J)return;
    const proposals=group.proposals.filter(p=>p.kind===`card` && !lemmaDecisionLedger.reserved().has(p.id));
    const ids=proposals.map(p=>p.id);
    if(!ids.length){a(`No available cards remain in this batch`,{tone:`danger`});return}
    const action=lemmaDecisionLedger.stage({ids,projectSlug:group.project,action:`approve`,
      label:P(group.project)+` · `+group.label,previous:Q?.id});
    if(action){F(null);w(null);B(false);a(`${action.ids.length} cards staged · Undo within six seconds`)}
  };
'''
s=s[:start]+replacement+s[end:]
# top ledger showing pending and uncertain with Undo; confirmed hidden, provide dismiss for uncertain manual only.
start=s.index('      E &&\n        (0, N.jsxs)(`div`, {')
end=s.index('      e.isLoading',start)
replacement='''      ledger.filter(item=>item.state!==`confirmed`).length>0 &&
        (0,N.jsxs)(`section`,{
          className:`flex flex-col gap-2 rounded-ctl border border-edge bg-[var(--paper)] p-3`,
          "aria-label":`Decision status and Undo`,
          children:[
            (0,N.jsx)(`p`,{className:`text-label font-semibold text-ink`,children:
              `${X.length+Z.length} to inspect · ${ledger.filter(r=>r.state===`pending`).reduce((v,r)=>v+r.ids.length,0)} awaiting save · ${ledger.filter(r=>r.state===`uncertain`).length} need status check`}),
            ...ledger.filter(item=>item.state!==`confirmed`).map(item=>(0,N.jsxs)(`div`,{
              className:`flex min-h-11 flex-wrap items-center gap-2 border-t border-edge pt-2 text-label text-ink-2`,
              children:[
                (0,N.jsx)(`span`,{className:`min-w-0 flex-1 break-words`,children:
                  `${item.label} · ${item.ids.length} item${item.ids.length===1?``:`s`} · `+
                  (item.state===`pending`?`Awaiting save (6 s Undo window)`:
                   item.state===`sending`?`Sending…`:
                   `Needs status check · ${Object.values(item.results??{}).filter(v=>v===`confirmed`).length} confirmed`)}),
                item.state===`pending` && (0,N.jsx)(`button`,{
                  type:`button`,className:`min-h-11 rounded-ctl border border-edge px-3 font-semibold text-ink`,
                  onClick:()=>{const before=lemmaDecisionLedger.undo(item.id);if(before){F(before.previous??null);a(`Decision cancelled before save`)}},children:`Undo`
                }),
                item.state===`uncertain` && (0,N.jsx)(`button`,{
                  type:`button`,className:`min-h-11 rounded-ctl border border-edge px-3 font-semibold text-ink`,
                  onClick:()=>void e.refetch(),children:`Refresh status`
                }),
              ],
            },item.id))
          ],
        }),
'''
s=s[:start]+replacement+s[end:]
rep('''          { value: `cards`, label: `Cards`, count: X.length },
          { value: `plan`, label: `Plan`, count: Z.length },''','''          { value: `cards`, label: `Cards`, count: serverCardCount },
          { value: `plan`, label: `Plan`, count: serverPlanCount },''')
# Disable drag-triggered decisions: buttons remain the reliable action surface.
rep('''    drag: !t && `x`,''','''    drag: !1,''')
rep('''    "aria-label": `Proposal card, swipe right to approve or left to reject`,''','''    "aria-label": `Proposal card, use the labeled Approve or Reject buttons below`,''')
# Batch button uses queue rather than component-local timeout.
rep('''                    (O({
                      ids: l.proposals
                        .filter((e) => e.kind === `card`)
                        .map((e) => e.id),
                      label: P(l.project) + ` · ` + l.label,
                    }),
                    w(null),
                    B(!1));''','''                    stageBatch(l);''')
p.write_text(s)
print('W16 ledger implemented',len(s))
