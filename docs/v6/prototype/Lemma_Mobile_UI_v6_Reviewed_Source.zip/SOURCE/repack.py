#!/usr/bin/env python3
"""Deterministic offline packer and integrity verifier for the standalone Lemma UI.

Work only from the immutable uploaded HTML and detached editable module copies.
The verify command checks output bytes, source hashes, module contents, import
identifiers/order, and inline patches; it never modifies the source or output.
"""
import argparse
import base64
import gzip
import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent
ORIGINAL = ROOT.parent / '01_Original_Unmodified.html'
OUTPUT = ROOT.parent / 'Lemma_UI_Implemented.html'
MANIFEST = ROOT / 'manifest.json'
MODULES = ROOT / 'modules'
PATCHES = ROOT / 'inline-patches.json'
PATTERN = r'(<script id="lemma-packed-modules" type="application/octet-stream">)(.*?)(</script>)'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_payload(html):
    match = re.search(PATTERN, html, re.S)
    if match is None:
        raise ValueError('Embedded module payload is missing')
    return json.loads(gzip.decompress(base64.b64decode(match.group(2))))


def read_sources(allow_missing=False):
    original_bytes = ORIGINAL.read_bytes()
    original = read_payload(original_bytes.decode('utf-8'))
    manifest = json.loads(MANIFEST.read_text('utf-8'))
    if manifest['source_sha256'] != sha256(original_bytes):
        raise ValueError('Immutable original HTML differs from recorded manifest SHA-256')
    entries = manifest['imports']
    if [entry['id'] for entry in entries] != list(original):
        raise ValueError('Import IDs or order differ from original')
    for entry in entries:
        if sha256(original[entry['id']].encode('utf-8')) != entry['sha256']:
            raise ValueError('Original module differs from recorded baseline: '+entry['id'])
    modules = {}
    for entry in entries:
        path = MODULES / entry['filename']
        if path.exists():
            modules[entry['id']] = path.read_text('utf-8')
        elif allow_missing:
            modules[entry['id']] = original[entry['id']]
        else:
            raise ValueError('Missing editable module: ' + str(path))
    return original_bytes.decode('utf-8'), original, modules


def render(source_html, modules):
    compressed = bytearray(gzip.compress(
        json.dumps(modules, ensure_ascii=False, separators=(',', ':')).encode('utf-8'),
        mtime=0, compresslevel=9,
    ))
    compressed[9] = 255
    embedded = base64.b64encode(compressed).decode('ascii')
    output, count = re.subn(PATTERN, lambda match: match.group(1)+embedded+match.group(3), source_html, count=1, flags=re.S)
    if count != 1:
        raise ValueError('Unable to replace packed module payload')
    if PATCHES.exists():
        patches = json.loads(PATCHES.read_text('utf-8'))
        for patch in patches:
            old = patch['old']
            if 'source_file' in patch:
                # Source-owned helper: keep the editable file as the authority,
                # rather than retaining an independently mutable JSON duplicate.
                helper = (ROOT / patch['source_file']).resolve()
                if ROOT.resolve() not in helper.parents or not helper.is_file():
                    raise ValueError('Invalid editable inline source path: ' + str(helper))
                new = '\n' + helper.read_text('utf-8') + '\n' + old
            else:
                new = patch['new']
            matches = output.count(old)
            if matches != 1:
                raise ValueError(f'Expected one occurrence of inline patch anchor, found {matches}: {old[:100]}')
            output = output.replace(old, new, 1)
    output = output.replace(
        'content="Audit revision 2 · 30 findings addressed · 2026-11-02"',
        'content="Mobile UI redesign · example workspace · see DESIGN_HANDOFF.md for validation limits · 2026-11-04"', 1,
    )
    output = output.replace(
        '<!-- Original Lemma GitHub Pages build, all JavaScript chunks embedded as import-map modules, original CSS retained, demo mode enabled. -->',
        '<!-- Standalone Lemma audit remediation build; all existing embedded imports and offline demo retained. Generated from immutable uploaded source. -->', 1,
    )
    for owner in (ROOT / 'owners').glob('*'):
        if owner.suffix == '.css':
            pattern = r'(<style id="lemma-consolidated-design-system">)(.*?)(</style>)'
        elif owner.suffix == '.js':
            pattern = r'(<script id="' + re.escape(owner.stem) + r'"[^>]*>)(.*?)(</script>)'
        else:
            continue
        owned_source = owner.read_text('utf-8')
        if owner.stem == 'lemma-native-calendar-runtime':
            owned_source = owned_source.replace('__LEMMA_CALENDAR_CSS__', json.dumps((ROOT / 'styles/calendar.css').read_text('utf-8'), ensure_ascii=False))
        output, count = re.subn(pattern, lambda m: m.group(1)+owned_source+m.group(3), output, count=1, flags=re.S)
        if count != 1: raise ValueError('Missing owner anchor: '+str(owner))
    if read_payload(output) != modules:
        raise ValueError('Repacked modules differ from editable modules')
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['unpack', 'pack', 'verify'])
    operation = parser.parse_args().operation
    source, original, modules = read_sources(allow_missing=operation == 'unpack')
    if operation == 'unpack':
        # Safeguard modified working copies: unpack is allowed only if the
        # module directory is pristine or empty, never if edits exist.
        touched = [key for key in original if modules[key] != original[key]]
        if touched:
            raise ValueError('Refusing to overwrite '+str(len(touched))+' edited source modules')
        MODULES.mkdir(exist_ok=True)
        for entry in json.loads(MANIFEST.read_text('utf-8'))['imports']:
            (MODULES / entry['filename']).write_text(original[entry['id']], encoding='utf-8')
        print('Unpacked pristine editable source of', len(modules), 'modules')
        return
    expected = render(source, modules)
    if operation == 'pack':
        OUTPUT.write_text(expected, encoding='utf-8')
        print('Generated', OUTPUT, len(expected), 'characters;', len(modules), 'modules; SHA-256',sha256(expected.encode('utf-8')))
        return
    if not OUTPUT.exists():
        raise ValueError('Built HTML is missing')
    result_bytes = OUTPUT.read_bytes()
    if result_bytes != expected.encode('utf-8'):
        raise ValueError('Built HTML is not the deterministic output of the current source modules and patches')
    changed = [key for key in original if original[key] != modules[key]]
    print('Verified byte-for-byte reproducible build;',len(modules),'imports;',len(changed),'modified modules; SHA-256',sha256(result_bytes))


if __name__ == '__main__':
    main()
