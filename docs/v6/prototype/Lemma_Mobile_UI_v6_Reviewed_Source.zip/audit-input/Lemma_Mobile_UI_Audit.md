# Lemma: Mobile UI/UX Audit

**Subject:** `Lemma_Mobile_UI.html` (Lemma, "Your study notebook"). Mobile redesign mockup, example workspace, source commit `87997854…`
**Audit date:** 4 November 2026
**Primary viewport:** 390 × 844 CSS px (iPhone 14/15/16-class, touch, `isMobile`). Also tested at 320 × 568 (small phone), 844 × 390 (landscape), root text at 200% (large-text users) and in the Night theme.
**Method:** I drove the mockup in a real Chromium browser with Playwright. I opened every route, tab, sheet, dialog, expander and form, and screenshotted each one top to bottom with scroll steps of no more than 700 px, including inner scroll areas inside sheets. I added automated measurements (contrast, target size, accessible names, focus visibility, overflow) and checked the results against current platform guidance and research (WCAG 2.2, Apple HIG and iOS 26, Material 3 Expressive, Android 14–16, NN/g, Baymard, FSRS).

> Screenshots referenced below are in `screens/` next to this file (figures **F1–F15**).

---

## 1. Executive summary

Lemma's visual design is strong. It has a calm, editorial "notebook" voice (Newsreader with Instrument Sans), a disciplined navy-on-paper palette that passes contrast in both themes, generous 44 px+ targets on almost every core screen, real modal semantics, and a thumb-reachable review flow. It reads as a crafted product, not a template.

The **experience** is weaker than the **look**. The problems cluster in five areas:

1. **The app disagrees with itself about the facts that matter most.** "How long did I study today?" gets four different answers on four screens (0 min, 5 h 15 min, 12 h 20 min, and 12,920 h over 30 days). Some views go stale after actions: after *Finish & log*, Today still says *"In focus · remaining 50:00"* and *"0 min logged today"*. A study tracker that can't be trusted on time studied fails at its core job.
2. **Feedback doesn't reach the user.** In the Calendar module, confirmation and *Undo* toasts render 1,700–2,600 px below the visible screen (a `position: fixed` element trapped in a transformed container). A newly added task is appended as item 354 of a 12-item paged list, so it never appears. Deleting a calendar block happens instantly, and its only safety net (Undo) is off-screen.
3. **Two design systems are stitched together.** The Calendar/planner module (a shadow-DOM web component) uses **red as its primary "Save" colour**, while the core app uses navy for primary actions and red for danger. On the card screen *Delete* is navy. Error styles, list paging, toggles, sheet headers and wording also differ between the two halves.
4. **It doesn't survive phone realities.** At the 200% font scale that Android 14+ users can choose, labels break mid-word ("Toda/y", "Calen/dar"), headers collide, and fixed chrome takes about a third of the screen. In landscape, the mini-timer and tab bar leave about 150 px for content.
5. **Overload instead of guidance.** "Plan my day" opens with 283 pre-checked tasks. Auto-plan renders a list about 19,000 px tall inside a sheet. "Close my day" pre-checks 70+ carry-overs. The Calendar tab puts about 600 px of controls before the first event.

**Overall rating: 3.0 / 5** (visual craft 4.5, accessibility foundations 4, information integrity 1.5, mobile ergonomics 3, consistency 2.5).

### Top 10 fixes, in order of impact

| # | Fix | Severity | Effort |
|---|---|---|---|
| 1 | One source of truth for logged time, session state and counts; recompute every surface after each action (X1) | Critical | M |
| 2 | Re-anchor all Calendar-module toasts to the viewport, above the tab bar (X3) | Critical | S |
| 3 | After *Save task* / *Add block*, show the new item in place (scroll to it and highlight it) (§7) | Critical | S |
| 4 | Make colour roles global: navy = primary, red = destructive only (X2) | High | S |
| 5 | Action toasts persist until dismissed (or ≥ 20 s, extended on focus); undo for all reversible deletes (X10) | High | S |
| 6 | Fix text scaling: rem/clamp sizing, no mid-word breaks, collapse chrome at large text (X4) | High | M |
| 7 | Replace opt-out mega-lists with "suggested 3–5 + add more" (X7) | High | M |
| 8 | Calendar: lead with the schedule, move controls into one toolbar and sheet, mobile day view first (§6.9) | High | M |
| 9 | Merge the two component systems (forms, errors, toggles, paging, headers) (X6) | High | L |
| 10 | Mini-timer as a tab-bar accessory, plus a system Live Activity / Live Update (X5) | Medium | M |

---

## 2. Scope, method and limitations

### 2.1 Coverage
Every route in the router and every reachable sub-view was opened and scrolled end to end (see **Appendix B** for the checklist). In total that was roughly **25 routes and views, 40+ sheets and dialogs, a dozen-plus expanders and 9 complete flows**, captured as several hundred screenshots.

Flows exercised end to end: add task (empty submit, invalid estimate, valid save, undo), add/edit/delete calendar block, plan my day (3 steps and preview), close my day, auto-plan, work backwards from a deadline, topic recall, focus (pause, break, finish and log), review (start, confidence, reveal, grade, close, summary, redo missed), inbox approve/reject/edit with undo, new card, delete card, new project, project actions, archive view, search with empty results, and pagination.

### 2.2 Automated checks
- WCAG 1.4.3 text contrast, computed against the actual blended background for every visible text node at every scroll step, in Day and Night themes, across 12 routes plus overlays.
- Target size (WCAG 2.5.8 at 24 px, and the platform 44/48 px guidance).
- Accessible names on all interactive elements, including inside shadow DOM.
- WCAG 2.4.11 Focus Not Obscured: tabbed through 32–53 focusable elements per screen and checked against the fixed bottom chrome.
- Horizontal overflow at 320 px, 200% text and landscape.
- Modal semantics, focus containment, Escape handling, scroll locking.
- Platform CSS features: safe-area insets, reduced motion, dynamic viewport units, `inputmode` and `enterkeyhint`.

### 2.3 Limitations, stated plainly
- **Fonts.** The file loads Google Fonts, which the test sandbox can't reach. I served the identical families (Newsreader, Instrument Sans, STIX Two Text, IBM Plex Mono) from the official `google/fonts` repository, so typography renders as designed.
- **Stress fixtures.** The demo workspace is seeded with stress data ("Stress Project 59", card #30000, 4,000 due). I separate *design* problems (for example, two screens computing the same metric differently) from *fixture* artefacts. Where a fixture value is impossible (12,920 h in 30 days), I still flag the missing **guardrail**: real sync bugs produce the same outputs.
- **Clipboard.** Under `file://` the Clipboard API is unavailable, so *Copy study prompt* shows a manual-copy fallback. In production over HTTPS it should copy directly. Not counted as a defect.
- **Gestures.** Swipe-to-dismiss on sheets was tested with emulated touch events and did not dismiss. Confirm on a physical device before acting on it.
- Native wrappers (haptics, notifications, widgets) are shown only as previews in this build and were assessed as concepts.

### 2.4 Severity scale
- **Critical:** misinforms the user or makes a core task fail silently. Fix before any release.
- **High:** a frequent friction or accessibility barrier with a clear workaround cost.
- **Medium:** inconsistency or inefficiency that erodes trust or speed.
- **Low:** polish.

---

## 3. Scorecard

| Area | Score | Notes |
|---|---|---|
| Visual craft and brand | ★★★★½ | Distinctive, calm, coherent typography. Math rendering is excellent (KaTeX + STIX). |
| Accessibility foundations | ★★★★ | Contrast passes almost everywhere. ≥ 44 px targets in core. Real dialogs. Focus not obscured. 16 px inputs. Zoom allowed. |
| Information integrity | ★½ | Contradictory metrics, stale state, impossible values without guardrails. |
| Feedback and error recovery | ★★ | Undo exists but is off-screen or too short. Errors vary by module. Silent saves. |
| Mobile ergonomics | ★★★ | Review run is excellent. Calendar, large text and landscape are poor. |
| Consistency | ★★½ | Two component systems, inverted colour semantics, three paging patterns, mixed time formats. |
| Information architecture | ★★★ | Clear 5-tab model. Overflow "Menu" hides Concept map, Inbox and Settings inconsistently. Some features unreachable. |
| Cognitive load | ★★½ | Opt-out mega-lists, jargon ("planet/moon", "timer guard", "estimate ×1.3"), whimsical headings that hide function. |

---

## 4. What's working (keep these)

- **Review run is genuinely mobile-first** (F9). The tab bar is hidden, *Show answer* and the four grade buttons sit in the thumb zone, grades pair colour with symbol and text (× ~ ✓ ✓✓) and show the next interval ("10 min / 1 mo / 1.5 mo / 2.1 mo"), long cards get a "More below ↓" cue, and the summary offers "Go over the 1 missed". This is the best screen in the product.
- **Accessibility groundwork is real.** Text contrast passes WCAG AA in both themes on all 12 main routes (one exception, Appendix A). Core targets are ≥ 44 × 44. Sheets use `role="dialog"` + `aria-modal`, contain focus and lock background scroll. Calendar dialogs use native `showModal()` and close on Escape. Inputs are 16 px, which prevents iOS focus-zoom. The viewport doesn't block pinch-zoom. Safe-area and `prefers-reduced-motion` are handled. Tabbing never leaves the focused control hidden under the sticky bars (WCAG 2.4.11 pass on every screen tested).
- **Inbox decisions are staged with undo**, the right model for reversible approvals (but see X10 for timing).
- **Card deletion uses a confirmation sheet** with a clear consequence statement.
- **Honest copy in places users need it.** "Catch-up estimate: 121 more sessions after today at 33 cards each" is exemplary expectation-setting. "Tune to my reviews" is disabled with a reason ("requires 400 eligible").
- **The Night theme** is properly designed, not inverted: separate tokens, contrast maintained (F15).
- **Empty states exist** for search, archive, filters and paused projects, each with a recovery action ("Clear", "Clear filters").

---

## 5. Cross-cutting findings

### X1 · Contradictory sources of truth and stale state (Critical)
![F3 · Four answers to “how long did I study today?”](screens/F03_state_truth.png)

**Evidence (F3, F10, F11)**

| Metric | Screen A | Screen B | Screen C | Screen D |
|---|---|---|---|---|
| Logged today | Today: **0 min** | Calendar › Day details: **5 h 15 min** | Close my day: **12 h 20 min** | Progress 30 d: **12,920 h** (> 720 h in 30 days) |
| Session state after *Finish & log* | Focus: "Ready to start 50:00" | Today hero: **"In focus · remaining 50:00"** | Toast: "Study time saved to your log" | Today: still "0 min logged today" |
| Cards due | Review: **33 for today** (4,000 queued) | Project › Topology: **0 cards due** | Review summary: **0 due tomorrow** | |
| Topology progress | Project: "Current checkpoint: **on time**" | Same card: "Goal forecast: **34 days after target**" | Checkpoint sheet: "expected 5 Nov: on time" | |
| Tutor sessions | Project chip: **28 tutor sessions** | Sessions tab: **1000** | Session 991 tagged **CP19** while path is at CP2 | |
| Backlog | Tools sheet: **283 tasks waiting** | Backlog: "Showing 12 of **353**" (includes 70 completed, interleaved) | | |
| Day capacity | Day details: **26 h 45 min of blocks** in one day | "25 blocks overlap" | | |

**Why it matters.** Study apps live on self-monitoring. When numbers disagree, learners stop trusting the plan and the app becomes a guilt generator. Contradictory status ("on time" next to "34 days late") is the worst case: it leaves the user to work out which number is true.

**Fix.**
1. Make one selector per domain metric (`loggedToday`, `sessionState`, `dueNow`, `pathStatus`) consumed by every surface, with subscription-based re-render after any mutation (finish, log, grade, delete).
2. Define each metric once in a glossary and use the same label everywhere ("Logged today", "Due now", "Due today").
3. Add **sanity guardrails**: clamp per-day time at 24 h and flag overlaps, and show "Check your log" instead of an impossible total.
4. Collapse dual statuses into one verdict with a cause: "Behind by 34 days. CP2 on time, later stages slipping."

### X2 · Colour semantics inverted between modules (High)
![F2 · Colour semantics](screens/F02_color_semantics.png)

**Evidence (F2).**
- Calendar module: *Save task*, *Add to calendar*, *Save changes*, *Place what fits*, *Add deadline*, *Continue* are all **red** (`rgb(185,47,38)`, coral in Night). On *Edit time block*, **Save is red and Delete is neutral**.
- Card detail: the destructive **Delete card** button is **navy** (the primary style).
- Component kit: **Reject** is styled as a filled primary, identical to *Start*.
- Month view marks *today* with a red disc. Calendar "Due today" and "25 blocks overlap" use amber.

**Research.** Apple's HIG says to *"assign the primary role to nondestructive buttons"* and shows destructive actions in system red. Google's Material 3 Expressive studies (46 studies, 18,000+ participants) found that consistent emphasis through colour, size and containment helped people find key actions up to 4× faster, and closed the age gap in spotting them. Inconsistent colour roles throw that benefit away and invite mis-taps on destructive actions.

**Fix.** Define three global role tokens and apply them in both systems: `--action-primary` (navy / light-blue in Night), `--action-destructive` (red, used only for delete, remove, reject, sign out), `--status-warning` (amber). Destructive actions should be text or outlined red, never the most prominent button unless the whole sheet exists to confirm deletion. Use the accent or a ring for "today", not error red.

### X3 · Feedback rendered off-screen (Critical)
**Evidence (F1).** After *Save task*, the "Task saved · Undo" toast is `position: fixed` but sits **1,773 px** from the top of the viewport. After deleting a block, "Block removed · Undo" sits at **2,578 px**. The cause is a fixed element inside a transformed or contained ancestor in the calendar web component, so "fixed" becomes relative to that container. In the core app, the *Finish & log* toast lands mid-screen over a list row.

**Fix.** Render toasts through a single top-level portal (outside the shadow root), anchored to `bottom: calc(tabbar + mini-timer + 8px + env(safe-area-inset-bottom))`, with `role="status"`. Then add an automated check that every toast's rect intersects the viewport.

### X4 · Large text and reflow break the layout (High)
![F4 · 200% text](screens/F04_text200.png)

**Evidence (F4).** With root text at 200%:
- Tab labels split mid-word ("Toda/y", "Revie/w", "Calen/dar", "Progr/ess").
- The page title "Pat/hs" and "Revie/w" wrap per letter group.
- The Calendar header overlaps ("Calend[Add]").
- The Inbox card body *doesn't* scale (fixed px) while the chrome does.
- The mini-timer becomes three lines.
- Fixed chrome consumes about 30% of the screen.

**Research.** Android 14 raised the system font scale to 200% with a nonlinear curve and tells developers to test at the maximum. iOS Dynamic Type accessibility sizes go further. Users who set these are exactly the ones a dense study tool most needs to keep.

**Fix.**
- Size type in `rem` with `clamp()` and a capped scale for display headings.
- Never `overflow-wrap: anywhere` on short labels: use `hyphens: manual` and let tab labels drop to icon + tooltip, or truncate with an accessible name.
- At large text, switch the tab bar to icons only (with labels kept in `aria-label`), collapse the mini-timer into the tab-bar accessory (X5), and let headers wrap their actions below the title.
- Include 200% text and 320 px width in visual regression tests.

### X5 · The fixed-chrome budget (Medium; High in landscape)
![F5 · Landscape](screens/F05_landscape.png)

**Evidence (F5, F12).** On every tab except Today, the mini-timer (≈ 60 px) plus the tab bar (≈ 64 px) take ≈ 125 px, or 15% of an 844 px screen and 22% of 568 px. In landscape (390 px tall) only ≈ 150 px of content remains. The mini-timer also appears on **Sign in**, before the user exists.

**Research.** iOS 26 tab bars can **minimize on scroll** and host an **accessory view above the tab bar** that moves next to the minimized bar. That is exactly a now-playing / running-timer slot. Android 16 introduced **Live Updates** (progress-centric notifications) for ongoing activities. A running focus timer is the canonical case.

**Fix.**
- Treat the timer as a tab-bar accessory that collapses into the minimized bar on scroll-down.
- Hide all chrome in landscape except a slim timer pill.
- In the native wrappers, mirror the session as an iOS Live Activity and an Android Live Update so the in-app bar can shrink.
- Never render session UI when signed out.

### X6 · Two component systems (High)
The core app (React/Tailwind) and the Calendar/planner module (`<lemma-native-calendar>`, shadow DOM) diverge:

| Pattern | Core app | Calendar module |
|---|---|---|
| Primary colour | Navy | Red (X2) |
| Field error | — (disabled Create button + hint) | *New task*: grey sentence at bottom, no field link. *Add block*: red outline only, no text |
| Toggle | Switch (Review › Mix decks) | "On / Off" pill buttons (Settings), checkbox (Add block) |
| More items | "Load 50 more" (Cards), "Next page / Page 1 of 4" (Paths), "Show more · 2457 remaining" (Atlas) | "Show 12 more" (Backlog), "Showing 8 of 162" (Deadlines) |
| Sheet titles | Functional ("New project", "Switch project") | Poetic ("A date on the horizon.", "Start from the horizon.", "A small beginning.", "Recall before you look.", "Calendar, in the margin.") |
| Time format | 24 h ("06:51–07:41") | 12 h with zone ("07:36 AM GMT+5:30") in Conflicts; 12 h inputs even when *Clock = 24h* |
| Eyebrow text | 12 px | 11 px ("PLAN YOUR DAY", "CALENDAR · NOV 4") |

**Fix.** Port the calendar module onto the core tokens and components (or expose them as CSS custom properties through the shadow boundary). Keep one Field component (label, hint, inline error with `aria-describedby` and `aria-invalid`), one Toggle, one List-paging pattern and one Sheet header. Poetic headings can stay as **sub-titles** under a functional title ("New deadline", subtitle "A date on the horizon").

### X7 · Opt-out mega-lists and unbounded modals (High)
![F7 · Mega-lists](screens/F07_overload.png)

**Evidence (F7).**
- *Plan my day* step 1 shows **283 pre-checked tasks** (≈ 22,000 px scroll) under the prompt "Choose what matters today".
- *Auto-plan* preview lists every backlog item (≈ 19,000 px) with no fits / doesn't-fit summary.
- *Close my day* pre-checks every carry-over.
- *Topic reviews* duplicate the card-review concept with a separate 3-point scale.

**Why it matters.** Pre-selection plus volume is a default effect working against the user's stated goal (a "realistic day"). Nobody reviews 283 checkboxes on a phone, so they accept an impossible plan.

**Fix.**
- Step 1: show the **top 3–5 suggestions** ranked by deadline, priority and fit for today's capacity, plus "Add from backlog…" (search sheet).
- Auto-plan: lead with a summary ("Fits: 6 tasks · 4 h 10 m. Doesn't fit: 277 → stays in backlog") and an expandable detail.
- Close my day: default to **unchecked** carry-overs, with a single "Carry everything" bulk action.
- Long-form content belongs in a full-screen view, not a sheet (eBay Playbook).

### X8 · Navigation model and duplicate entry points (Medium)
- **Global actions vary per screen.** Today shows Inbox and Settings as icons. Every other tab hides them under a text "Menu" button (a `<details>` element) along with Concept map. So on four of the five tabs, Inbox (599 waiting proposals) is two taps away, and no tab shows a pending-count badge.
- **Duplicates.** Calendar header *Tools* and in-page *Planning tools* open the same sheet. Header *+ Add* and in-page *+ Add block* open the same form. Focus view has both × and "Back to notebook".
- **Inconsistent naming.** "Concept map" is called "Atlas" on the map's back button ("Back to Atlas"). "Paths", "projects", "learning paths" and "subjects" are used interchangeably.
- **Fix.** Put a consistent top-right cluster on every tab (Inbox with badge, overflow), remove in-page duplicates, and pick one noun per concept.

### X9 · Jargon and naming that leaks implementation (Medium)
Examples:
- Concept types "cluster / system / galaxy / planet / moon" on every row.
- "Estimate ×1.3", "Timer guard · hours", "Long-running guard", "Gap · minutes".
- "Carrel live mirror", the internal codename visible in Connected calendars.
- Raw enums on New card: Type "basic", Kind "other".
- Accessible names "stress-t-149" on Close-my-day checkboxes.
- "Stability 14 d / Recall now 90%" with no explanation.
- "Focus 2 of 4 · 50/10".
- Grammar slips: "1 children", "1 local calendar days".
- Atlas header says 2,500 concepts while the list says 2,537 match.
- Atlas sorts lexically ("Idea 100, Idea 1000, Idea 1001").

**Fix.** Plain labels with optional info pop-overs. Hide astronomical metaphors behind the map legend. Natural sort. Pluralization helpers. A content-design pass with a glossary.

### X10 · Undo, confirmation and timing (High)
| Action | Current | Problem |
|---|---|---|
| Delete calendar block | Immediate, Undo toast off-screen | No visible recovery |
| Remove task | Immediate (same toast system) | Same |
| Approve/Reject proposal | "Undo within six seconds", toasts stack over content | 6 s is short for screen-reader, switch and motor-impaired users |
| Delete card | Confirmation sheet, navy *Delete* | OK pattern, wrong colour |
| Close review after 1 card | Treated as completion → "Q.E.D." | Interruption is celebrated as completion |

**Research.** WCAG 2.2.1 uses **20 seconds** as the benchmark reaction time when content imposes a time limit. Material 3–aligned frameworks now default snackbars **with an action to not auto-dismiss** (Flutter 3.38). Angular Material advises against giving action snack-bars a duration so screen-reader users can reach the action. UX consensus is to prefer undo for reversible actions and reserve confirmation for irreversible ones.

**Fix.**
- Every reversible destructive action commits and shows a visible **persistent** Undo toast, with a single queue (no stacking) and batch undo for repeated approvals.
- Make the window ≥ 20 s or until the next navigation, and pause it while the toast has focus.
- Closing a review early should offer "Finish later (32 left)" and must not trigger the completion state.

### X11 · Orphaned and unreachable features (Medium)
The integrated "Day Margin" module ships complete pages for **Time log** (edit/split/export entries), **Attention** (noticed, drift, parked thoughts), **Insights** (focus, estimates, patterns, streak), **Coach**, **Android** and **Features**. Their routes (`#/carrel/log`, `#/carrel/distractions`, …) redirect to Today. Some panels link to them (for example, "You returned more quickly → /carrel/distractions"). Users therefore **cannot correct a wrong time entry**, which compounds X1.
**Fix.** Either expose the time log (Progress › Time › "Edit log") and attention tools (Focus view › "Noticed / Park a thought"), or remove the dead links and code.

### X12 · Bottom-sheet mechanics (Medium)
- Every sheet shows a **grab handle**, but emulated swipe-down didn't dismiss any sheet tested. A handle that doesn't drag is a false affordance. NN/g recommends supporting Back and the handle for dismissal.
- **Sheets launch sheets.** Planning tools › Backlog › New task › (Save) is fine, but Backlog › Find time opens the full *New time block* sheet over the tools context.
- Some sheets reach the top of the screen with no safe-area gap (Auto-plan, Conflicts).
- **Fix.** Implement drag-to-dismiss with velocity thresholds, honour the Android Back gesture, cap sheet height at about 90% with a top inset, and promote long or tall content to full-screen pages.

### X13 · Lists and paging (Low–Medium)
There are five patterns for "more items" (X6), plus nested scroll areas: the Cards list is a 60 dvh inner scroller inside the scrolling page, and the Day grid is a 420 px inner scroller below about 600 px of controls. Paths › *Next page* keeps the scroll position mid-list, so page 2 starts off-screen.
**Research.** Baymard's mobile testing found that "Load more" combined with lazy-loading performs better than numbered pagination.
**Fix.** Use one pattern (lazy-load 20 → "Load more" every ~60), with a single page scroll and no nested scroll areas on phones. Restore the scroll position on back.

### X14 · Assistive-technology semantics (Medium)
- `document.title` is "Lemma · Your study notebook" on every route. After navigation, focus stays on `<body>` and nothing announces the new view.
- Unnamed controls: Review (3 elements, including empty `<summary>`), Settings (4), Project (1), and one Day-grid button.
- Close-my-day checkboxes are named by internal IDs ("stress-t-149").
- Segmented filters (Active/Paused/Done, Path/Sessions/Sources) use `aria-pressed` buttons. Acceptable, but tabs (`role="tablist"`) would better express "one view at a time".
- **Fix.** Per-route titles ("Calendar · Lemma"), move focus to the new `<h1>` on route change, and name every control. Use `role="tab"` for view switchers.

---

## 6. Screen-by-screen audit

Each screen was captured at every scroll position. The **Covered** column lists states verified.

### 6.1 Today (`#/`) (F12)
![F12 · Today and Paths](screens/F12_today_paths.png)

Covered: default, after Finish & log, Night theme, 320 px, 200% text, landscape.

| Sev | Finding | Recommendation |
|---|---|---|
| Critical | After *Finish & log*, the hero still says "In focus · remaining 50:00" and "0 min logged today" doesn't change (X1). | Bind to the session store. Show "Ready · Topology CP2 · Start 50 min". |
| High | "0 min logged today" contradicts the Calendar, Close-my-day and Progress figures (X1). | Single selector. Show today's progress toward the 4 h intention (bar). |
| Medium | "A LITTLE FURTHER, EVERY DAY" eyebrow, "CURRENT SESSION" label and the τ watermark take three lines before the content. | Merge into one line. The watermark is decorative (`aria-hidden`), which is fine. |
| Medium | Today is the only tab without the mini-timer, which is right, but also the only tab with Inbox/Settings icons (X8). | Same header cluster on all tabs. |
| Low | The day's agenda (next block "20:00 Quotient topology") isn't on Today. Users must open Calendar. | Add a "Next up" row with *Start* (that's the student's real next action). |

### 6.2 Focus view (Return to focus / mini-timer) (F11)
![F11 · Focus](screens/F11_focus.png)

Covered: in focus, paused, break (09:59), after finish, close.

| Sev | Finding | Recommendation |
|---|---|---|
| High | *Finish & log* ends and logs immediately with no summary of what was logged ("28 min to Topology CP2") and no reflection, even though *Session reflection: On* is a setting. | Show a 1-step sheet: logged time (editable), optional 1–3 focus rating, *Save* / *Discard*. |
| Medium | "Focus 2 of 4 · 50/10" is cryptic. | "Pomodoro 2 of 4 · 50 min focus / 10 min break". |
| Medium | "Finish & log" and "Back to notebook" are 38 px tall (below the 44 px used elsewhere). "Back to notebook" duplicates ×. | 44 px. Drop the duplicate. |
| Low | The full-screen grid background adds noise behind the 96 px numerals. | Fade the grid behind the timer area. |

### 6.3 Paths (`#/projects`) (F12)
Covered: Active/Paused/Done, search with results and empty, group collapse, project actions sheet, archived view, pages 1→2, New project sheet.

| Sev | Finding | Recommendation |
|---|---|---|
| Medium | 100-segment progress bars ("3 of 100") read as texture, not progress. The current segment marker is a 2 px tick. | Continuous bar plus "3/100 · CP4 Compactness". Segments only when there are ≤ 12. |
| Medium | Numbered pagination ("Page 1 of 4 · 1–16 of 60 unpinned"). *Next page* doesn't scroll to the top. | Lazy-load (X13). |
| Medium | The search field has two clear buttons (native ✕ and custom ✕). | Hide the native `::-webkit-search-cancel-button`. |
| Medium | Archived view: the breadcrumb "Archive" label is clipped at the right edge. | Allow wrapping or truncation with ellipsis. |
| Medium | Actions sheet: *Archive* has the same styling as *Pin*. "Set active · already active" shows as a disabled tile. Tiles have uneven heights. | List-style action sheet with Archive in destructive style. Hide no-op actions. |
| Low | Every generic subject uses the same ∑ glyph. 30+ identical icons add no information. | Initials or colour chips per subject. |
| Low | The New project name field uses the same grey fill as disabled controls. "Create project" is disabled with a hint below. | Distinct enabled-input style. Keep the button enabled and validate inline (NN/g). |

### 6.4 Project detail (`#/p/:slug`), tabs, checkpoint sheet, session (F10)
![F10 · Project](screens/F10_project.png)

Covered: Path / Sessions (1000) / Sources (100) tabs, Switch project sheet, Copy study prompt, Explore timeline, Goal forecast, Stages accordion, CP2 checkpoint sheet, Session 991 (all 120 events, "More reasoning").

| Sev | Finding | Recommendation |
|---|---|---|
| Critical | "Current checkpoint: on time" sits next to "Goal forecast: 34 days after target" (X1). | One verdict with its cause. |
| High | "0 cards due", "28 tutor sessions" vs "Sessions 1000", and "0 h 0 min logged · 29 min in progress" contradict other screens (X1). | Shared selectors. Label scope ("for CP2" vs "all"). |
| Medium | The title "Topology ›" is also a project switcher: an unusual affordance for a page title. | Switcher as an explicit chip ("Switch") or in the overflow menu. |
| Medium | "Stages" heading is styled as a bordered card (looks tappable) next to a separate "Full path" expander and a "Current stage" select: three controls for one hierarchy. | One collapsible stage list with the current stage expanded. |
| Medium | Locked checkpoints and "Planned 13 Nov" are low-emphasis grey. They pass contrast, but the meaning ("locked", "up next") is carried by text alone at the far right. | Lock icon plus state chip next to the title. |
| Medium | Session page: 120 events of near-identical text ("Attempt 10: justify each inference…"). Hint groups collapse, but there's no summary of outcome. | Lead with outcome counts (demonstrated, partial, rechecked) and a timeline sparkline. Default-collapse repeats. |
| Low | The session is tagged CP19 while the path is at CP2 (fixture artefact, but there's no guard). | Validate checkpoint links. |

### 6.5 Concept map (`#/atlas`): list, concept detail, map (F8)
![F8 · Concept map](screens/F08_atlas.png)

Covered: List (full scroll, "Show more · 2457"), concept tap, detail panel, Map tab, Fit/zoom, subject expand, map key and keyboard help, Reset branches.

| Sev | Finding | Recommendation |
|---|---|---|
| Critical | Tapping a concept renders its detail **at the bottom of a ~6,000 px page**. Nothing visibly happens. | Open the detail as a sheet or push a page. Highlight the selected row. |
| High | Map nodes are 30 × 30 px and overlap each other. The WCAG 2.5.8 spacing exception can't apply, so the targets fail 24 px with spacing. Labels use a heavy outline and are hard to read. | Semantic zoom (subjects → clusters → concepts). Hit targets ≥ 44 px. A list alternative is already present, so make it the default on phones. |
| Medium | "cluster / system / galaxy / planet / moon" type labels on every row (X9). | Remove from rows. Explain in the map legend. |
| Medium | 2,500 vs 2,537 counts. Lexical sort ("Idea 100, Idea 1000"). | Single count. Natural sort. |
| Low | "Expand 1 children" (grammar). "Back to Atlas" (naming). | Fix copy. |

### 6.6 Review home (`#/review`), batch, decks, queue
Covered: home, Change batch sheet, Decks & options (Mix decks switch, 60 decks, Show 8 more), Queue details expanded (outlook, timer and calendar).

| Sev | Finding | Recommendation |
|---|---|---|
| Medium | Batch picker: the selected option (33 cards) is a grey fill that reads as disabled. | Checkmark plus accent border for the selection. |
| Medium | Deck rows show an unlabeled "67" and a chevron next to a checkbox (two targets in one row). | Label "67 due". Make the row toggle the checkbox, with the chevron as a separate 44 px target. |
| Low | The search icon (cards) sits on Review while Cards lives under "Search cards", a hidden IA path. | Name it "Card library". |

### 6.7 Review run (`#/review/run`) and summary (`#/review/done`) (F9)
![F9 · Review](screens/F09_review.png)

Covered: question (long and short card), optional confidence, reveal, all 4 grades, More menu, Close mid-session, summary with missed cards, "Go over the 1 missed".

| Sev | Finding | Recommendation |
|---|---|---|
| High | *Close* after 1 of 33 jumps to the celebratory "Q.E.D." summary (X10). | "Pause review? 32 left. Finish later." Celebrate only real completion. |
| Medium | Summary says "0 due tomorrow" while 4,000 are queued (X1). | Pull from the queue model. |
| Medium | The "More" menu includes "Scroll reading panel", a developer-ish command. | Rely on native scroll. Use the "More below ↓" cue (already present). |
| Medium | Grade semantics: under FSRS, *Hard* is a **pass**, and users commonly misuse it as a fail. The UI groups Again/Hard in one row and Good/Easy in another, which visually pairs Hard with Again. | Put **Again** apart (left, red) and *Hard/Good/Easy* as one passing group, or offer a 2-button (Again/Good) mode, which FSRS handles well. |
| Low | The subtitle is lower-case ("∫real analysis · CP1"), inconsistent with titles elsewhere. | Title case. |

### 6.8 Cards (`#/cards`), card detail, new card
Covered: filters (project, checkpoint, scheduling, status, has-notes chip and toggle), Load 50 more, empty results, New card sheet, card detail (edit, pause, delete confirm, tutor note).

| Sev | Finding | Recommendation |
|---|---|---|
| High | The list is a 60 dvh **inner scroller inside a scrolling page** (scroll trap on touch). Filters occupy ~half of the first screen (F14). | Single page scroll. Collapse filters into a "Filters (2)" button that opens a sheet. Active filters as removable chips. |
| Medium | "Has notes" exists as both a chip and a toggle. The toggle's grey fill reads as disabled. The chip row clips the first chip at the left ("lathematics project 60"). | One control. Reset the chip-row scroll on change. |
| Medium | Card detail actions are icon-only (pencil, ‖ pause, trash). ‖ is ambiguous (pause vs suspend). Delete is navy (X2). | Labelled actions in an overflow, or icon + text. Destructive red. |
| Medium | Memory panel: "Next 14 days / Stability 14 d / Recall now 90%". The units differ and the jargon is unexplained. | "Next review in 14 days · You'll likely recall it (90%)". Stability in an info pop-over. |
| Low | New card "Type: basic / Kind: other" (raw enums, two similar labels). | "Card type: Basic / Cloze". Drop or rename "Kind". |

### 6.9 Calendar (`#/calendar`) — Agenda, Day, Week, Month (F6)
![F6 · Calendar](screens/F06_calendar_density.png)

Covered: all 4 views at every scroll position, previous/today/next, Day details, Review conflicts, Due-today link, Earlier today, block tap → edit, delete, Menu, Tools.

| Sev | Finding | Recommendation |
|---|---|---|
| High | About **600 px of controls** (title, Tools, Add, Menu, date nav, View select, Add block, Planning tools, Due today, overlap banner, Day details) before the first event. On Day/Week, the time grid is a 420 px inner scroller starting below the fold. | Collapse into one toolbar row: ‹ date › · view switch (segmented) · ＋ (FAB or header). Put Due and Overlap as compact chips. Let the grid fill the viewport. |
| High | Day details is broken: the legend renders as "Logged Planned Busy26 h 45 min of blocks", with no chart and a > 24 h total (X1). | Fix the legend layout. Show a stacked day bar. Guard totals. |
| High | Review conflicts is a wall of text with "GMT+5:30" repeated on every line and no way to resolve anything (only *Close*). | Pairwise cards with *Move*, *Shorten*, *Keep both*. Local times without the zone suffix. |
| Medium | Duplicate entry points (*Tools*/*Planning tools*, *+ Add*/*+ Add block*) (X8). | One of each. |
| Medium | View switcher is a native `<select>` labelled "View". | Segmented control (Agenda · Day · Week · Month). |
| Medium | Day grid: time labels collide at the top ("06:00 06:1…"). 25-minute blocks are 35 px tall. Titles truncate to "Compac…". | Minimum block height of 44 px with overflow to a "+2" stack. Tap opens a details sheet. |
| Medium | Month view: the date and the block count are stacked in the same type ("2 / 22"), which is ambiguous. Today is shown as a red disc. Out-of-month days are 4.24:1. | Date top-left, count as a dot or bar. Accent ring for today. Contrast ≥ 4.5:1. |
| Medium | Tapping a planned block opens **Edit** directly. There's no read view with *Start session*, which is the most likely intent. | Details sheet: *Start focus*, *Edit*, *Move*, *Delete*. |
| Medium | Status encoding: dashed blue = planned, solid green = logged, thin grey = busy. Text is present, but border style is subtle at small sizes. | Add a status icon. |

### 6.10 Calendar › Planning tools sheet and sub-tools
Covered: Auto-plan; Backlog (list, search, check, Find time, Edit, Remove, New task, Show 12 more, Find time for all); Deadlines (list, search, New deadline, Work backwards); Topic reviews (list, Recall, rate, Edit topic, New topic); Daily rituals (Plan my day steps 1–3 and preview, Close my day); Day preferences; Connected calendars; Done.

| Sev | Finding | Recommendation |
|---|---|---|
| Critical | **Add task** flow (see §7). | — |
| High | Plan my day, Auto-plan and Close my day are opt-out mega-lists (X7). | Suggest 3–5 items. Lead with a summary. |
| High | All primary buttons are red (X2). | Navy. |
| Medium | Work backwards: "4h across 1 local calendar days before 2026-11-06 … 180 min per day … capped at 3h/day". The math doesn't fit (240 > 180) and the overflow isn't reported. The copy mixes ISO and long dates. | "Needs 4 h; only 3 h fit before Fri 6 Nov. Add 1 h on Thu?" Human dates. |
| Medium | Topic reviews duplicate card review with a different 3-point scale (Poor/Okay/Good) vs the card review's 4-point scale. "Recall" gives no reveal step. | Merge into Review as a deck type, or align the scale. |
| Medium | Backlog: completed items are interleaved with open ones. The checkbox is 18 px (the label row extends the target, so it passes). The "Find time" icon (calendar glyph) is unlabeled visually. | Sort done to a collapsed "Completed (70)". Icon + "Schedule". |
| Medium | Day preferences duplicate Settings › Study & review › Daily schedule (two places, same values; F13). *Clock: 24h* while time fields display AM/PM. "Timer guard · hours" is jargon. | One home (Settings) with a deep link from Calendar. Respect the clock setting. Plain labels. |
| Medium | Connected calendars titled "Calendar, in the margin." and showing "Carrel live mirror · Not connected" (an internal codename). | Functional title. Remove codenames. |
| Low | The Daily rituals cards touch with no gap. Titles are italic serif ("Choose what matters."). | 12–16 px gap. |

### 6.11 Progress (`#/insights`): Overview, Learning, Time × 7/30/90 days
Covered: all 9 combinations, View recall data, Time subject filter, Other (34) expand, Study rhythm and examples.

| Sev | Finding | Recommendation |
|---|---|---|
| High | Impossible values shown without guardrails: 12,920 h in 30 days, 2,553 h in 7 days (X1). | Clamp, flag and link to the time log. |
| Medium | Two stacked segmented controls (range + view) push content down 140 px. | Range as a compact chip in the section header. |
| Medium | The stacked review chart uses red, brown and green for Again/Hard/Good/Easy. Good and Easy are two similar greens, and red/green is a classic colour-vision-deficiency pairing. | Use a diverging palette with distinct lightness. Direct-label segments. Add patterns. |
| Medium | Self-rated confidence bars put the value on a separate line, right-aligned below the bar, far from the label. | Value inline at the bar end. |
| Medium | Time by subject lists the aggregate "Other (34)" first, as the longest bar. | Sort subjects by value. Put "Other" last. |
| Low | "Checkpoints completed 0" next to path progress "3 of 36" (X1). | Define "completed" vs "demonstrated". |

### 6.12 Inbox (`#/proposals`): Cards and Plans (F14)
![F14 · Inbox and Cards](screens/F14_inbox_cards.png)

Covered: card proposal, Why this card?, Browse queue (grouped), Edit (LaTeX source and preview), Approve, Reject, stacked undo, Plans tab.

| Sev | Finding | Recommendation |
|---|---|---|
| High | Undo window is 6 s, and repeated decisions stack multiple toasts over the content (X10). | Single toast "2 decisions staged · Undo". ≥ 20 s or persistent. |
| Medium | "Why this card?" expands to "Tutor proposal 10", which gives no rationale. | Show the source passage, checkpoint and the reason given by the tutor. |
| Medium | "Previous proposal / 1 of 599 / Next proposal" uses three wide buttons for linear navigation. | Swipe between cards with a "1/599" indicator. Buttons as chevrons. |
| Low | Plans tab: *Reject* and *Approve* have equal width. "See the whole plan" is a plain text link. | Approve primary. Reject secondary. "See plan" as a button. |

### 6.13 Settings (`#/settings`) (F13)
![F13 · Settings](screens/F13_settings.png)

Covered: Appearance; Tutor (Connected, Connector address, Apps, Say this to start, Teaching style, Tutor rules); Study & review (Daily schedule, Focus & breaks, Projects & time [40 subject rows], Review scheduling, Attention & reminders, Android previews, Calendar connection); Memory (target recall slider, new cards stepper, Tune, eligibility); Data & account (Manage subjects, Math shortcuts, Download a backup, Sign out).

| Sev | Finding | Recommendation |
|---|---|---|
| Medium | **Three levels of accordion** (section › subsection › expander). Several can be open at once, which produces very long pages. | Top-level list → sub-pages (iOS Settings pattern). |
| Medium | Each subsection has its own *Save day*, *Save defaults* or *Save review duration* button, while On/Off toggles save instantly. | Autosave everything with a "Saved" status. |
| Medium | On/Off pills instead of switches (inconsistent with Review's switch). | Platform switch. |
| Medium | Projects & time shows 40 subjects × weekly-hours inputs in a grid. The "Unlinked / gene…" select truncates. | Only linked subjects. "Add subject" for the rest. |
| Low | "Appearance" appears twice (section title and inner heading). | Remove the inner heading. |
| Low | Manage subjects is a list of inputs with no add, delete or reorder affordances visible. | Standard editable list. |
| Low | *Sign out* gives no visible response in the demo. In production, confirm only if there is unsynced data. | — |

### 6.14 Sign in (`#/sign-in`)
| Sev | Finding | Recommendation |
|---|---|---|
| High | The focus-timer bar ("Topology · In focus · Pause") renders on the signed-out screen. | Gate all session chrome on auth. |
| Low | The demo copy "Sign-in is available in live mode." has no CTA. | Fine for a mockup. In production, use passkeys first (WCAG 3.3.8 Accessible Authentication). |

### 6.15 Component kit (`#/kit`)
| Sev | Finding | Recommendation |
|---|---|---|
| Medium | *Reject* is the same filled style as *Start*. *Saving* and *Disabled* are visually identical. | Destructive variant. A spinner and label distinguish loading. |
| Medium | "Time by subject": value labels collide with the bar end ("9h 20m"). | Reserve a label column. |
| Low | The subtitle "Amber on Obsidian" is a stale theme name. | Update. |
| Low | The kit doesn't include the calendar module's components (X6). | Single kit. |

### 6.16 Night theme (F15)
![F15 · Night theme](screens/F15_dark.png)

Text passes AA on every route tested. The Calendar module's primary becomes coral (X2). The Learning chart pastels keep their order. Everything else is consistent.

---

## 7. Deep dive: adding a task (step by step)

Path: **Calendar › Planning tools › Backlog › New task** (F1). The **Find time** and **Edit task** variants were also tested.

![F1 · Add task flow](screens/F01_add_task.png)

| Step | What happens | Issue | Severity |
|---|---|---|---|
| 0. Find it | Three taps deep, inside a sheet from a tab named "Calendar". There's no "Add task" on Today, Paths or the project page. | Low discoverability for the most frequent planning action. | High |
| 1. Sheet opens | Focus goes to the heading (good for screen readers). The keyboard doesn't open. The Task field has no placeholder. | One extra tap. No example of a good task. | Low |
| 2. Fields | Task, Subject (6 hard-coded options that don't match the 40+ subjects or 60 projects elsewhere), Estimate (`type=number`, no `inputmode`), Due date (native), Priority (Normal/High). | Subject list diverges from the app's subjects. No link to a project/checkpoint, so tasks can't feed path progress. | High |
| 3. Submit empty | A grey sentence appears at the bottom: "Add a task and an estimate between 5 and 720 min." No field is marked. No `aria-invalid`. Focus doesn't move. The *Add block* form, by contrast, outlines the field in red with no text. | NN/g: put actionable messages next to the field. The two modules use different error patterns. | High |
| 4. Save button | Full-width **red** "Save task". | Primary rendered in the destructive colour (X2). | High |
| 5. After save | Sheet closes. List header changes "Showing 12 of 353 → 354". **The new task is appended at position 354**, hidden behind "Show 12 more". | Users see no evidence the task exists. Expect duplicate re-entry. | Critical |
| 6. Confirmation | "Task saved · Undo" renders **1,773 px below the viewport** (X3). | Confirmation and undo are invisible. | Critical |
| 7. Edit / remove | *Edit task* sheet: *Remove task* (neutral) next to *Save task* (red). Remove is immediate with the same off-screen undo. | Inverted emphasis. No visible recovery. | High |
| 8. Find time | Opens the generic *New time block* sheet pre-filled with today 8:00 PM, ignoring the estimate (50 min shown, but the 1.3× estimate factor isn't applied) and free slots. | "Find time" implies a suggestion. It delivers a blank form. | Medium |

**Recommended add-task design**
1. A global **＋** (tab-bar accessory or header) offering "Task", "Time block" and "Card", so tasks can be added from any tab.
2. One-line quick add with natural-language parsing ("Prove quotient lemma 50m Fri !high #topology"), and fields revealed only on demand.
3. Subject and project picker sourced from the real project list. Optional checkpoint link.
4. Inline validation under the field, with `aria-invalid` and `aria-describedby`. Estimate field with `inputmode="numeric"` and presets (25 / 50 / 90). Default 30.
5. On save: insert at the top (or in its sorted position), scroll it into view, highlight it for 2 s, and show a viewport-anchored "Task added · Schedule · Undo" toast that persists until dismissed.
6. "Schedule" proposes the next 2–3 free slots that fit the estimate, rather than a blank form.

---

## 8. Prioritised roadmap

### Now (1–2 sprints)
- X1 shared selectors for logged time, session state, due counts and path status, plus guardrails.
- X3 toast portal anchored to the viewport. Automated "toast in viewport" test.
- §7 steps 4–6: new-item reveal, navy primary, inline errors.
- X2 global colour role tokens across both modules.
- X10 persistent action toasts. Undo for block and task delete. Review "pause" vs "complete".
- Sign-in hides session chrome. Concept detail opens as a sheet.

### Next (this quarter)
- X4 large-text pass (rem/clamp, tab bar icon mode, header wrapping) with 200% and 320 px in CI.
- X7 suggestion-first Plan my day, Auto-plan summary, unchecked carry-overs.
- Calendar mobile layout (§6.9): one toolbar, segmented views, full-height grid, conflict resolution actions, block details sheet.
- X6 unify Field, Toggle, Paging and Sheet header components. Calendar module on core tokens.
- X14 route titles, focus on `<h1>`, names for all controls.

### Later
- X5 tab-bar accessory timer with minimize-on-scroll. iOS Live Activity and Android 16 Live Update for focus sessions.
- X11 surface the time log and attention tools, or remove them.
- Settings restructured into sub-pages. Content-design pass and glossary (X9).
- Concept map semantic zoom, with the list as the phone default.

---

## Appendix A: Automated test results

| Check | Result | Details |
|---|---|---|
| Text contrast (1.4.3), Day and Night, 12 routes + overlays | **Pass** with 1 exception | Month view out-of-month day numbers: 4.24:1 at 12 px (needs 4.5:1). |
| Text size | Pass (≥ 12 px) in core | 11 px eyebrows in the calendar module ("PLAN YOUR DAY", "CALENDAR · NOV 4"). |
| Target size (2.5.8 ≥ 24 px) | **Pass** in core | At risk: concept-map nodes 30 × 30 and **overlapping** (the spacing exception fails). |
| Platform target (44 px) | Pass in core | Below 44: Focus "Finish & log" 84 × 38, "Back to notebook" 116 × 38; Backlog "New task" 100 × 36; Deadlines "New deadline" 125 × 36; Topics "Recall" 55 × 36; Day-grid 25-min blocks 35 px tall. |
| Accessible names | 9 unnamed controls | Review 3 (empty `<summary>`), Settings 4, Project 1, Day grid 1. Close-my-day checkboxes named by ID. |
| Focus not obscured (2.4.11) | **Pass** | 32–53 focus stops per route. None fully under the sticky bars. |
| Modal semantics | Pass | Core: `role=dialog` + `aria-modal`, focus contained, body scroll locked. Calendar: native `showModal()`, Escape closes. |
| Swipe-to-dismiss on sheets | Not observed | Emulated touch drag on the handle didn't dismiss. Verify on device. |
| Reflow at 320 px | Pass | No horizontal overflow on 6 tabs. |
| 200% text | **Fail (usability)** | Mid-word breaks, header overlap, unscaled card body (F4). |
| Landscape 844 × 390 | **Poor** | ≈ 150 px usable content (F5). |
| Page titles (2.4.2) | **Fail** | Same `<title>` on every route. |
| Safe areas | Partial | top/bottom/left handled. `safe-area-inset-right` unused (landscape notch). |
| Reduced motion | Present | `prefers-reduced-motion` queries in CSS. |
| Input ergonomics | Partial | 16 px inputs (no iOS zoom). `inputmode` and `enterkeyhint` rarely used. Number fields lack numeric keypad hints. |
| Runtime errors | None | No uncaught page errors during the run. |

## Appendix B: Screen coverage checklist

**Core routes:** Today · Paths (Active/Paused/Done, search, empty, actions, archived, page 2) · New project · Project (Path, Sessions, Sources, switcher, copy prompt, timeline, forecast, stages) · Checkpoint sheet · Session detail (all events) · Concept map (list, show more, detail, map, expand, key/help, reset) · Review (home, batch, decks, queue, outlook) · Review run (long and short card, confidence, reveal, 4 grades, More menu, close) · Review summary (redo missed) · Cards (filters, chips, load more, empty) · New card · Card detail (edit, pause, delete confirm, note) · Calendar Agenda/Day/Week/Month (all scroll positions, previous/next/today, full week) · Day details · Conflicts · Due today · Earlier today · Block add (with more options) / edit / delete · Calendar menu · Planning tools · Auto-plan · Backlog (check, find time, edit, remove, new task, show more, find time for all) · Deadlines (new, work backwards) · Topic reviews (recall, rate, edit, new) · Plan my day 1–3 and preview · Close my day · Day preferences · Connected calendars · Focus (in focus, pause, break, finish) · Progress (3 views × 3 ranges, expanders) · Inbox Cards/Plans (why, browse queue, edit, approve, reject, undo) · Settings (all sections and subsections, Android previews, calendar connection, manage subjects, math shortcuts, sign out) · Sign in · Component kit · Night theme · 320 px · 200% text · landscape.

**Not reachable in this build:** `#/carrel/*` pages (log, distractions, insights, coach, android, features, subjects, more). They redirect to Today (X11).

## Appendix C: Sources

- W3C, *Understanding SC 2.5.8 Target Size (Minimum)*: https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html
- W3C, *Understanding SC 2.4.11 Focus Not Obscured (Minimum)*: https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured
- W3C, *What's New in WCAG 2.2*: https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/
- W3C, *Understanding SC 2.2.1 Timing Adjustable*: https://www.w3.org/WAI/WCAG22/Understanding/timing-adjustable.html
- Apple, *Human Interface Guidelines: Buttons*: https://developer.apple.com/design/human-interface-guidelines/buttons
- Apple WWDC25, *Build a UIKit app with the new design* (tab bar minimize on scroll): https://developer.apple.com/videos/play/wwdc2025/284
- Donny Wals, *Exploring tab bars on iOS 26 with Liquid Glass* (bottom accessory view): https://www.donnywals.com/exploring-tab-bars-on-ios-26-with-liquid-glass/
- Google Design, *Expressive Material Design: Google research*: https://design.google/library/expressive-material-design-google-research
- Android Developers, *Android 14 features: nonlinear font scaling to 200%*: https://developer.android.com/about/versions/14/features
- Android Authority, *Android 16 Live Updates*: https://www.androidauthority.com/android-16-live-updates-3556651/
- Flutter, *SnackBar with action no longer auto-dismisses* (Material 3 alignment): https://docs.flutter.dev/release/breaking-changes/snackbar-with-action-behavior-update
- Angular Material, *Snack-bar accessibility guidance*: https://v6.material.angular.io/components/snack-bar
- Nielsen Norman Group, *Bottom Sheets: Definition and UX Guidelines*: https://www.nngroup.com/articles/bottom-sheet/
- Nielsen Norman Group, *Errors in Forms: Design Guidelines*: https://www.nngroup.com/articles/errors-forms-design-guidelines/
- eBay Playbook, *Bottom sheet*: https://playbook.ebay.com/design-system/components/bottom-sheet
- Baymard Institute via Smashing Magazine, *Infinite Scrolling, Pagination or "Load More" Buttons?*: https://www.smashingmagazine.com/2016/03/pagination-infinite-scrolling-load-more-buttons/
- Anki Forums / FSRS, *Pass/Fail grading* and *Hard is a passing grade*: https://forums.ankiweb.net/t/pass-fail-grading-as-default/34147 · https://forums.ankiweb.net/t/add-visual-cues-to-make-it-clear-that-hard-is-not-a-failing-grade/40879
