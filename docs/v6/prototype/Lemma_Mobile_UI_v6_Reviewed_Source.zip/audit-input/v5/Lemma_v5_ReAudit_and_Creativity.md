# Lemma v5: Mobile UI Re-audit and Creativity Review

**Subject:** `Lemma_Mobile_UI_5.html` (the updated plan). Compared against the build audited on 4 Nov 2026.
**Date:** 5 November 2026
**Primary viewport:** 390 × 844 CSS px, touch. Also tested at 320 × 568, 844 × 390 landscape, root text at 200%, and in the Night theme.
**Method:**
- **Build diff.** I diffed the two builds at the module, CSS and script level.
- **Screen-by-screen re-walk.** I opened every route, tab, sheet, flow and expander again in Chromium (Playwright), screenshotting top to bottom including inner scroll areas.
- **Automated checks.** I re-ran contrast, target size, accessible-name, focus-visibility, overflow and swipe tests.
- **Creativity rating.** I scored creativity against an explicit rubric drawn from creativity research.
- **Creative proposals.** I grounded each new idea in published work from cognitive psychology, learning science, behavioural economics and HCI.

> Figures **G1–G10** are in `screens/`. Typography was rendered with the real families (Newsreader, Instrument Sans, STIX Two Text, IBM Plex Mono) from the official `google/fonts` repository.

---

## 1. Executive summary

**v5 is a substantial, disciplined remediation.** The build includes a new 26.7 KB stylesheet block headed *"Audit remediation, 4 November 2026"*, and 19 of the 78 app modules changed. Of the 14 cross-cutting problems found yesterday, **8 are fixed, 5 are partly fixed and 1 is still open**. Most notably:
- **Feedback is visible.** Toasts sit in the viewport, persist, and offer real Undo.
- **Colour roles are consistent.** Navy means primary; red means destructive, everywhere.
- **Adding a task works.** Inline errors, duration presets, the new task inserted at the top, a confirmation you can see.
- **The planner no longer overloads.** Plan my day suggests rather than pre-ticking 283 tasks, and Close my day pre-checks nothing.
- **The chrome adapts.** Tab bar and timer merge into a compact dock on scroll, and landscape gets a floating timer pill.
- **One component system.** The calendar now uses the notebook's components.
- **Truth guardrails have started.** A single "logged effort" selector now gives the same number on Today, Calendar and Close-my-day.

**Overall UX rating: 3.0 → 3.9 / 5.**

What still holds it back:
1. **A new header regression (High).** The global header cluster (Inbox, +, ⋯) squeezes page titles. "Topology" breaks per syllable at 390 px and stacks vertically at 320 px. Card detail and Cards push the cluster onto a second row (G2).
2. **Truth guardrails stop short (High).** "9 h 24 min logged today" at 08:05, sessions marked *Logged* later today, study-log entries dated 2027, a "29 min logged" toast that doesn't move the total, and card memory stats next to "No reviews yet" (G4).
3. **Large text is better but still breaks (High).** Paths rows overlap, Progress tabs collide, and the project title stacks vertically (G8).
4. **Smaller new issues.**
   - In-focus feedback hides under the focus overlay.
   - *Park a thought* uses the browser's native `prompt()`.
   - The overflow menu repeats all five tabs.
   - Global **+ Task** teleports you into Calendar.
   - Settings sub-pages have two back buttons.
   - Plan previews dead-end at "0 tasks fit".
   - 4 of 59 keyboard focus stops on Paths now land under the dock (WCAG 2.4.11 regression).

**Creativity rating: 3.2 / 5, "distinctive craft, cautious interaction."** Lemma is creative at the level of **concept and tone**:
- a tutor that *proposes* and a learner who *approves*;
- *demonstrated* mastery kept separate from *logged* effort;
- a geometer's-notebook identity with math-native type.

It is conventional at the level of **interaction**: lists, sheets and segmented controls that any productivity app could ship. In Boden's terms it is strong *combinational* creativity with pockets of *exploratory* creativity, and nothing yet *transformational*.

§8 proposes 12 research-grounded creative directions. The five highest-value bets:
1. a **Calibration Mirror** (confidence before reveal, which exploits the hypercorrection effect);
2. a **Proof Ladder** that reveals answers line by line (generation, productive failure);
3. a **Living Atlas** with stable spatial geography (spatial-memory research);
4. **Interleave by technique**, going beyond today's deck-level "Mixed order" (classroom RCT, d ≈ 0.83);
5. **Forgiving rhythms** in place of streaks (research on broken streaks and fresh starts).

---

## 2. What changed between builds

| Area | Change |
|---|---|
| Modules | 19 of 78 changed. None added or removed. |
| CSS | New blocks: "Audit remediation, 4 Nov 2026", "Remaining audit comments", "Shared notebook records and feedback…", "Calendar consumes the same roles and typography as the notebook shell". |
| Themes | Renamed to `graph` / `graph-night` ("Graph paper before first paint, with migration from obsolete worlds"), with background `#FAFAF6`. |
| Data | A single read-only `lemmaEffortSelector`: "Overlapping saved intervals count once, live time stays separate, and invalid records remain inspectable." |
| Bridges | `lemma-calendar-drawer-bridge` makes the background inert under native sheets and returns focus. `lemma-calendar-route-scroll-guard` stops timer ticks resetting scroll. `lemma-prompt-handoff` handles clipboard with a manual-copy fallback. |
| Copy | "Long-running guard" → "Pause reminder after". "Search cards" → "Card library". "Back to Atlas" → "Back to concept map". "Undo within six seconds" → "at least 30 seconds to undo". "Next page" → "Load 20 more paths". "Subjects merged. Projects and ideas now use the selected subject." |

---

## 3. Status of the previous findings

![G1 · Add task v1 vs v5](screens/G01_add_task_v1_v5.png)

![G9 · Chrome fixes](screens/G09_chrome_v5.png)

![G3 · Planner](screens/G03_planning_v5.png)

![G6 · Review, Inbox, Cards](screens/G06_review_inbox_v5.png)

| ID | Finding (4 Nov) | v5 status | Evidence |
|---|---|---|---|
| X1 | Contradictory sources of truth | **Partial** | Today, Calendar › Day details and Close my day all say 9 h 24 min. Progress shows a plausible 45 h 39 m over 30 days and an overlap warning ("Each minute is counted once · Check your log"). The project now combines its status into one line ("34 days after target. Current checkpoint is on time."). Guardrails for time-travel and impossible totals are still missing (N2). |
| X2 | Colour semantics inverted | **Fixed** | Calendar Save is navy. *Delete card* and *Archive* are red. *Discard session* is red outline. *Delete* block is red tint. Exception: Month view still circles *today* in red. |
| X3 | Toasts rendered off-screen | **Fixed** | "Task added to the top of your backlog" and "Calendar block removed · Undo Calendar changes" sit at y≈626–722, persist, and have ×. Exception: hidden under the focus overlay (N6). |
| X4 | Large text breaks layout | **Partial** | The tab bar collapses to icons and the dock merges. Project title, Paths rows, Progress tabs and the clipped timer still break (G8). |
| X5 | Fixed-chrome budget | **Fixed** | Compact dock on scroll. Landscape tab bar replaced by a floating timer pill. No session chrome on Sign-in (G9). |
| X6 | Two component systems | **Mostly fixed** | Calendar now uses the notebook Field, error, segmented, "Load 20 more" and sheet patterns. Leftovers: italic serif panel titles (*Backlog*, *Plan my day*) and an unthemed native range slider (bright system blue) in Memory. |
| X7 | Opt-out mega-lists | **Fixed** | Plan my day: "Suggested from deadlines, priority and available time. Nothing is selected for you." Close my day: unchecked, with "Carry all 283 open tasks". Preview leads with a summary. New dead-end issue (N7). |
| X8 | Navigation and duplicate entry points | **Partial** | The same header cluster on every tab, an Inbox badge ("99+", label "600 pending proposals"), and a single Planning tools entry. New issues: overflow repeats the tabs, and global + teleports (N3, N4). |
| X9 | Jargon and internal names | **Mostly fixed** | Planet/moon labels gone, "Carrel" gone, "Topic practice notes" explains itself, "Likely recall 90%". Left: "Memory stability 14 d", "N30000", "N1", ISO dates in Study log. |
| X10 | Undo, confirmation, timing | **Fixed** | 30 s staged decisions with per-item Undo. Closing review mid-way asks "Pause review? 32 cards left… Finish later / Keep reviewing". |
| X11 | Orphaned features | **Partial** | *Edit study log*, *Noticed a distraction* and *Park a thought* are now reachable. The old `#/carrel/*` routes still redirect to Today (fine if intentional). |
| X12 | Bottom-sheet mechanics | **Fixed / changed** | Grab handles removed, so there's no false affordance. New: the page behind native calendar dialogs still scrolls (N9). |
| X13 | Five paging patterns | **Fixed** | "Load 20 more …" everywhere, and the Cards nested scroller is removed. |
| X14 | Assistive-technology semantics | **Partial** | Per-route titles ("Paths · Lemma", "Learning path · Lemma"). All controls named. Still: focus stays on `<body>` after navigation, and a new 2.4.11 regression (N10). |
| §7 | Add task | **Fixed** | G1: navy Save, inline "Enter a short task title.", presets (25/50/90), Learning path and Checkpoint fields, inserted at the top, visible toast, labelled Schedule/Edit. |
| 6.5 | Concept detail rendered 6,000 px below | **Fixed** | Opens as a sheet. The map is now subject tiles (G7). |
| 6.7 | Hard paired with Again | **Fixed** | Full-width *× Again*, with *Hard / Good / Easy* grouped under ✓ (G6). This matches FSRS guidance that Hard is a pass. |
| 6.9 | Calendar 600 px of controls; nested day grid | **Fixed** | Segmented views and compact chips. The Day grid scrolls with the page in four overlap lanes. Block tap opens details with *Start focus / Edit / Move / Delete*. |
| 6.9 | Conflicts were a wall of text | **Fixed** | "Resolve overlapping blocks" with *Move / Shorten / Keep both*. |
| 6.2 | Finish & log had no summary | **Fixed** | "Finish focus session" form: logged minutes (editable), focus rating, "What did you learn?", *Save* / *Discard* / *Back*. |
| 6.13 | Three-level accordions; duplicated preferences | **Fixed** | Settings › section sub-pages. Calendar "Study preferences" links into Settings, so preferences now live in one place. |

---

## 4. New and remaining findings

### N1 · Header cluster collides with page titles (High, new regression)

![G2 · Header collisions](screens/G02_header_collisions.png)
**Evidence (G2).**
- **Project page at 390 px:** "To/pol/og/y" breaks across four lines next to ←, Switch, ›, Inbox, + and ⋯.
- **At 320 px:** the title stacks one letter per line.
- **Card detail:** *Edit card / Pause card / Delete card* render above the Inbox/+/⋯ cluster, which drops to a second row.
- **Cards:** two "+" buttons (page "New card" and the global add), with the cluster wrapped beneath.
- **Concept map and Component kit:** titles wrap to two lines.

**Cause.** The global cluster (3 × 44 px) plus page actions plus back are laid out in the title row with `min-width:0` on the `h1`, so the heading takes whatever width is left.

**Fix.**
- Use a two-tier header on sub-pages: row 1 holds back, title and cluster; row 2 holds page actions as a scrollable chip row.
- Never let the `h1` drop below its longest word: `min-inline-size: max-content` with an ellipsis fallback.
- On detail pages, move Inbox and + into ⋯.
- Remove the page-level "+" where the global + already offers "Card".

### N2 · Logged-time guardrails (High)

![G4 · Guardrails](screens/G04_data_guardrails.png)
**Evidence (G4).** At 08:05 local time:
- Today and Day details report **9 h 24 min logged today**, which is more than the 8 h 05 min elapsed since midnight.
- The agenda shows blocks marked *Logged* at 09:00, 11:00, 14:00 and 18:14, all later today.
- The Study log's newest entries are dated **2027-02-18**.
- After *Save study time* (29 min), the toast says "29 min logged to Topology" but the total stays 9 h 24 min. The overlap rule likely absorbed it, but the user isn't told.
- Card detail shows next review, stability and "Likely recall 90%" above "Recent reviews: No reviews yet."

**Why it matters.** The new selector made the numbers *consistent*. They still aren't *plausible*. A learner who sees time logged in the future or a toast that doesn't change the total will distrust every metric.

**Fix.**
- Reject or flag intervals with `end > now`, and render them as *Planned*.
- Clamp "logged today" to the time elapsed today, and show the remainder as "needs review".
- When a save is deduplicated, say so: "29 min saved · 18 min overlapped existing records". Link to the log.
- On card detail, derive the "Memory" panel and "Recent reviews" from the same review log, or explain that the stats come from an imported schedule.

### N3 · Overflow menu duplicates the tab bar (Medium)
⋯ lists Today, Paths, Review, Calendar, Progress, Concept map, Card library and Settings. Five of those eight are already one tap away in the tab bar.
**Fix.** Keep ⋯ for secondary destinations only (Concept map, Card library, Settings, Help). Hick's law favours fewer, more distinct choices.

### N4 · Global "+ Task" changes context (Medium)
From Today, **+ › Task** navigates to Calendar › Backlog before opening the sheet. After saving, the user is left in Calendar.
**Fix.** Open the sheet over the current page and keep the user there. The toast's "View in backlog" link does the navigation if they want it.

### N5 · Placeholder examples look like values (Medium)
The Task field shows "Prove the quotient-map criterion" in grey inside a grey-filled field. After an empty submit, the inline error says "Enter a short task title" while the field still *looks* filled.
**Fix.** Lighter placeholder with an "e.g." prefix (the Checkpoint field already does this), or show the example as helper text below the field.

### N6 · Focus-mode feedback is invisible (Medium)

![G5 · Focus](screens/G05_focus_v5.png)
*Noticed a distraction* creates "Distraction noted. Return when you're ready." in the feedback layer (z-index 1000), which sits under `#cr-focus-overlay` (z-index 99999). *Park a thought* calls `window.prompt("Park a thought for later")`. That is an unstyled browser dialog, unavailable in some installed-PWA contexts and impossible to theme or localize.
**Fix.** Render feedback inside the overlay. Make Park a one-line inline field with a "Parked · 3" counter that later flows into Close my day.

### N7 · Planning dead ends (Medium)
*Preview study plan* says "0 tasks fit · 0 min… There is no room within your daily intention and free time". The only actions are *Keep editing* and a disabled *Add 0 blocks*. Plan my day says "No suggestions fit today" with only *Add from backlog…*.
**Fix.** Offer next-best actions:
- "Try tomorrow (3 h free)"
- "Shorten 2 overlapping blocks"
- "Raise today's intention by 30 min"
- "Pick 1 must-do anyway"

### N8 · Settings sub-pages have two back controls (Low)

![G10 · Settings](screens/G10_settings_v5.png)
The header shows ← with the title **Settings**, and the page shows "‹ Settings" with **Appearance** below it (G10).
**Fix.** Header title = sub-page name. Remove the in-page back link.

### N9 · Scroll bleed behind calendar dialogs (Low)
With native `<dialog>` sheets open (Preview study plan, Plan my day), the agenda behind keeps scrolling. Screenshots show the background moving between frames.
**Fix.** Use `overscroll-behavior: contain` on the sheet body, and lock `html { overflow: hidden }` while it's open. The core sheets already do this.

### N10 · Focus not obscured: regression (Medium, WCAG 2.4.11 AA)
Tabbing through Paths: **4 of 59** focus stops (for example "Mathematics project 45", "Actions for Mathematics project…") land entirely under the bottom dock (top = 735 px, dock top = 734 px). Calendar, Settings and Progress pass.
**Fix.** Update `scroll-padding-bottom` to the dock's *current* height, including when the dock switches to compact mode.

### N11 · Large text (High, carried over from X4)

![G8 · 200% text](screens/G08_large_text_v5.png)
G8 at 200%:
- Paths rows overlap ("Mathematics / project 41" over "Now CP4 Checkpoin…").
- Progress tabs read "OverviewLearning".
- Inbox "Approve" is clipped.
- The dock timer is clipped ("21:1").
- The card body doesn't scale.

**Fix.** Allow row height to grow (no fixed `min-h` with absolutely positioned meta). Segmented controls wrap to two rows. Give the timer a fixed `ch` width.

### N12 · Small polish
- Month view marks *today* with a red ring. Use the accent ring instead.
- Memory "target recall" slider uses the default system blue. Theme it.
- Concept sheet shows two close buttons (header ×, plus a × in the card). "Expand 1 child" uses pale text that reads as disabled.
- New project focuses the heading with a full focus ring, so it looks like an input. Use `:focus-visible` only for keyboard users.
- Study log shows ISO dates that wrap ("2027-/02-18"). Use "Thu 18 Feb".
- Compact dock: the "Pause" label renders at a fraction of a pixel during the transition. Animate opacity, not font-size.

---

## 5. Screen-by-screen delta

![G7 · Concept map](screens/G07_atlas_v5.png)

| Screen | Better in v5 | Still to fix |
|---|---|---|
| Today | Logged-today bar with overlap note. "Also in your notebook" with *Next up · Start*. After finishing a session, it switches to "Continue Compactness · Copy resume prompt". | N2 plausibility. The hero still shows its eyebrow plus title plus subtitle plus status on four lines. |
| Focus | Attention tools surfaced. "Pomodoro 2 of 4 · 50 min focus / 10 min break" in plain words. Finish form. | N6. "Finish & log" is now a text link, a weak affordance for a primary end action. |
| Paths | Continuous progress bars. Subject initials (S4…). "Load 20 more paths". Archive in red. | N10. Group headers repeat the subject with the same initial ("S5 Subject 5" above "S5 Mathematics project 5"). |
| Project | "0 due for CP2" and "28 tutor sessions for CP2" are scoped. Locked/up-next chips with dates. "Time records effort. Complete a checkpoint by demonstrating the required work." | **N1** title collapse. The stage picker select and the stage accordion still duplicate each other. |
| Session | "This session refers to a checkpoint ahead of your current path. It does not advance the path on its own." Outcome barcode. | The 400-tick barcode is decorative at this density. Bin it or make it scrubbable. |
| Concept map | Detail sheet. Subject tile map with "33 more subjects". Natural sort. Jargon removed. | Title wraps. Two close buttons. |
| Review | Again / pass-group split. Pause sheet; *Finish later* returns to "Continue your review · Resume review" with no false celebration. "Card library". | The queue line reads "3,999 due across all decks" after one card. Accurate, but at that scale a catch-up plan is more useful than a raw count. |
| Cards | Filters moved into a sheet. Single page scroll. Labelled detail actions. | N1 header. "No reviews yet" contradiction (N2). |
| Calendar | Segmented views, compact chips, details sheet, conflict resolver, Day grid in lanes, Study log editor, preferences moved to Settings. | N2, N7, N9. Day-grid block titles truncate to "Represe…" at 76 px wide. Consider stacked lanes with a "+3" overflow. |
| Progress | Range as a select, guardrail note, patterned review legend (Again / Hard-hatched / Good / Easy). | Large-text tab collision. |
| Inbox | Staged decisions list with per-item Undo. "Decision staged · at least 30 seconds to undo". | The staged-decision toast covers the proposal body. Dock it above the action bar instead. |
| Settings | Sub-pages. Toggles are switches. Single source for day preferences. | N8. |
| Sign in | No session chrome. | — |
| Kit | "Navy on paper · Day and Night". Patterned charts. Calendar component specimens. | Title wraps (N1). |

---

## 6. Automated results, v1 → v5

| Check | 4 Nov | 5 Nov |
|---|---|---|
| Text contrast AA (12 routes × Day/Night) | Pass, 1 exception | **Pass, 0 exceptions** |
| Smallest text | 11 px eyebrows (calendar) | 10 px "99+" badge only |
| Targets < 44 px (main routes) | 6 types in sub-views | Timer-details button 43–44 × 47 only |
| Unnamed controls | 9 | **0** (remaining hits are closed `<details>` content) |
| Page titles per route | Fail | **Pass** |
| Focus moves to new view on navigation | Fail | Fail |
| Focus not obscured (2.4.11) | Pass | **Regression: 4/59 on Paths** |
| Swipe affordance | Handle present, no swipe | Handles removed (consistent) |
| 320 px overflow | Pass | Pass, but title collapse (N1) |
| 200% text | Fail | Improved, still fails (N11) |
| Landscape | ≈150 px usable | **≈ full height with floating pill** |

---

## 7. Creativity assessment

### 7.1 Method
Creativity research defines a creative product by two jointly required properties. Runco & Jaeger's "standard definition" states that **creativity requires both originality and effectiveness**, and notes that originality alone is not enough. Both are relative to a context and its norms. So I rate Lemma against its category (spaced-repetition apps, study planners, focus timers, AI-tutor companions) and against its own goal: helping a self-directed mathematics learner make real progress.

To classify *kind* of novelty I use Boden's three types:
- **combinational:** familiar ideas recombined;
- **exploratory:** pushing within an existing conceptual space;
- **transformational:** changing the rules of that space.

The rubric has six criteria, each 1–5:
1. **Originality:** novelty relative to the category.
2. **Effectiveness:** does the novelty serve learning?
3. **Conceptual coherence:** does one idea organise the whole?
4. **Surprise and delight:** moments that exceed expectation.
5. **Expressive craft:** type, colour, motion, voice.
6. **Generativity:** does the concept open new features rather than just decorate?

### 7.2 Scores

| Criterion | Score | Rationale |
|---|---|---|
| Originality | **3.5** | The *tutor proposes → learner approves* inbox (cards, plans, fixes) is a fresh human-in-the-loop model for AI-assisted curricula. *Demonstrated vs logged* ("Time records effort. Complete a checkpoint by demonstrating the required work.") is rare and valuable. Checkpointed "paths" with multi-source citations go beyond a deck list. Everything else (agenda, backlog, Pomodoro, segmented tabs) is category-standard. |
| Effectiveness | **4.0** | The novel parts are well chosen for learning: implementation intentions in Plan my day ("If I get stuck… Then I will…"), Park-a-thought for open loops, FSRS-aligned grading, "without shame" re-planning, and the topic-practice disclaimer. |
| Conceptual coherence | **3.0** | The *geometer's notebook* (graph paper, Newsreader, STIX, ℓ monogram, Q.E.D.) is strong but stops at the surface. Planner, map and progress don't *behave* like a notebook (no margins, no ink, no proofs-as-pages). The UI has dropped the cosmic vocabulary, but the tutor integration still describes ideas as clusters, galaxies, systems, planets and moons, so the learner may hear two metaphors. |
| Surprise and delight | **2.5** | Calm by design, which is appropriate, but there are few peak moments. The Q.E.D. summary ring is the only one. No motion signature, no haptics, no celebratory moment when a checkpoint is *demonstrated*. |
| Expressive craft | **4.0** | Excellent typographic voice, careful Night theme, patterned charts, restrained palette. |
| Generativity | **2.5** | The concept hasn't yet generated *interactions* unique to mathematics (proof scaffolding, notation, sketching, calibration). |
| **Overall** | **3.2 / 5** | Strong combinational creativity, some exploratory creativity, nothing transformational yet. |

### 7.3 What's already genuinely creative (protect these)
1. **The approval inbox.** An AI tutor that cannot silently change your curriculum is a strong trust and agency pattern.
2. **Effort ≠ mastery.** Separating logged time from demonstrated checkpoints resists the "hours studied" vanity metric.
3. **Implementation intentions** built into Plan my day.
4. **Park a thought / Noticed a distraction.** Lightweight metacognitive tools inside focus.
5. **Graph-paper identity** with math-native typography and KaTeX.
6. **"Without shame" copy**, such as "Pause review? Your answers are saved; you can finish this round later."

---

## 8. Creative directions, grounded in research

Each idea gives the mobile interaction, the evidence, guardrails, a success metric and effort (S/M/L). Ideas are ordered by expected value.

### C1 · Calibration Mirror ("How sure are you?") (Effort S, Impact High)
**Interaction.** Before *Show answer*, a one-thumb **confidence slider** (Guess · Unsure · Sure · Certain) sits in the thumb zone (today it's hidden under "Optional confidence"). After grading, a **mirror moment** flags *confident errors* with a distinct ochre frame and the line "You were sure — this one will stick if you look closely." The weekly Progress view shows a **calibration curve**: predicted vs actual recall.

**Evidence.** Butterfield & Metcalfe found that errors made with high confidence are *more* likely to be corrected after feedback than low-confidence guesses (the hypercorrection effect). The leading explanation is extra attention caused by the metacognitive mismatch.

**Guardrails.** Keep confidence optional. Never shame overconfidence; frame it as an opportunity.

**Metric.** Re-test accuracy on high-confidence errors. Calibration (Brier score) over 4 weeks.

```
┌───────────────────────────────┐
│ Definition · N1               │
│ State the quotient-map …      │
│                               │
│ How sure are you?             │
│ ○ Guess ○ Unsure ● Sure ○ Cert│
│ [        Show answer        ] │
└───────────────────────────────┘
```

### C2 · Proof Ladder (line-by-line reveal) (Effort M, Impact High)
**Interaction.** For proof cards, *Show answer* becomes **"Show next step"**. Each tap reveals one line of the proof, so the learner tries to generate the next move before seeing it. Grades become *Needed 0 / 1 / 2+ hints*, which maps cleanly onto Again/Hard/Good.

**Evidence.** Sinha & Kapur's meta-analysis of 53 studies (166 comparisons) found a moderate effect favouring *problem solving before instruction* (g = 0.36), and stronger effects when designs follow Productive Failure principles (g 0.37–0.58).

**Guardrails.** Productive failure needs some prior knowledge. Offer the ladder only for cards past their first review.

**Metric.** Delayed-test accuracy on ladder cards vs whole-answer cards.

### C3 · Living Atlas: a stable geography of ideas (Effort L, Impact High)
**Interaction.** Concepts get **fixed coordinates** that never reflow; zoom scales the map rather than re-laying it. Demonstrated concepts "ink in" (graphite → navy). Un-studied regions stay pencil-light. *Today's* review cards appear as pins, so a review session becomes a walk across your own map. Opening a checkpoint flies to its region.

**Evidence.**
- Spatial consistency lets users build memory of where things are, which cuts visual search time. Because spatial memory is long-lasting and high-capacity, the benefit lasts and scales.
- In CommandMaps studies, novices performed the same as with menus, but experienced users were significantly faster than with both menus and the Ribbon.

**Guardrails.** Never auto-re-layout (scaling outperformed reflowing in the same research programme). Keep the list view as the accessible equivalent.

**Metric.** Time to locate a known concept after 2 weeks.

### C4 · Interleave by technique, not just by deck (Effort S, Impact High)
**Already present:** Review shows "60 decks selected · Mixed order", so deck-level mixing is on.
**Interaction.** Go one level deeper: tag cards with the *technique* they require (compactness argument, ε-δ, diagonalisation…) and order the queue so that no two consecutive cards need the same technique. Add a small **mix dial** (Focused ↔ Mixed) with the honest label "Mixed practice feels harder and works better."

**Evidence.** In a preregistered cluster-randomised trial across 54 grade-7 maths classes, the interleaved group outscored the blocked group 61% to 38% (d = 0.83) on an unannounced test a month later.

**Guardrails.** Interleaving feels harder. Say so ("Mixed practice feels harder and works better"). Teachers in the trial reported it took more time.

**Metric.** 30-day retention by mix level.

### C5 · Forgiving rhythms instead of streaks (Effort S, Impact Medium–High)
**Interaction.** Replace any streak with a **"rhythm"**: 4 of the last 7 days counts as on-rhythm. Never announce a broken rhythm; show "Welcome back · pick up where you left off". Offer **fresh-start moments** on Mondays, the 1st of the month and the term start: "New week, clean page. Choose 3 things."

**Evidence.**
- Silverman & Barasch found that highlighting an intact streak raises engagement relative to a broken one. They also found the harm of a broken streak is amplified when people blame themselves, and reduced when the streak can be "repaired".
- Dai, Milkman & Riis found that temporal landmarks such as a new week, month or semester increase aspirational behaviour.

**Guardrails.** Fresh starts can demotivate people who are already on track. Show them only after a lapse or a low week.

**Metric.** Return rate after a 3+ day lapse.

### C6 · Open-loop inbox (making "Park a thought" real) (Effort S, Impact Medium)
**Interaction.** Park becomes an inline field in Focus ("Parked · 3"). At *Finish*, parked thoughts appear with one-tap destinations: *Task*, *Card*, *Question for tutor*, *Discard*. Close my day lists unresolved parks.

**Evidence.** Masicampo & Baumeister showed that making a specific plan for an unfulfilled goal removed its intrusive cognitive effects. Once a plan exists, goal-related activity pauses and resumes at the planned time.

**Metric.** Self-rated focus after sessions with vs without parks.

### C7 · Break menu that restores (Effort S, Impact Medium)
**Interaction.** "Take a break" offers three 1-tap break types with a gentle 5–10 min ring: *Move* (stand, stretch), *Look far* (window, 20 s eye focus), *Breathe*. After deep-work blocks over 90 minutes, it suggests a longer break.

**Evidence.** A meta-analysis of 22 samples found micro-breaks raised vigour and reduced fatigue (d ≈ .35). It found no overall performance effect, and longer breaks helped performance more.

**Guardrails.** Don't promise performance gains. Frame breaks as energy.

**Metric.** Fatigue rating at session end.

### C8 · End on a proof (peak-end session close) (Effort S, Impact Medium)
**Interaction.** After *Save study time*, show a **single-card "proof of the day"**: the best line the learner wrote in "What did you learn?", or the one card that moved from Again to Good, typeset in STIX with Q.E.D. It can be shared as an image to the tutor.

**Evidence.** Peak-end research (Kahneman et al., 1993) shows that retrospective evaluation of an experience is dominated by its peak and its final moments. This is a well-replicated judgment pattern, used here for motivation, not memory.

**Metric.** Next-day return rate.

### C9 · Pre-exam worry dump (Effort S, Impact Medium, mixed evidence)
**Interaction.** Two days before a *Deadline* tagged "Exam", Lemma offers a private 10-minute "Clear your head" page. Nothing is stored unless the learner chooses to keep it.

**Evidence.** Ramirez & Beilock (*Science*, 2011) found that writing about worries for 10 minutes before an exam improved performance in students prone to test anxiety. Later classroom studies are mixed: one found neither expressive writing nor an instructional intervention reduced test anxiety or improved exam scores.

**Guardrails.** Opt-in, private, framed as optional. Measure before investing further.

### C10 · Goal-gradient checkpoints (Effort S, Impact Medium)
**Interaction.** Inside a checkpoint, show **step progress** ("Step 2 of 3 · Construct the argument") as the dominant bar, and the 100-checkpoint path as a quiet secondary line. Near the end of a checkpoint, switch copy to "One step left." Give a short **ink-in animation** with a haptic tick when a checkpoint is *demonstrated*.

**Evidence.** Kivetz, Urminsky & Zheng found that people accelerate effort as they approach a reward. Even *illusory* progress helped: a 12-stamp card with 2 bonus stamps was completed faster than a 10-stamp card.

**Guardrails.** Never fake progress. Use real sub-steps. Motivation dips just after a reward, so queue the next checkpoint immediately.

### C11 · Calm periphery: Live Activity and widget as ambient presence (Effort M, Impact Medium)
**Interaction.** The running session lives on the lock screen and Dynamic Island (iOS Live Activity) or as an Android 16 Live Update. A home-screen widget shows **only** "Next up 08:23 · Representation of finite groups" and a tiny ring of today's intention. No badges, no red counts.

**Evidence.** Weiser & Brown describe calm technology as moving easily between the periphery of attention and the centre, then back again.

**Metric.** In-app opens per completed session (lower is better if completion holds).

### C12 · A notebook that behaves like one (Effort L, Impact Medium)
**Interaction.**
- **Margins.** Swipe left on any card, session or checkpoint to reveal a margin for handwritten (stylus) or typed notes. These become *For your tutor* notes.
- **Ink states.** Pencil means planned, ink means logged, a stamp means demonstrated. One visual language across Calendar, Paths and Map, which retires today's dashed / solid / green borders.
- **Notation keyboard.** A bottom accessory bar of common symbols (∀ ∃ ∈ ⊆ → ⇒ ∘ ≅) above the system keyboard in every math field.

**Evidence and rationale.**
- Spatial and visual consistency (C3) carries over to status encoding.
- Gamification meta-analyses find small-to-medium effects on cognitive learning outcomes (g = .49 across 19 comparisons), and effects depend on design. A *coherent fiction* (the notebook) is a better-founded engagement lever than points or badges.

**Metric.** Notes per session. Error rate when entering notation.

### 8.1 Prioritisation (ICE)

| # | Idea | Impact | Confidence (evidence) | Ease | ICE |
|---|---|---|---|---|---|
| C1 | Calibration Mirror | 5 | 4 | 4 | **80** |
| C4 | Interleave by technique | 4 | 5 (RCT) | 4 | **80** |
| C5 | Forgiving rhythms / fresh starts | 4 | 4 | 5 | **80** |
| C6 | Open-loop inbox | 3 | 4 | 5 | **60** |
| C2 | Proof Ladder | 5 | 4 | 3 | **60** |
| C10 | Goal-gradient checkpoints | 3 | 4 | 4 | **48** |
| C7 | Restorative breaks | 3 | 3 | 5 | **45** |
| C8 | End on a proof | 3 | 3 | 5 | **45** |
| C3 | Living Atlas | 5 | 4 | 2 | **40** |
| C11 | Calm periphery | 3 | 3 | 3 | **27** |
| C12 | Notebook behaviours | 4 | 2 | 2 | **16** |
| C9 | Worry dump | 2 | 2 | 4 | **16** |

**Projected creativity score after C1, C2, C3 and C4: about 4.0 / 5.** This moves the product from combinational to exploratory creativity. C3 and C12 together are the path to something transformational: a study app whose *interface itself* is a model of the learner's mathematical knowledge.

---

## 9. Roadmap

**Now (this sprint)**
- N1 two-tier header and `h1` min-width.
- N2 guardrails: future intervals, elapsed-day clamp, dedupe explanation, card-stats source.
- N6 feedback inside the focus overlay, plus inline Park.
- N10 dock-aware `scroll-padding`.
- N3 slim the overflow menu. N8 single back control.

**Next**
- N11 large-text fixes.
- N7 next-best actions.
- N4 in-place global add.
- N9 scroll lock.
- C1 calibration. C4 technique-level interleaving. C5 rhythms.

**Later**
- C2 Proof Ladder. C3 Living Atlas. C11 Live Activity / Live Update. C12 notebook behaviours.

---

## Appendix A · Coverage
Today (session, after finish) · global + menu (Task, Time block, Card, Learning path) · ⋯ menu · Focus (in focus, break, noticed, park, finish form, save) · Paths (all scroll, actions sheet, Load more, archive) · Project (path, sessions, sources, stages, CP chips) · Session 991 (all scroll) · Concept map (list, detail sheet, map tiles) · Review (home, run Q/A, grades, pause sheet) · Cards (list, filter sheet, detail) · Inbox (approve, reject, staged undo, why) · Calendar (Agenda, Day, Week, Month, Day details, Due today, Resolve overlaps, block details, delete and undo) · Planning tools (New task with empty/valid save, Preview a study plan, Backlog with completed group, Deadlines, Topic practice notes, Plan my day steps 1–3, Close my day, Edit study log, Study preferences → Settings, Connected calendars) · Settings (Appearance, Tutor, Study & review, Data & account, Memory) · Sign in · New project · Component kit · Night theme · 320 px · 200% text · landscape.

## Appendix B · Sources
- Runco & Jaeger (2012), *The Standard Definition of Creativity*, Creativity Research Journal: https://doi.org/10.1080/10400419.2012.650092
- Boden, three forms of creativity (overview): https://divingintoradicalcreativity.aalto.fi/?p=575
- Butterfield & Metcalfe; hypercorrection reviews: https://pmc.ncbi.nlm.nih.gov/articles/PMC3970786 · https://core.ac.uk/download/357328401.pdf
- Sinha & Kapur (2021), *When Problem Solving Followed by Instruction Works*, Review of Educational Research: https://doi.org/10.3102/00346543211019105
- Scarr, Cockburn, Gutwin & Bunt (2012), *Improving Command Selection with CommandMaps*, CHI: https://hci.cs.umanitoba.ca/publications/details/improving-command-selection-with-commandmaps
- Rohrer, Dedrick, Hartwig & Cheung (2020), *A randomized controlled trial of interleaved mathematics practice*: https://ies.ed.gov/use-work/awards/efficacy-study-interleaved-mathematics-practice?ID=1790
- Silverman & Barasch (2023), *On or Off Track: How (Broken) Streaks Affect Consumer Decisions*, JCR: https://www.colorado.edu/business/faculty-research/2023/04/19/or-track-how-broken-streaks-affect-consumer-decisions
- Dai, Milkman & Riis (2014), *The Fresh Start Effect*, Management Science: https://faculty.wharton.upenn.edu/wp-content/uploads/2014/06/Dai_Fresh_Start_2014_Mgmt_Sci.pdf
- Masicampo & Baumeister (2011), *Consider it done!*, JPSP: https://pubmed.ncbi.nlm.nih.gov/21688924/
- Albulescu et al. (2022), *"Give me a break!"*, PLOS ONE: https://doi.org/10.1371/journal.pone.0272460
- Ramirez & Beilock (2011), *Science*: https://www.sciencedaily.com/releases/2011/01/110113141605.htm
- Myers, Davis & Chan (2021), *Does expressive writing … reduce the impacts of test anxiety?*: https://pmc.ncbi.nlm.nih.gov/articles/PMC8192598
- Kivetz, Urminsky & Zheng (2006), *The Goal-Gradient Hypothesis Resurrected*: https://business.columbia.edu/faculty/research/goal-gradient-hypothesis-resurrected-purchase-acceleration-illusionary-goal
- Weiser & Brown (1995), *Designing Calm Technology*: https://calmtech.com/papers/designing-calm-technology
- Sailer & Homner (2020), *The Gamification of Learning: a Meta-analysis*: https://doi.org/10.1007/s10648-019-09498-w
- Kahneman, Fredrickson, Schreiber & Redelmeier (1993), *When more pain is preferred to less*, Psychological Science (peak-end rule). Classic reference, cited from the literature.
- WCAG 2.2 SC 2.4.11 Focus Not Obscured (Minimum): https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured
- Previous audit (4 Nov 2026) for platform sources: WCAG 2.5.8, Apple HIG, Material 3 Expressive, Android 14 font scaling, NN/g, Baymard, FSRS.
