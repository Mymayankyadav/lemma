# Lemma v5 re-audit response — v6 implementation

The supplied `Lemma_v5_ReAudit_and_Creativity.md` and its ten screenshot figures are preserved in `audit-input/v5/` as before-change evidence. This pass implements changes for all **12 N1–N12 finding groups**, plus the related screen-level polish described below. These are source implementation dispositions; browser/device closure is not claimed.

## Audit findings

| ID | Delivered change | Verification / boundary |
| --- | --- | --- |
| N1 Header collisions | A shared two-tier header reserves the first row for Back, the title and utilities. Page actions have their own chip row. Detail/secondary pages move Inbox/Add into Menu. Project switching is a separate action; the heading contains the project title. Cards' duplicate New action is removed. Long titles use an ellipsis with their complete accessible text/title. | Actual shared-header and menu components are exercised. 320/390-pixel and 200% rendered geometry still needs device/browser verification. |
| N2 Implausible recorded time | Saved intervals stop at the current instant; future portions are excluded and flagged. Unplaced durations cannot exceed elapsed day capacity. Derived Calendar blocks show future portions as planned records needing review, without changing the raw entry. Manual entry edits reject future end times. Fresh example logs are anchored in the past; existing stored records are preserved. Save feedback states how many minutes overlap and offers Check study log. Today also refreshes its timestamp after saves. Card Memory explains when estimates come from a saved/imported schedule without local review history. | Tests cover 08:05 with later intervals, crossing-now records, future years, elapsed-day limits, duplicate saves, Calendar mirroring, and unchanged totals with explicit overlap receipts. No live database writes or schema changes. |
| N3 Repeated primary destinations | Normal overflow contains secondary destinations. Primary tabs appear there only in landscape, when the bottom navigation is hidden. Detail menus also contain Inbox and Add. | Existing destinations and creation actions remain reachable; the actual compact menu is executed in tests. |
| N4 Global Task changes route | The global Task action opens the shared native sheet on the current page. It supports subject/path/checkpoint tags, estimate presets, due date, priority and inline errors. Save inserts into the same canonical backlog without navigation, with targeted Undo and View in backlog. | Actual sheet validation/save/Undo are tested. Undo preserves unrelated later tasks. Only the explicit View action changes context. |
| N5 Task placeholder | Both Task editors prefix the example with “e.g.” and give placeholders a quieter style. The empty field remains empty, and submit errors remain associated with it. | Source/style checks and invalid-submit regressions pass. |
| N6 Focus feedback and Park | The existing feedback surface moves inside the native Focus dialog while open, then returns to the page without losing actions. Park is an inline, themed field with validation and a session counter. Finish and Close my day expose parked thoughts with Make task/Dismiss. Finish & log is a full-width primary action. | Actual inline Focus, parking, task conversion, feedback hosting and action retention are tested. No browser prompt is used. |
| N7 Empty-plan dead ends | Empty previews and no-suggestion rituals offer Try next day, Review overlaps when relevant, and Adjust daily intention. Retry previews another date without silently adding, shortening or overbooking work. | A full day produces zero placements; retrying the next day previews a fitting task without committing blocks. |
| N8 Settings backs | The header becomes the selected section's title and supplies its single Back action. Duplicate in-page back links and repeated headings are removed. All section deep links initialize correctly. | Module contracts and source review pass. |
| N9 Dialog scroll bleed | Calendar and specimen dialogs lock both the document root and body. Locks restore prior overflow values, support overlapping dialog lifetimes, and release on close/unmount. Sheet bodies contain overscroll. | Nested lock/restoration regression passes. Light-DOM focus scrolling skips shadow hosts/dialogs, preventing an unrelated background jump. Physical touch behavior needs verification. |
| N10 Obscured keyboard focus | Dock measurements now react to compact/large-text attributes, viewport changes, scrolling and element resizing. Root scroll padding and focus margins use current chrome height; focusing a main-page control reveals it above the dock. Forward route focus retries through lazy content loading, without a pointer-triggered heading ring. | A test changes dock position without changing its height and executes the real reveal handler. This is a geometry test double, not a rendered WCAG pass. |
| N11 Large text | Paths titles/meta/progress use growing heights and proportional line spacing. Tabs and proposal actions wrap; the timer gets a stable five-character width and a wider compact slot. Card text inherits the rem-scaled reader size. Detail headings cannot stack letter by letter. Narrow/large-text Calendar overlaps become full-width stack controls. | CSS parsing, token checks and source contracts pass. Final 200% reflow remains unverified. |
| N12 Polish | Calendar receives current core theme tokens, replacing stale red shadow accents. Today uses the accent ring. Range inputs are themed. Concept details have one close control and readable child actions. Study-log dates use readable local dates, including the year when needed. Dock transitions do not animate font size. | Day/Night token transfer is tested. Selected contrast checks pass; computed rendered contrast remains unverified. |

## Related screen changes

- Today omits the redundant CURRENT SESSION eyebrow while the timer status already identifies the active session.
- Subject-grouped Paths rows no longer repeat the group's subject marker/name. Mixed contexts can retain subject information.
- The stage picker is the sole control for selecting a stage; the selected stage no longer adds another collapse control.
- Session timelines use at most 24 columns, binning long conversations while retaining exact outcome counts and the event list.
- Calendar's narrow overlap lanes become named stack controls rather than four tiny, truncated columns.
- The existing seven-day catch-up budget and qualified estimate remain under Review → Queue details. No clearance date is invented from a changing review queue.

## Creative directions

The research suggestions are product directions rather than additional defect counts. The following records exactly what is implemented and what still needs design/data work; learning-effect claims and research forecasts have not been treated as guarantees.

| Idea | Disposition |
| --- | --- |
| C1 Calibration Mirror | **Partly implemented.** Optional Guess/Unsure/Sure is visible before reveal, with an explicit skip and a gentle confident-error cue. The supplied API has three confidence categories. A fourth category, probability-based calibration curve and Brier score need a defined data model; no percentages are invented. |
| C2 Proof Ladder | **Deferred.** Answers are whole mathematical documents, without authoritative proof-step/hint boundaries. Splitting them heuristically could disclose a conclusion early or corrupt notation; the grading proposal also needs validated scheduler semantics. |
| C3 Living Atlas | **Deferred.** Durable coordinates, zoom, checkpoint/review pins and an equivalent accessible list require a map model and interaction pass. The current bounded map/list is retained. |
| C4 Technique interleaving | **Deferred.** Cards have no reliable technique taxonomy. Inferring “compactness” or “diagonalisation” from prose would mislabel work. Existing deck mixing remains; technique tags and queue policy need to be defined together. |
| C5 Forgiving rhythms | **Implemented.** The Time view shows qualifying days out of the last seven using saved, guarded effort and the learner's minimum-day setting. Rest days are neutral. A low/lapsed week can offer a clean-page return step; no broken-streak warning is shown. |
| C6 Open loops | **Partly implemented.** Inline Park, session count, Finish/Close-my-day triage, Task conversion and Dismiss are real. Direct Card/Tutor conversion still needs a deliberate editor/handoff flow to avoid incomplete or duplicate learning records. |
| C7 Restorative break menu | **Deferred.** The existing break timer remains. Break-type preferences, longer-break policy and fatigue measures are a separate opt-in flow; no performance or health benefit is promised by this UI pass. |
| C8 End on a proof | **Deferred.** Saved reflection already persists, but choosing/sharing a “best” mathematical line needs an explicit selection/export interaction. The prototype does not infer that logged time proves mastery. |
| C9 Worry dump | **Deferred.** This is a new private writing flow with mixed evidence, not an audit defect. It needs explicit opt-in/storage behavior and evaluation before being added to exam reminders. |
| C10 Goal-gradient checkpoints | **Existing real step progress retained.** Checkpoint steps remain prominent and path progress secondary. New completion ink/haptics need authoritative demonstration events and motion/device validation; no synthetic steps or completion are added. |
| C11 Native calm surfaces | **Deferred.** Live Activities, Live Updates and installed widgets require native wrappers/entitlements. The static HTML cannot install them. Existing examples remain labeled previews. |
| C12 Notebook interactions | **Deferred.** Persistent margins/stylus input and a notation accessory require dedicated editors and gesture design. Horizontal formula scrolling is preserved; new swipes are not assigned over it. |

## Validation

- **53 state/component regressions:** 26 original + 10 follow-up + 17 re-audit cases, using actual production owners/components with DOM/React test doubles.
- **23 source/module-contract checks**, linking the original 78 import identifiers.
- **84 production JavaScript files and 12 executable inline scripts** parse.
- **Two CSS stylesheets** parse; **48 selected theme/token contrast pairs** pass.
- Retained effort-selector regressions and a deterministic, byte-identical HTML rebuild.

Run `node SOURCE/tests/v5-reaudit.test.cjs` for the combined state suites. Evidence is in `validation/audit/v5-reaudit.json`, the earlier state reports, `validation/mobile-redesign/` and `BUILD_MANIFEST.json`.

**Still unverified:** actual screenshots/viewport geometry, 320/390-pixel and landscape rendering, 200% text, computed rendered contrast, screen readers, and physical-device touch/Back/keyboard behavior. The supported browser-control tool was unavailable; no replacement browser tooling was installed. The supplied re-audit screenshots describe the preceding build.
