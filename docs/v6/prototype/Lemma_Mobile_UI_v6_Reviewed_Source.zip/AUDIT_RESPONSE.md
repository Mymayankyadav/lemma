# Lemma mobile audit response

Latest pass: see [V5_REAUDIT_RESPONSE.md](V5_REAUDIT_RESPONSE.md) for N1–N12 and the creative-direction dispositions. The 82-row count below belongs to the original audit; the new findings are tracked separately.

Implemented against the supplied audit dated 4 November 2026; delivered source revision dated 5 November 2026. The original report/screenshots are retained in `audit-input/` as **before-change evidence**.

The changes address contradictory logged-time data, stale focus state, hidden feedback, inverted action colors, overloaded planning, large-text chrome and interrupted reviews. “Implemented” below describes delivered source behavior; final rendered/device verification is outstanding.

The follow-up pass fixes **12 more finding rows**. Of the audit's **82 screen-specific rows, 78 are implemented, 3 remain partial with explicit reasons, and 1 demo limitation is accepted without change**. There are no unreviewed open rows. See `AUDIT_COMMENT_COUNT.md` for the complete ledger.

The subsequent phone screenshot prompted a header correction: Paths now uses the shared compact header, without a duplicate New action. Inbox/Add/Menu align with the title at normal text sizes, utility surfaces are quieter, and the count badge sits within its target. Add → Learning path preserves creation. Source checks pass; final phone rendering remains unverified.

A further phone screenshot exposed chart focus artifacts: the unconditional focus-within frame is removed, and decorative bar groups no longer create individual focus targets. Keyboard focus remains visible on the scroll viewport, with accessible period labels and the exact-value table preserved. Progress now shows one patterned review legend. These source/style changes pass checks; touch rendering still needs device verification.

## Cross-cutting findings

| Finding | Delivered response | Evidence / limitation |
| --- | --- | --- |
| **X1 · inconsistent facts/stale state** | One immutable notebook store for shell and Calendar; one session timing authority. Today, Day details, Close my day, Progress and project effort consume shared interval calculations. Logged Calendar blocks derive from saved entries. Duplicate/overlapping minutes count once, day capacity is guarded, suspect records link to correction, and subject totals partition the overall total. Checkpoint/session/forecast/review counts have explicit scope. | State regressions cover finish/pause/break/discard, duplicate saves, overlaps, midnight, capacity, subject partitioning and stale revisions. Tutor conversations and timed focus sessions remain distinct records. |
| **X2 · action colors** | Shared primary/destructive/warning roles; red Calendar-dialog overrides removed. Save/Add/Continue use navy/light blue; Delete/Remove/Reject use destructive styling. Today in Month uses an accent ring. | CSS parsing and selected contrast checks pass. Final computed styles need browser verification. |
| **X3 · off-screen feedback** | A single feedback layer attaches directly to document.body outside the transformed Calendar host, above measured chrome/action bars. New confirmations retain pending Undo. | DOM-parent/action-retention regressions pass. Toast bounding-rectangle/viewport intersection remains **unverified** without a browser. |
| **X4 · 200% text/reflow** | Rem body/fields, capped headings, no short-label mid-word wrapping, wrapping header actions, icon navigation, compact timer, large-text Calendar reflow and scalable Inbox math. | Implemented in styles. Final 200%-text and narrow-phone appearance is **unverified**. |
| **X5 · fixed chrome** | Timer accessory joins minimized phone navigation on scroll. Large text uses a compact clock entry into Focus. Landscape uses a slim timer pill, with destinations in header Menu. Sign in suppresses session chrome. | Web behavior implemented. **Live Activity / Live Update deferred** to native wrappers; no OS installation claimed. |
| **X6 · component consistency** | Shared tokens cross the shadow boundary; both systems use functional dialog titles, safe height, scalable fields, associated inline errors, switch tracks and progressive-list wording. 24-hour fields accept four-digit input. | Validation/time-edit/settings regressions pass. Calendar remains a shadow component with shared contracts; no framework rewrite. |
| **X7 · mega-lists** | Five unchecked suggestions and a searchable bounded backlog picker; automatic placement capped at 20 fitted tasks, with capacity/unplaced summary; carry-overs start unchecked with explicit Carry all. Invented 1.3 multipliers removed from active planning. | 283-task regression checks unchecked controls, bounded output, daily budget and conflict-free placement. |
| **X8 · header access** | Shared Inbox/Add/Menu. Add offers Task, Time block, Card and Learning path. Duplicate Calendar Add/Tools controls removed. Card creation also opens correctly when already on Cards. | Module contracts and component checks pass. |
| **X9 · wording/counts** | Functional sheets, human card type/category names, explicitly separate topic practice, natural concept ordering, consistent non-synthetic count, child/children grammar, scoped labels and user-facing calendar-connection names. | Active flows reviewed. Historical source comments/retired feature-inventory text retain provenance. |
| **X10 · recovery/early review exit** | Persistent planner Undo changes affected records without deleting unrelated later logs. Inbox decisions have at least 30 seconds, extended during feedback focus, plus batch Undo. Paused review queues/answers survive session refresh; only exhausted rounds complete. | Regressions cover planner Undo after a later focus save, pending-decision cancellation, focus extension, refresh recovery and completion guard. Card deletion retains explicit confirmation. |
| **X11 · hidden log/attention** | Progress → Time → Edit study log and Planning tools → Edit study log expose editing, splitting and export. Focus exposes Noticed and Park a thought; attention detail uses the integration. | Actual log mutations exercised. Retired public `/carrel/*` routes remain retired; new controls use Calendar plus its supported internal view. |
| **X12 · sheets** | Native dialogs, close/Escape, focus restoration, route-change dismissal, safe-area padding and a 90-dvh cap. Long planning content is bounded. False grab handles removed. | **Design adjustment:** no drag-to-dismiss was added; the false affordance was removed. Native Back/gesture behavior needs physical-device verification. |
| **X13 · paging/scrolling** | Paths append 20; Cards reveal/load 20 in page flow; backlog/deadlines/topics/concepts use progressive batches. Calendar grids use page vertical flow. Formula/chart horizontal scrolling and modal-body scrolling remain intentional. | Actual Cards regression passes. Rendered scroll restoration/reflow remains unverified. |
| **X14 · assistive semantics** | Route titles, heading focus on forward navigation, named utility/deck/grid controls, human task labels, keyboard view tabs and titled native dialogs. | Source contracts pass. Full rendered accessible-name scan and screen-reader pass remain outstanding. |

## Screen findings

| Audit section | Change |
| --- | --- |
| 6.1 Today | Shared time/state; daily intention rail; reduced eyebrow duplication; consistent header cluster; next scheduled block with a direct Start action that opens Focus using its title, duration and tags. |
| 6.2 Focus | Editable duration, optional reflection, Save/Discard; explicit Pomodoro wording; ≥44-pixel controls; duplicate Back-to-notebook and noisy grid removed. |
| 6.3 Paths | Continuous rails, append paging, duplicate native search cancel removed, wrapping Archive breadcrumb, distinct generic subject initials/numbers, no-op actions suppressed, destructive Archive, enabled project field/submit with inline validation. |
| 6.4 Project/session | Scoped forecast verdict/counts, explicit Switch, single stage picker, prominent Locked/Up next/In progress chips, evidence-based outcome counts, categorical event timeline and collapsed repeats. Missing/future checkpoint links are identified and do not advance the path. |
| 6.5 Concept map | Detail sheet, bounded semantic browsing, natural order/counts, type labels removed from rows, preserved map context, batches of 20. |
| 6.6 Review home | Selected-batch checkmark, “due” deck counts, whole-label selection with a separate expansion button, Card library name and Resume review. |
| 6.7 Review run/summary | Pause/Finish later instead of premature completion, refresh recovery, Again separated from passing grades, readable project subtitle capitalization, developer scrolling command removed, qualified tomorrow forecast. |
| 6.8 Cards | Filter sheet/removable chips, page scroll, 20-row loading, one Has notes control, labeled detail actions, destructive Delete, memory explanations and readable enums. |
| 6.9 Calendar | Compact date/view/tools controls, schedule first, capacity/legend with a logged/busy/planned stack partitioned to avoid double counting, actionable conflicts, read-first block details, overlap stacks, month contrast/ring and status symbols. |
| 6.10 Planning / §7 task flow | Global add, catalog subjects, optional path/checkpoint tags, finite estimate/keypad/presets, linked errors, insert/reveal/highlight, persistent Undo, fitting slot suggestions, bounded backward planning with unplaced work stated. |
| 6.11 Progress | Shared saved-time selectors, correction link, compact range, distinct patterned chart, inline confidence values, Other last, “Checkpoints demonstrated” scope. |
| 6.12 Inbox | Single feedback surface, 30-second focus-extended pending decisions/batch Undo, named chevrons, honest missing-rationale copy, scalable math, visible See plan button and stronger Approve hierarchy. |
| 6.13 Settings | Section pages/Back, valid local autosave/Saved feedback, switches, linked weekly goals first, explicit expansion and visible demo sign-out response. Searchable subject management now exposes Add, Edit and reorder in both modes, plus record-preserving merge. |
| 6.14 Sign in | Session chrome suppressed. |
| 6.15 Kit | Destructive variant honored, spinner distinguishes loading, theme copy updated, time values in a dedicated chart column. Interactive Calendar fields/validation/native sheet reuse its actual markup factories and stylesheet. |
| 6.16 Night | Shared semantic roles, field readability, destructive colors and chart patterns apply to both themes. |

The global Task action deliberately opens the structured editor with clear validation. Optional natural-language parsing remains in the existing capture implementation. Subject creation uses the supplied catalog API, including its existing Supabase live adapter; no schema change or live database writes were needed. Native service examples remain labeled previews.

## Reasons for remaining partial items

- **6.12.2 — proposal rationale:** the example records contain no useful tutor rationale or source passage. The UI says so; inventing an explanation would misrepresent the evidence.
- **6.12.3 — swipe navigation:** explicit named Previous/Next chevrons remain. Horizontal gestures are reserved for scrolling long mathematics, preventing accidental proposal changes.
- **6.13.6 — standalone subject deletion:** Add, Edit, search and reorder are implemented. The supplied API has no hard-delete operation. Confirmed Merge removes the source subject while preserving its projects and ideas; it does not promise an unavailable Undo.

**6.14.2 remains accepted:** live sign-in requires a configured production authentication flow; the audit explicitly accepts the demo's limitation. Native Live Activities/Live Updates and physical-device verification are separate limits below.

## Verification

Passed on this revision:

- **36 state/interaction regressions** (26 existing plus 10 follow-up checks), executing actual stores, timer owner, Calendar mutations, review store, subject catalog methods and affected components with DOM/React test doubles.
- **23 source interaction/module-contract checks**, linking all 78 modules.
- Retained effort regressions for duplicate identity, legacy time, intervals, breaks and midnight.
- **84 production JavaScript files and 12 executable HTML scripts** parse without errors.
- **Two CSS stylesheets** parse; **48 selected Day/Night text/boundary/chart contrast pairs** meet thresholds.
- Byte-for-byte reproducible HTML rebuild.

Evidence: `validation/audit/{state-transitions,remaining-items}.json`, `validation/mobile-redesign/{source-interactions,syntax,styles}.json` and `BUILD_MANIFEST.json`.

**Not verified:** final browser screenshots or viewport geometry, computed rendered contrast, 320/390-pixel and landscape reflow, 200% text, physical-device Back/touch gestures, screen readers and human usability sessions. No supported browser-control tool was available in the managed environment. No replacement browser tooling was installed or used. Audit and older source screenshots remain before-change evidence.

**Deferred native work:** iOS Live Activities and Android Live Updates need native wrapper code and entitlements; the static prototype cannot install them. Planned-versus-actual attribution and difficult-topic analytics also remain deferred until their data is defined.

Before a production release, rerun the audit’s device/browser matrix against this exact HTML, especially toast viewport intersection, large-text chrome, modal Back/focus restoration, long mathematics and Day/Week overlap stacks.
