import {useSyncExternalStore} from 'react';
import {authGeneration, authOwner, onAccountChange} from '../../../data/authBoundary';
import {getDemoProfile, getMode} from '../../../data/mode';
import {subscribeTutorLocalCleanup, tutorLocalScopeActive, writeTutorLocal} from '../../../data/tutor/local-storage';
import {ALL_WRITING_AID_SURFACES, type WritingAidMode, type WritingAidSurface, type WritingAidSurfaces} from './policy';

const CHANGE = 'lemma:tutor-writing-aid-preferences';
const DEFAULT_MASK = 15;
const SURFACE_BITS: Readonly<Record<WritingAidSurface, number>> = {words: 1, replace: 2, correction: 4, ghost: 8};
export const WRITING_AID_MODES = ['balanced', 'fast', 'strict', 'off'] as const;
export const TUTOR_HINTS_MODES = ['wording', 'all', 'off'] as const;
export type TutorHintsMode = typeof TUTOR_HINTS_MODES[number];
type Stored = Readonly<{mode: WritingAidMode; mask: number; autoCorrection: boolean; tutorHints: TutorHintsMode}>;
export type WritingAidScope = Readonly<{
  id: string;
  key: string | null;
  ownerId: string | null;
  generation: number;
  defaultMode: WritingAidMode;
}>;

export function currentWritingAidScope(): WritingAidScope {
  const generation = authGeneration();
  if (getMode() === 'demo') {
    const profile = getDemoProfile();
    return {id: 'demo:' + profile, key: 'lemma.demo-tutor.writing-aid.v1:' + profile,
      ownerId: null, generation, defaultMode: 'balanced'};
  }
  const ownerId = authOwner();
  const active = ownerId && tutorLocalScopeActive({ownerId, generation});
  return {id: JSON.stringify(['live', ownerId, generation, Boolean(active)]),
    key: active ? 'lemma.tutor.draft:' + JSON.stringify([ownerId, 'input', 'preferences']) + ':writing-aid' : null,
    ownerId, generation, defaultMode: 'off'};
}

function read(scope: WritingAidScope): Stored {
  try {
    const stored = scope.key && localStorage.getItem(scope.key);
    const match = stored && /^(balanced|fast|strict|off):([0-9]|1[0-5])(?::(0|1)(?::([an]))?)?$/u.exec(stored);
    if (match) return {mode: match[1] as WritingAidMode, mask: Number(match[2]), autoCorrection: match[3] !== '0',
      tutorHints: match[4] === 'a' ? 'all' : match[4] === 'n' ? 'off' : 'wording'};
  } catch {
    // Storage can be restricted in a private window. Keep the relevant default.
  }
  return {mode: scope.defaultMode, mask: DEFAULT_MASK, autoCorrection: true, tutorHints: 'wording'};
}

function snapshot(): string {
  const scope = currentWritingAidScope();
  const {mode, mask, autoCorrection, tutorHints} = read(scope);
  return JSON.stringify([scope.id, Boolean(scope.key), mode, mask, autoCorrection, tutorHints]);
}

function subscribe(update: () => void): () => void {
  const releaseAuth = onAccountChange(update);
  const releaseCleanup = subscribeTutorLocalCleanup(update);
  window.addEventListener(CHANGE, update);
  window.addEventListener('storage', update);
  return () => {
    releaseAuth();
    releaseCleanup();
    window.removeEventListener(CHANGE, update);
    window.removeEventListener('storage', update);
  };
}

function write(change: (current: Stored) => Stored, expectedScopeKey?: string): boolean {
  const scope = currentWritingAidScope();
  if (!scope.key || (expectedScopeKey !== undefined && scope.id !== expectedScopeKey)) return false;
  const {mode, mask, autoCorrection, tutorHints} = change(read(scope));
  const value = mode + ':' + mask + (tutorHints === 'wording' ? autoCorrection ? '' : ':0' :
    ':' + (autoCorrection ? '1' : '0') + ':' + (tutorHints === 'all' ? 'a' : 'n'));
  try {
    if (scope.ownerId) writeTutorLocal({ownerId: scope.ownerId, generation: scope.generation}, scope.key, value);
    else localStorage.setItem(scope.key, value);
    window.dispatchEvent(new Event(CHANGE));
    return true;
  } catch {
    return false;
  }
}

export function setWritingAidMode(mode: WritingAidMode, scopeKey?: string): boolean {
  return WRITING_AID_MODES.includes(mode) && write(current => ({...current, mode}), scopeKey);
}

export function setWritingAidSurface(surface: WritingAidSurface, enabled: boolean, scopeKey?: string): boolean {
  const bit = SURFACE_BITS[surface];
  return Boolean(bit) && write(current => ({...current, mask: enabled ? current.mask | bit : current.mask & ~bit}), scopeKey);
}

export function setWritingAidAutoCorrection(enabled: boolean, scopeKey?: string): boolean {
  return write(current => ({...current, autoCorrection: enabled}), scopeKey);
}

export function setTutorHints(mode: TutorHintsMode, scopeKey?: string): boolean {
  return TUTOR_HINTS_MODES.includes(mode) && write(current => ({...current, tutorHints: mode}), scopeKey);
}

const serverSnapshot = () => '["",false,"off",15,true,"wording"]';
export function useWritingAidPreferences(): {
  scopeKey: string; available: boolean; mode: WritingAidMode; surfaces: WritingAidSurfaces; autoCorrection: boolean;
  tutorHints: TutorHintsMode;
} {
  const stored = useSyncExternalStore(subscribe, snapshot, serverSnapshot);
  const [scopeKey, available, mode, mask, autoCorrection, tutorHints] = JSON.parse(stored) as
    [string, boolean, WritingAidMode, number, boolean, TutorHintsMode];
  const surfaces = mask === DEFAULT_MASK ? ALL_WRITING_AID_SURFACES : {
    words: Boolean(mask & SURFACE_BITS.words),
    replace: Boolean(mask & SURFACE_BITS.replace),
    correction: Boolean(mask & SURFACE_BITS.correction),
    ghost: Boolean(mask & SURFACE_BITS.ghost),
  };
  return {scopeKey, available, mode, surfaces, autoCorrection, tutorHints};
}
